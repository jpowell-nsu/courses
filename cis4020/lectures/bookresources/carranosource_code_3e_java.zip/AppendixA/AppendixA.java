// Java comment on a single line                // C++ comment on a single line
/* Java comment                                 /* C++ comment
   that crosses multiple lines */                  that crosses multiple lines */
/** Javadoc-style comments */

// Java uses packages to group                  // C++ uses libraries to group
// related classes together                     // related functions and classes
                                                // together

// Java class                                   // C++ class - by default, all
// Each member has an access                    // members are private unless
// modifier (public, private,                   // labeled otherwise, no package access
// protected, or none for
// package access)                              class Person {
class Person {                                    string name;
  private String name;                          protected:
  protected int age;                              int age;
  double gpa;                                     double gpa;
  public Person() {                             public:
  } // end default constructor                    Person();
  ...                                           };  // end Person
}  // end Person

// No equivalent in Java, a class               // C++ structure - by default, all
// containing only public data                  // members are public unless
// could be used                                // labeled otherwise
                                                struct person {
                                                  string name;
                                                  int    age;
                                                  double gpa;
                                                };  // end person

// Java supports single inheritance             // C++ supports multiple
// of classes. Interfaces can be                // inheritance
// used to specify additional
// behavior

// Java provides generics to handle             // C++ provides generics to handle
// parameterized types                          // parameterized types
public class Stack <T> {                        template <class T>
  private T temp;                               class Stack {
                                                  private:
  public void push(T newItem) {                     T temp;
    ...
  } // end push                                   public:
} // end Stack                                      void push(const T&);

                                                    ...
                                                } // end Stack

                                                template <class T>
                                                void Stack<T>::push(const T& newItem) {
                                                    ...
                                                }

// Java does not rely on a                      // C++ uses a preprocessor for
// preprocessor;                                // compiler directives such as file
// functionality is provided by the             // inclusion
// Java language itself

// Java methods must appear as part             // C++ can have stand-alone functions
// of a class

// Java constant                                // C++ constant
// Must be declared within a class              // Can be declared globally or
// or a method                                  // within a class or a function
final int SIZE = 50;                            const int SIZE = 50;

// Java valued method                           // C++ valued function
public boolean isLeapYear(int year) {           bool isLeapYear(int year) {
// Returns true if year is a leap               // Returns true if year is a leap
// year; otherwise returns false.               // year; otherwise returns false.
   boolean leap = false;                           bool leap = false;
   boolean yearEndsIn00 = (year % 100 == 0);       bool yearEndsIn00 = (year % 100 == 0);
   if (yearEndsIn00 && (year % 400 == 0))          if ( yearEndsIn00 && (year % 400 == 0))
      leap = true;                                    Leap = true;
   else if (!yearEndsIn00 && (year % 4 == 0))      else if (!yearEndsIn00 &&
      leap = true;                                                        (year % 4 == 0))
   return leap;                                       leap = true;
} // end isLeapYear                                return leap;
                                                } // end isLeapYear

// Java variable declarations                   // C++ variable declarations
// Variables must be declared                   // Variables can be declared
// within a class or a method                   // globally as well as within
int      day, month, year;                      // classes and methods
double   power, x;                              int    day, month, year;
char     response;                              double power, x;
boolean  done;                                  char   response;
// Simple reference declaration; no             bool   done;
// object is instantiated until the             // Objects can be declared
// new operator is used. Java                   // statically using the default
// supports only dynamic allocation             // constructor
// of objects                                   Sphere ball;
Sphere ball;                                    // Also by using a constructor with
// Creating an object using a                   // parameters
// default constructor                          Sphere ball(1.0);
Sphere ball = new Sphere();                     // Dynamic allocation is supported
// Using constructor with                       // using pointers and the new
// parameters                                   // operator
Sphere ball = new Sphere(1.0);                  Sphere *ball = new Sphere();

// Equality in Java                             // Equality in C++
// == and != check for shallow                  // == and != check for shallow
// equality                                     // equality
// For object equality, must                    // For object equality, must
// override the equals method from              // provide the functions operator
// class Object                                 // == and operator !=, for example

// Java array, primitive types                  // C++ array
double[] r = new double[SIZE];                  typedef double arrayType[SIZE];
double[] s = new double[SIZE];                  arrayType r;
                                                double    s[SIZE];
for (int i = 0; i < SIZE; i++) {
  r[i] = 0.0;                                   for (int i = 0; i < SIZE; ++i) {
} // end for                                       r[i] = 0.0;
                                                } // end for
// Java array using objects and references
Sphere[] marbles = new Sphere[SIZE];
for (int i=0; i < SIZE; i++) {
  marbles[i] = new Sphere(0.3);
} // end for

// Java Standard Output                         // C++ Standard Output
System.out.println("Enter month and " +         cout << "Enter month and day "
      "day for year " + year +                       << "for year" << year
      "as integers: ");                              << " as integers: ";

// Java Scanner class can be used               // C++ Standard input
// with standard input                          cin >> x >> y;
import java.util.Scanner;
Scanner kbInput = new Scanner(System.in);
x = kbInput.nextInt();
y = kbInput.nextDouble();
