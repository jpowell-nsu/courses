http://java.com and http://www.oracle.com/technetwork/java/
index.html

http://www.java.com/en/download/

http://download.oracle.com/javase/

public class Hello {
  public static void main(String[] args) {
    System.out.println("Hello World");
  } // end main
} // end Hello

javac Hello.java

java Hello

Hello World
