power2(x, n)

    if (n == 0)
       return 1
    else
       return  x * power2(x, n-1)

power2(x, k) = xk

power2(x, k + 1) = x * power2(x, k)

power2(x, k + 1) = x * xk
                 = xk + 1
