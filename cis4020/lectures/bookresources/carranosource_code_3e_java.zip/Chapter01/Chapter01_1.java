double radius;  // radius of a sphere
String name;    // reference to a String object

double radius;
double radiusCubed;

int x = 9;
Integer intObject = new Integer(x);
System.out.println("The value stored in intObject = "
                   + intObject.intValue());

Integer intObject = 9;

int x = intObject + 1;

String name = new String("Sarah");

4 * Math.PI * radiusCubed / 3

System.out.println("Hello\n Let\'s get started!");

final float DEFAULT_RADIUS = 1.0;

radius = initialRadius;

double radiusCubed = radius * radius * radius;

a / b * c

(a / b) * c

(5 == 4) && (a < b)  // false since (5 == 4) is false
(5 == 5) || (a < b)  // true since (5 == 5) is true

int ? long ? float ? double

double volume = 14.9;
System.out.print((int)volume);

final int DAYS_PER_WEEK = 7;
double [] maxTemps = new double[DAYS_PER_WEEK];

double [] weekDayTemps = {82.0, 71.5, 61.8, 75.0, 88.3};

String[] stuNames = new String[10];

stuName[0] = new String("Andrew");

final int DAYS_PER_WEEK = 7;
final int WEEKS_PER_YEAR = 52;

double[][] minTemps = new
                      double[DAYS_PER_WEEK][WEEKS_PER_YEAR];

// minTemps is a two-dimensional array of daily minimum
// temperatures for 52 weeks, where each column of the
// array contains temperatures for one week.

// initially, assume the lowest temperature is
// first in the array
double lowestTemp = minTemps[0][0];
int dayOfWeek = 0;
int weekOfYear = 0;
// search array for lowest temperature
for (int weekIndex = 0; weekIndex < WEEKS_PER_YEAR;
                                         ++weekIndex) {
  for (int dayIndex = 0; dayIndex < DAYS_PER_WEEK;
                                         ++dayIndex) {
    if (lowestTemp > minTemps[dayIndex][weekIndex]) {
      lowestTemp = minTemps[dayIndex][weekIndex];
      dayOfWeek = dayIndex;
      weekOfYear = weekIndex;
    }  // end if
  } // end for
} // end for
// Assertion: lowestTemp is the smallest value in
// minTemps and occurs on the day and week given by
// dayOfWeek and weekOfYear; that is, lowestTemp ==
// minTemps[dayOfWeek][weekOfYear].

int[][] x = {{1,2,3},{4,5,6}};
