if (expression)
   statement1

if (expression)
   statement1
else
   statement2

if (a > b) {
  System.out.println(a + " is larger than " + b + ".");
} // end if
System.out.println("This statement is always executed.");

if (a > b) {
  larger = a;
  System.out.println(a + " is larger than " + b + ".");
}
else {
  larger = b;
  System.out.println(b + " is larger than " + a + ".");
} // end if

System.out.println(larger + " is the larger value.");

if ((a >= b) && (a >= c)) {
  largest = a;
}
else if (b >= c) {    // a is not largest at this point
  largest = b;
}
else {
  largest = c;
} // end if

switch (month) {
  // 30 days hath Sept., Apr., June, and Nov.
    case 9: case 4: case 6: case 11:
      daysInMonth = 30;
      break;
    // all the rest have 31
    case 1: case 3: case 5: case 7: case 8: case 10: case 12:
      daysInMonth = 31;
      break;

    // except February
    case 2:  // assume leapYear is true if leap
             // year, else is false
      if (leapYear) {
         daysInMonth = 29;
      }
      else {
         daysInMonth = 28;
      } // end if
      break;

   default:
      System.out.println("Incorrect value for Month.");
}  // end switch

case expression:
