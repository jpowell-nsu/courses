while (expression)
   statement

int sum = 0;
int index = 0;
while (index <= myArray.length) {
  sum += myArray[index];
} // end while

for (initialize; test; update)
   statement

int sum = 0;
for (int counter = 1; counter <= n; ++counter) {
  sum += counter;
} // end for

// this statement is always executed
int x = 0;

int sum = 0;
int counter = 1;
while (counter <= n) {
   sum += counter;
   ++counter;
}  // end while
// this statement is always executed
int x = 0;

initialize;
while (test) {
  statement;
  update;
} // end while

for (byte ch = 'z'; ch >= 'a'; --ch) {
// ch ranges from 'z' to 'a'
   statements to process ch
}  // end for

for (double x = 1.5; x < 10; x += 0.25) {
// x ranges from 1.5 to 9.75 at steps of 0.25
   statements to process x
}  // end for

// floating-point power equals floating-point x
// raised to int n; assumes integer expon
for (power = 1.0, expon = 1; expon <= n; ++expon){
   power *= x;
}   // end for

sum = 0;
int i = 0;
while (i < x.length) {
   sum += x[i];
   i++;
} // end while

for (int i = 0, sum = 0; i < x.length; sum += x[i++]) {
}

for (int i = 0, sum = 0; i < x.length; ) {
   sum += x[i++];
} // end for

for ( ; x > 0; ) {
   statements to process nextValue in inputLine
} // end for

while (x > 0)

for (ArrayElementType variableName : arrayName)
   statement

String[] nameList = { "Janet", "Frank", "Mike", "Doug"};
for (string name: nameList) { // for each name in nameList
   System.out.println(name);
} // end for

String[] nameList = { "Janet", "Frank", "Mike", "Doug"};
for (int index=0; index < nameList.length; index++) {
   System.out.println(nameList[index]);
} // end for

do {
   statement
} while (expression);

char response;
do {
   . . . (a sequence of statements)
   ask the user if they want to do it again
   store user's response in response
}  while ( (response == 'Y') || (response == 'y') );
