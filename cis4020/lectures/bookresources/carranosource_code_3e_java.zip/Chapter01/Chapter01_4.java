The volume of a sphere of radius 19.1 inches is 29186.95

package package-name;

import package-name.class-name;

import java.lang.*;

new SimpleSphere()

access-modifier use-modifiers return-type
                method-name (formal-parameter-list) {
  method-body
}

public static int max(int x, int y) {
  if (x > y) {
    return x;
  }
  else {
    return y;
  } // end if
}  // end max

return expression;

int x, int y

public void printLargest(int a, int b, int c) {
  int largerAB = max(a, b);
  System.out.println("The largest of "+ a + ", " + b + ", "
                + " and " + c + " is " + max(largerAB, c));
} // end printLargest

public static double averageTemp(double[] temps, int n)

double avg = averageTemp(maxTemps, 6);

public static int max(int... numbers) {

   int maximum = Integer.MIN_VALUE;
   for (int num : numbers) {
     if (maximum < num){
       maximum = num;
   } // end if
  } // end for
  return maximum;
} // end max

public SimpleSphere() {
  radius = DEFAULT_VALUE; // DEFAULT_VALUE = 1.0
} // end default constructor

SimpleSphere unitSphere = new SimpleSphere();

The next constructor in SimpleSphere is

public SimpleSphere(double initialRadius) {
  setRadius(initialRadius);
} // end constructor

SimpleSphere mySphere = new SimpleSphere(5.1);

SimpleSphere defaultSphere = new SimpleSphere();

static public void main(String[] args) {
  SimpleSphere ball = new SimpleSphere(19.1);
  System.out.println("The volume of a sphere of radius "
                    + ball.getRadius() + " inches is "
                    + (float)ball.getVolume()
                    + "cubic inches\n");
} //end main

SimpleSphere.DEFAULT_RADIUS;

import java.awt.Color;
public class ColoredSphere extends SimpleSphere {
  private Color color;

  public ColoredSphere(Color c) {
    super();
    color = c;
  } // end constructor

  public ColoredSphere(Color c, double initialRadius) {
    super(initialRadius);
    color = c;
  } // end constructor

  public void setColor(Color c) {
    color = c;
  } // end setColor

  public Color getColor() {
    return color;
  } // end getColor
} // end ColoredSphere

super.getVolume()

public void useColoredSphere() {
  ColoredSphere redBall =
       new ColoredSphere(java.awt.Color.red);
  System.out.println("The ball volume is " +
                     redBall.getVolume());
  System.out.println("The ball color is " +
                     redBall.getColor());
  // other code here...
} // end useColorSphere
