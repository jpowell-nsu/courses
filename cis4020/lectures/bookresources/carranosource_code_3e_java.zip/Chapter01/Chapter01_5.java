public boolean equals(Object obj)

SimpleSphere s1 = new SimpleSphere();
SimpleSphere s2 = s1;
if (s1.equals(s2)) {
  System.out.println("s1 and s2 are the same object" );
} // end if

s1 and s2 are the same object

SimpleSphere s1 = new SimpleSphere(2.0);
SimpleSphere s3 = new SimpleSphere(2.0);
if (s1.equals(s3)) {
  System.out.println("s1 and s3 have the same radius");
}
else {
  System.out.println("s1 and s3 have different radii");
} // end if

s1 and s3 have different radii

public boolean equals(Object rhs) {
  return ((rhs instanceof SimpleSphere) &&
          (radius == ((SimpleSphere)rhs).radius));
} // end equals

protected void finalize()

public int hashCode()

public String toString()

Sphere mySphere = new Sphere();

public static ptype[] copyOf(ptype[] original, int newLength)

public static ptype[] copyOfRange(ptype[] original,
                               int beginIndex, int endIndex)

public static String toString(ptype[] a)

public static int binarySearch(ptype[] a, ptype key)

public static void sort(ptype[] a)

"This is a string."

String title;

String title = "Walls and Mirrors";

title = "J Perfect's Diary";

string1.compareto(string2)

"dig".compareTo("dog")     //returns negative
"Star".compareTo("star")   //returns negative
"abc".compareTo("abc")     //returns zero
"start".compareTo("star")  //returns positive
"d".compareTo("abc")       //returns positive

String s = "Com";

String t = s + "puter";
s += "puter";

s += 's';

String monthName = "December";
int day = 31;
int year = 02;
String date = monthName + " " + day + ", 20" + year;

public String substring(int beginIndex, int endIndex)

title = "J Perfect's Diary";

public int indexOf(String str, int fromIndex)

public String replace(char oldChar, char newChar)

public String trim()

public StringBuffer append(String str)

public StringBuffer insert(int offset, String str)

public StringBuffer delete(int start, int end)

public void setCharAt(int index, char ch)

public StringBuffer replace(int start, int end,
                            String str)

public StringTokenizer(String str)

public StringTokenizer(String str, String delim)

public StringTokenizer(String str, String delim,
                       boolean returnTokens)

public String nextToken()

public boolean hasMoreTokens()
