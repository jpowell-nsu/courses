try {
  statement(s);
}

catch (exceptionClass identifier) {
  statement(s);
}

try {
  int result = 99 / 0;
  // other statements appear here
} // end try
catch (Exception e) {
  System.out.println("Something else was caught");
} // end catch
catch (ArithmeticException e) {
  System.out.println("ArithmeticException caught");
} // end catch

TestExceptionExample.java:43: exception
  java.lang.ArithmeticException has already been caught
    catch (ArithmeticException e) {
    ^
1 error

class ExceptionExample {
  private int [] myArray;

  public ExceptionExample() {
    myArray = new int[10];
  }  // end default constructor
  public void addValue(int n, int value) {
    // add value to element n by calling addOne n times
    for (int i = 1; i <= value; i++) {
      addOne(n);
    } // end for
  } // end addValue

  public void addOne(int n) {
    // add 1 to the element n
      myArray[n] += 1;
  } // end addOne
} end ExceptionExample

public class TestExceptionExample {
  public static void main(String[] args) {
    ExceptionExample e1 = new ExceptionExample();
    e1.addValue(99, 3); // add 3 to element 99
  } // end main
} // end TestExceptionExample

java.lang.ArrayIndexOutOfBoundsException: 99
  at ExceptionExample.addOne(ExceptionExample.java)
  at ExceptionExample.addValue(Compiled Code)
  at TestExceptionExample.main(TestExceptionExample.java)

public void addOne(int n) {
  try {
    myArray[n] += 1;
  } // end try
  catch (ArrayIndexOutOfBoundsException e) {
    System.out.println("The element you requested, " +
                       n + ", is not available.");
  } // end catch
} // end addOne

The element you requested, 99, is not available.
The element you requested, 99, is not available.
The element you requested, 99, is not available.

public void addValue(int n, int value) {
  try {
    for (int i = 1; i <= value; i++) {
      addOne(n);
    } // end for
  } // end try
  catch (ArrayIndexOutOfBoundsException e) {
    System.out.println("The element you requested, " +
                      n + " is not available.");
    e.printStackTrace();
  } // end catch
} // end addValue

The element you requested, 99 is not available.
java.lang.ArrayIndexOutOfBoundsException: 99
  at ExceptionExample.addOne(ExceptionExample.java)
  at ExceptionExample.addValue(Compiled Code)
  at TestExceptionExample.main(TestExceptionExample.java)

import java.io.*;
public class TestExceptionExample  {
  public static void getInput(String fileName) {
    FileInputStream fis;
    fis = new FileInputStream(fileName);
    // file processing code appears here
  } // end getInput

  static public void main(String[] args) {
    getInput("test.dat");
  } // end main
} // end TestExceptionExample

TestExceptionExample.java:5: unreported exception
java.io.FileNotFoundException must be caught, or declared
to be thrown
    fis = new FileInputStream(fileName);
          ^
1 error

public static void getInput(String fileName) {
  FileInputStream fis;
  try {
    fis = new FileInputStream(fileName);
    // file processing code appears here
  } // end try
  catch (FileNotFoundException e) {
    System.out.println("The file " + fileName +
                      " is not available");
    System.out.println(e);
  } // end catch
  System.out.println("After try-catch blocks");
} // end getInput

The file test.dat is not available
java.io.FileNotFoundException: test.dat
  at java.io.FileInputStream.<init>(FileInputStream.java:56)
  at TestExceptionExample.getInput(TestExceptionExample.java)
  at TestExceptionExample.main(TestExceptionExample.java)
After try-catch blocks

finally {
  statement(s);
}

public FileInputStream(String name)
                        throws FileNotFoundException

throw reference

throw new exceptionClass(stringArgument);

class MyRuntimeException extends RuntimeException {
  public MyRuntimeException(String s) {
    super(s);
  } // end constructor
  // All other methods are inherited.
}  // end MyRuntimeException

class MyException extends Exception {
  public MyException(String s) {
    super(s);
  } // end constructor
  // All other methods are inherited.
  // This exception must be handled in or
  // propagated from the method in which it occurs.
}  // end MyException

throw new MyException("MyException: Provide reason");

public void myMethod() throws MyException {
  // some code here...
  throw new MyException("MyException was thrown: reason");
} // end myMethod
