BufferedReader stdin = new BufferedReader(
          new InputStreamReader(System.in));

String nextLine = stdin.readLine();

BufferedReader stdin = new BufferedReader(
         new InputStreamReader(System.in));

String nextLine = stdin.readLine();

StringTokenizer input = new StringTokenizer(nextLine);
x = Integer.parseInt(input.nextToken());
y = Integer.parseInt(input.nextToken());

import java.util.Scanner;

int nextValue;
int sum=0;
Scanner kbInput = new Scanner(System.in);

nextValue = kbInput.nextInt();
while (nextValue > 0) {
  sum += nextValue;
  nextValue = kbInput.nextInt();
} // end while
kbInput.close();

int count = 5;
double average = 20.3;
System.out.println("The average of the " + count
     + " distances read is " + average
     + " miles.");

The average of the 5 distances read is 20.3 miles.

SimpleSphere mySphere = new SimpleSphere();
System.out.println(mySphere);

SimpleSphere@733f42ab

public String toString() {
  return ("SimpleSphere: radius = " + radius);
} // end toString

SimpleSphere mySphere = new SimpleSphere();
System.out.println(mySphere);

SimpleSphere: radius = 1.0

printf(String format, Object... args)

String name = "Jamie";
int x = 5, y = 6;
int sum = x + y;
System.out.printf("%s, %d + %d = %d", name, x, y, sum);

Jamie, 5 + 6 = 11

%[width][.precision]conversion

Console myConsole = System.console();

  if (myConsole == null) {
      System.err.println("No console available.");
      System.exit(1);
  } // end if

String readLine(String fmt, Object... args)

char[] readPassword()
char[] readPassword(String fmt, Object... args)

Console printf(String format, Object... args)

PrintWriter writer()

import java.io.Console;
import java.util.Arrays;
import java.io.Printwriter;

public class ConsoleExample {

  static boolean validateLogin(String username,
                               char[] password) {
    // Would put code in here to validate the user login
    return true;
  }  // end validateLogin

  public static void main (String args[]){
    Console cons = System.console();
    if (cons == null) {
      System.err.println("No console available.");
      System.exit(1);
    } // end if
    PrintWriter consOutput = cons.writer();
    String username = cons.readLine("Username: ");
    char [] password = cons.readPassword("Password: ");

    if (validateLogin(username, password)) {
      // At this point you have validated the password
      consOutput.println("User " + username +
                         "successfully logged in");
      // Now wipe out the password from memory
      Arrays.fill(password, ' ');
      // And let the user start his or her session...
    } // end if

  } // end main
} // end ConsoleExample
