Scanner(InputStream source)

Scanner(File source)

String fname, lname;
int age;
Scanner fileInput;
File inFile = new File("Ages.dat");

try {
  fileInput = new Scanner(inFile);

  while (fileInput.hasNext()) {
    fname = fileInput.next();
    lname = fileInput.next();
    age = fileInput.nextInt();
    age = fileInput.nextInt();
    System.out.printf("%s %s is %d years old.\n",
                    fname, lname, age);
  } // end while

  fileInput.close();

} // end try
catch (FileNotFoundException e) {
  System.out.println(e);
} // end catch

FileReader inStream = new FileReader("Ages.dat");

File inFile = new File("Ages.dat");
FileReader inStream = new FileReader(inFile);

FileReader fr = new FileReader("Ages.dat");
BufferedReader input = new BufferedReader(fr);

BufferedReader input = new BufferedReader(
                       new FileReader("Ages.dat"));

BufferedReader input;
try {
  input = new BufferedReader(new FileReader("Ages.dat"));
  // read data from file
} // end try
catch (FileNotFoundException e) {
  e.printStackTrace();
  System.exit(1); // File not found so exit
} // end catch

StringTokenizer line;
while (input.ready()) {
    line = new StringTokenizer(input.readLine());
    // process line of data
    ...

}  // end while

StringTokenizer line;
String inputLine;
while ((inputLine = input.readLine()) != null) {
  line = new StringTokenizer(inputLine);
  // process line of data
  ...

} // end while

BufferedReader input;
StringTokenizer line;
String inputLine;
try {
  input = new BufferedReader(new FileReader("Ages.dat"));
  while ((inputLine = input.readLine()) != null) {
    line = new StringTokenizer(inputLine);
    // process line of data
    ...

  }
} // end try
catch (IOException e) {
  System.out.println(e);
  System.exit(1); // I/O error, exit the program
} // end catch

FileWriter outStream = new FileWriter("Results.dat");

try {
  PrintWriter output = new PrintWriter(
         new FileWriter("Results.dat"));
  output.println("Results of the survey");
  output.println("Number of males: " + numMales);
  output.println("Number of females: " + numFemales);

  // other code and output appears here...
} // end try

catch (IOException e) {
  System.out.println(e);
  System.exit(1); // I/O error, exit the program
} // end catch

myStream.close();

PrintWriter ofStream = new PrintWriter(
            new FileOutputStream("Results.dat", true));

public static void copyTextFile(String originalFileName,
                                String copyFileName) {
// ---------------------------------------------------------
// Makes a duplicate copy of a text file.
// Precondition: originalFileName is the name of an existing
// external text file, and copyFileName is the name of the
// text file to be created.
// Postcondition: The text file named copyFileName is a
// duplicate of the file named originalFileName.
// ---------------------------------------------------------
  BufferedReader ifStream = null;
  PrintWriter ofStream = null;

  try {
    ifStream = new BufferedReader(
               new FileReader(originalFileName));
    ofStream = new PrintWriter(new FileWriter(copyFileName));
    String line;

    // copy lines one at a time from given file
    // to new file
    while ((line = ifStream.readLine()) != null) {
      ofStream.println(line);
    }  // end while
  }  // end try
  catch (IOException e) {
    System.out.println("Error copying file");
  }  // end catch
  finally {
    try {
      ifStream.close(); // close the files
      ofStream.close();
    } // end try
    catch (IOException e) {
     e.printStackTrace();
    }  // end catch
  } // end finally
}  // end copyTextFile

public class Person {
  private String name;
  private double salary;

  public Person(String n, double s) {
    name = n;
    salary = s;
  }  // end constructor
  // other methods appear here
}  // end Person

public static Person searchFileSequentially(
                        String fileName, String desiredName) {
  // --------------------------------------------------------
  // Searches a text file sequentially for a desired person.
  // Precondition: fileName is the name of a text file of
  // names and data about people. Each person is represented
  // by two lines in the file: The first line contains the
  // person's name, and the second line contains the person's
  // salary. desiredName is the name of the person sought.
  // Postcondition: If desiredName was found in the file,
  // a Person object that contains the person's
  // name and data is returned. Otherwise, the value null
  // is returned to indicate that the desiredName was not
  // found. The file is unchanged and closed.
  // --------------------------------------------------------
  BufferedReader ifStream = null;
  String nextName = null;
  String nextSalary = null;
  boolean found = false;

  try {
    ifStream = new BufferedReader(new FileReader(fileName));
    while (!found &&
           (nextName = ifStream.readLine()) != null) {
      nextSalary = ifStream.readLine();
      if (nextName.compareTo(desiredName) == 0) {
        found = true;
      } // end if
    } // end while
  } // end try
  catch (IOException e) {
    System.out.println("Error processing file");
    return null;
  } // end catch
  finally {
    if(ifStream != null) {
      try {
        ifStream.close(); // close the file
      } // end try
      catch (IOException e) {
        System.out.println("Error closing file");
      } // end catch
    } // end if
  } // end finally
  if (found) {
    return new Person(nextName,
                      Double.parseDouble(nextSalary));
  }
  else {
    return null;
  } // end if
} // end searchFileSequentially

import java.io.Serializable;

public class Person implements Serializable {
  private String name;
  private double salary;
  private Person[] dependents;
  private int numDepend = 0;

  public Person(String n, double s) {
    name = n;
    salary = s;
    // assume that ListArrayBased also implements the
    // Serializable interface
    dependents = new Person[25];
  } // end constructor
  public void addDependent(Person p) {
    numDepend++;
    dependents[numDepend] = p;
  } // end addDependent

  public String getName() {
    return name;
  } // end getName

  // other methods for class appear here
} // end Person

ObjectOutputStream ooStream = new ObjectOutputStream(
              new FileOutputStream("EmployeeDB.dat"));
ooStream.writeObject(p);

ioStream = new ObjectInputStream(
                       new FileInputStream("EmployeeDB.dat"));
nextPerson = (Person)ioStream.readObject());

public static Person searchFileSequentially(
                     String fileName, String desiredName) {
  // --------------------------------------------------------
  // Searches a text file sequentially for a desired person.
  // Precondition: fileName is the name of a binary file
  // of Person objects. desiredName is the name of the person
  // sought.
  // Postcondition: If desiredName was found in the file,
  // a Person object that contains the person's
  // name and data is returned. Otherwise, the value null
  // is returned to indicate that desiredName was not
  // found. The file is unchanged and closed.
  // --------------------------------------------------------
  ObjectInputStream ioStream = null;
  Person nextPerson = null;
  boolean found = false;

  try {
    ioStream = new ObjectInputStream(
                               new FileInputStream(fileName));
    while (!found && (nextPerson =
             (Person)ioStream.readObject()) != null) {
      if (nextPerson.getName().compareTo(desiredName) == 0) {
        found = true;
      } // end if
    } // end while
  } // end try
  catch (IOException e) {
    System.out.println("Error processing file");
    return null;
  } // end catch
  catch (ClassNotFoundException e) {
    System.out.println("Unexpected object type in file");
    return null;
  } // end catch
  finally {
    //Close the ObjectInputStream
    try {
      if (ioStream != null) {
        ioStream.close();
      }
    } catch (IOException ex) {
      ex.printStackTrace();
    } // end catch
  } // end finally
  if (found) {
    return nextPerson;
  }
  else {
    return null;
  } // end if

} // end searchFileSequentially
