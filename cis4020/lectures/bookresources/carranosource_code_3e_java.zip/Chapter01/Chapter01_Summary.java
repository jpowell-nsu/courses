final  type-identi?er = value;

if (expression)
   statement1
else
   statement2

switch (expression) {
  case constant1:
    statement1
    break;
  . . .
  case constantn: case constantn+1:
    statementn
    break;
  default:
    statement
}

while (expression)
   statement

for (initialize; test; update)
   statement

for (ArrayElementType variableName: arrayName)
   statement

do
    statement
while (expression);

import package-name.class-name;

access-modi?er  use-modi?er  type  name(formal-parameter-list) {
    body
}
