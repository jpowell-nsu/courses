move(x, y)
// Moves a shape to a new location on the screen.
// Precondition: The calling code provides an
// (x, y) pair, both integers.
// Postcondition: The shape is moved to the new
// location.

move(x, y)
// Moves a shape to coordinate (x, y) on the screen.
// Precondition: The calling code provides an
// (x, y) pair, both integers, where
// 0 <= x <= MAX_XCOOR, 0 <= y <= MAX_YCOOR, where
// MAX_XCOOR and MAX_YCOOR are class constants that
// specify the maximum coordinate values.
// Postcondition: The shape is moved to coordinate
// (x, y).

assert booleanExpression;
assert booleanExpression : valueExpression;

public static void main(String[] args) {
  Scanner reader = new Scanner(System.in);
  System.out.print("Enter your score: ");
  int score = reader.nextInt();
  assert score>=0 && score <= 100 :
         "Score "+score+" is not in range 0-100";
  // Continue processing score
  System.out.println("Processing score...");
}

Exception in thread "main" java.lang.AssertionError:
       Score -23 is not in range 0-100
       at AssertionClass.main(AssertionClass.java:9)

// computes the sum of item[0], item[1], . . .,
// item[n-1] for any n >= 1
int sum = 0;
int j = 0;
while (j < n) {
  sum += item[j];
  ++j;
}  // end while

int sum = 0;
int j = 0;
                ?the invariant is true here
while (j < n) {
                ?the invariant is true here
  sum += item[j];
  ++j;
                ?the invariant is true here
}  // end while
                ?the invariant is true here

// Invariant: 0 <= j <= n and
// sum = item[0] +...+ item[j-1]
while (j < n)
   . . .

for (initialize; test; update) {
  statement(s)
} // end for

initialize;
while (test) {
  statement(s)
  update;
} // end while

// Computes an approximation to ex for a real x
double t = 1.0, s = 1.0;
int k = 1;
// Invariant: t == xk-1/(k-1)! and
// s == 1+x+x2/2!+...+xk-1/(k-1)!
while (k <= n) {
  t *= x/k;
  s += t;
  ++k;
}  // end while

// Computes n! for an integer n >= 0
int f = 1;
// Invariant: f == (j-1)!
for (int j = 1; j <= n; ++j) {
  f *= j;
}  // end for
