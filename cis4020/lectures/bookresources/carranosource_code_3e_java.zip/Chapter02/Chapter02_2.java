years[index] = 1492;

System.out.println(years[index]);

Set the time
Advance the time
Display the time

Set its value
Advance its value
Display its value

Read the test scores
Sort the scores
Get the "middle" score

Prompt the user for a score
Place the score into an array

-hour: integer
-minute: integer
-second: integer

+setTime(in hr: integer, in min: integer, in sec: integer)
-advanceTime()
+displayTime() {query}
