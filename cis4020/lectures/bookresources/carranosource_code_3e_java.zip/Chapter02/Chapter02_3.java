int [] scores = new int[202];

for (index = 0 through 201)
   Process the score

final int NUMBER_OF_MAJORS = 202;

int [] scores = new int[NUMBER_OF_MAJORS];

for (index = 0 through NUMBER_OF_MAJORS - 1)
   Process the score

1800  6  1
Jones, Q.  223 2234.00 1088.19  N, J  Smith, T. 111
110.23 I,  Harris, V.  44  44000.00 22222.22

CUSTOMER ACCOUNTS AS OF 1800 HOURS ON JUNE 1

Account status codes: N=new, J=joint, I=inactive

NAME       ACC#   CHECKING   SAVINGS    STATUS

Jones, Q.  223    $ 2234.00  $ 1088.19  N, J
Smith, T.  111    $  110.23  ---------  I
Harris, V.  44    $44000.00  $22222.22  ------

-12 is not a valid number of children.
Please enter this number again.

import java.util.Scanner;
public class IncomeStatistics {
  final static int LOW_END = 10;    // low end of incomes
  final static int HIGH_END = 100;  // high end of incomes
  final static int TABLE_SIZE = HIGH_END - LOW_END + 1;

  int[] incomeData;    // used to store the income data,
      // incomeData[G] stores the total number of
      // people that fall into the G-thousand-dollar
      // group

  public IncomeStatistics() {
    incomeData = new int[TABLE_SIZE];
  }  // end constructor

  public void readData() {
  // -----------------------------------------------------
  // Reads and organizes income statistics.
  // Precondition: The calling code gives directions and
  // prompts the user. Input data is error-free, and each
  // input line is in the form G N, where N is the number of
  // people with an income in the G-thousand-dollar group
  // and LOW_END <= G <= HIGH_END. An input line with values
  // of zero for both G and N terminates the input.
  // Postcondition: incomeData[G-LOW_END] = total number of
  // people with an income in the G-thousand-dollar group
  // for each G read. The values read are displayed.
  // -------------------------------------------------------
    int group, number;                       // input values
    Scanner input = new Scanner(System.in);

    for (group = LOW_END; group <= HIGH_END; ++group)  {
      // clear array
      incomeData[index(group)] = 0;
    }  // end for
    group = input.nextInt();
    number = input.nextInt();

    while ((group != 0) || (number != 0)) {
      System.out.println("Income group "+group+" contains " +
                          number + " people.");
      incomeData[index(group)] += number;

      group = input.nextInt();
      number = input.nextInt();
    }  // end while
  }  // end readData

  private int index(int group) {
  // Returns the array index corresponding to group number.
    return group - LOW_END;
  }  // end index

// other methods for class IncomeStatistics would follow

} // end IncomeStatistics

public boolean readData() {
  // -----------------------------------------------------
  // Reads and organizes income statistics.
  // Precondition: The calling code gives directions and
  // prompts the user. Each input line contains exactly two
  // integers in the form G N, where N is the number of
  // people with an income in the G-thousand-dollar group
  // and LOW_END <= G <= HIGH_END. An input line with
  // values of zero for both G and N terminates the input.
  // Postcondition: incomeData[G-LOW_END] = total number
  // of people with an income in the G-thousand-dollar
  // group. The values read are displayed. If either
  // G or N is erroneous (G and N are not both 0, and
  // either G < LOW_END, G > HIGH_END, or N <0),
  // the method prints a message indicating the line
  // will be ignored, sets the return value to false, and
  // continues. In this case, the calling code should take
  // action. The return value is true if the data is error
  // free.
  // -----------------------------------------------------
    int group, number;               // input values
    boolean dataCorrect = true;      // no data error found yet
    Scanner input = new Scanner(System.in);

    for (group = LOW_END; group <= HIGH_END; ++group)  {
        // clear array
        incomeData[index(group)] = 0;
    }  // end for
    group = input.nextInt();
    number = input.nextInt();

    while ((group != 0) || (number != 0)) {
    // Invariant: group and number are not both 0
      System.out.print("Income group "+group+" contains " +
                          number + " people.  ");
      if ((group >= LOW_END) && (group <= HIGH_END) &&
                (number >=0)) {
        incomeData[index(group)] += number;
        System.out.println();
      }
      else {
        System.out.println("Data not valid - ignored.");
        dataCorrect = false;
      } // end if

      group = input.nextInt();
      number = input.nextInt();

      }  // end while
    return dataCorrect;
  }  // end readData

public static int factorial(int n) {
// ---------------------------------------------------
// Computes the factorial of an integer.
// Precondition: n >= 0.
// Postcondition: Returns n * (n-1)*...*1, if n > 0;
// returns 1 if n = 0.
// ----------------------------------------------------
  int result = 1;

  for (int i = n; i > 1; --i) {
    result *= i;
  }  // end for
  return result;
} // end factorial

while (i > 0) {
   statement(s)
}  // end while

while (expression) {
   statement(s)
}  // end while

do {
   statement(s)
}  while (expression);

if (expression) {
   statement(s)
}
else {
  statement(s)
}  // end if

if (condition1) {
   action1
}
else if (condition2) {
   action2
}
else if (condition3) {
  action3
}  // end if

switch (expression) {
  case constant1 : action1; break;
  case constant2 : action2; break;
  case constant3 : action3; break;

}  // end switch

// check values of start and stop before entering loop
for (index = start; index <= stop; ++index) {
  // check values of index and key variables
  // at beginning of iteration
      .
      .
      .

  // check values of index and key variables
  // at end of iteration
}  // end for
// check values of start and stop after exiting loop

// check variables within expression before executing if
if (expression) {
  System.out.println("Value of expression is true");
  . . .
}
else {
  System.out.println("Value of expression is false");
  . . .
}  // end if

// This is point A
System.out.println("At point A method compute:\n" +
                   "x = " + x + ", y = " + y );
