// Search a dictionary for a word by using a recursive
// binary search

  if (the dictionary contains only one page) {
    Scan the page for the word
  }
  else {
    Open the dictionary to a point near the middle
    Determine which half of the dictionary contains the
      word
    if (the word is in the first half of the dictionary) {
      Search the first half of the dictionary for the word
    }
    else {
      Search the second half of the dictionary for the word
    }  // end if
  }  // end if

search(in theDictionary:Dictionary, in aWord: string)

  if (theDictionary is one page in size) {
    Scan the page for aWord
  }
  else {
    Open theDictionary to a point near the middle
    Determine which half of theDictionary contains aWord

    if (aWord is in the first half of theDictionary) {
      search(first half of theDictionary, aWord)
    }
    else {
      search(second half of theDictionary, aWord)
    }  // end if
  }  // end if

public static int fact(int n) {
// ---------------------------------------------------
// Computes the factorial of a nonnegative integer.
// Precondition: n must be greater than or equal to 0.
// Postcondition: Returns the factorial of n.
// ---------------------------------------------------
   if (n == 0) {
     return 1;
   }
   else {
     return n * fact(n-1);
   }  // end if
}  // end fact

System.out.println(fact(3));

  if (n == 0) {
    return 1;
  }
  else {
    return n * fact(n-1);
  }  // end if       A

public static int fact(int n) {
// Precondition: n must be greater than or equal to 0.
// Postcondition: Returns the factorial of n.
  if (n == 0) {
   return 1;
  }
  else { // Invariant: n > 0, so n-1 >= 0.
         // Thus, fact(n-1) returns (n-1)!
     return n * fact(n-1);  // n * (n-1)! is n!
  } // end if
}  // end fact

Write the empty string backward

Strip away the last character

Strip away the first character

writeBackward(in s:string)

   if (the string s is empty) {
     Do nothing -- this is the base case
   }
   else {
     Write the last character of s
     writeBackward(s minus its last character)
  }  // end if

public static void writeBackward(String s) {
// ---------------------------------------------------
// Writes a character string backward.
// Precondition: None.
// Postcondition: The string is written backward
// ---------------------------------------------------
  if (s.length() > 0) {
    // write the last character
    System.out.println(s.substring(s.charAt(s.length()-1)));

    // write the rest of the string backward,
    // s minus the last character
    writeBackward(s.substring(0, s.length()-1));  // Point A
  }  // end if
  // size == 0 is the base case - do nothing
}  // end writeBackward

Strip away the first character

writeBackward1(in s:string)

  if (the string s is empty) {
    Do nothing -- this is the base case
  }
  else {
    Write the first character of s
    writeBackward1(s minus its first character)
  }  // end if

Write the first character of s
Write the rest of s

Write string s minus its first character backward
Write the first character of string s

writeBackward2(in s:string)

  if (the string s is empty) {
     Do nothing -- this is the base case
  }
  else {
     writeBackward2(s minus its first character)
     Write the first character of s
  }  // end if

writeBackward(in s:string)

  System.out.println("Enter writeBackward, string: " + s );
  if (the string s is empty) {
    Do nothing -- this is the base case
  }
  else {
    System.out.println("About to write last character of " +
                       "string: " + s);
    Write the last character of s
    writeBackward(s minus its last character)  // Point A
  }  // end if
  System.out.println("Leave writeBackward, string: " + s);

writeBackward2(in s:string)

  System.out.println("Enter writeBackward2, string: " + s);
  if (the string s is empty) {
    Do nothing -- this is the base case
  }
  else {
    writeBackward2(s minus its first character) // Point A
    System.out.println("About to write first character of" +
                       "string: " + s);
    Write the first character of s
  }  // end if
  System.out.println("Leave writeBackward2, string: " + s);

abc(...)

  System.out.println("Calling abc from point A.");
  abc(...)  // this is point A

  System.out.println("Calling abc from point B.");
  abc(... )  // this is point B
