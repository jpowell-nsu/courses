public static int rabbit(int n) {
// ---------------------------------------------------
// Computes a term in the Fibonacci sequence.
// Precondition: n is a positive integer.
// Postcondition: Returns the nth Fibonacci number.
// ---------------------------------------------------
  if (n <= 2) {
     return 1;
  }
  else  { // n > 2, so n-1 > 0 and n-2 > 0
     return rabbit(n-1) + rabbit(n-2);
  }  // end if
}  // end rabbit

public static int c(int n, int k) {
// ---------------------------------------------------
// Computes the number of groups of k out of n things.
// Precondition: n and k are nonnegative integers.
// Postcondition: Returns c(n, k).
// ---------------------------------------------------
  if ( (k == 0) || (k == n) ) {
     return 1;
  }
  else if (k > n) {
     return 0;
  }
  else {
     return c(n-1, k-1) + c(n-1, k);
  }  // end if
}  // end c
