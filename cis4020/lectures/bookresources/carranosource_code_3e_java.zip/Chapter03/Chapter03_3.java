if (anArray has only one item) {
   maxArray(anArray) is the item in anArray
}
else if (anArray has more than one item) {
   maxArray(anArray) is the maximum of
      maxArray(left half of anArray) and
      maxArray(right half of anArray)
}  // end if

search(in theDictionary:Dictionary, in aWord: string)
  if (theDictionary is one page in size) {
    Scan the page for aWord
  }
  else {
    Open theDictionary to a point near the middle
    Determine which half of theDictionary contains
        aWord
    if (aWord is in first half of theDictionary) {
      search(first half of theDictionary, aWord)
    }
    else {
      search(second half of theDictionary, aWord)
    }  // end if
  }  // end if

anArray[0] = anArray[1] = anArray[2] = � � � = anArray[size-1]

binarySearch(in anArray:ArrayType, in value:ItemType)

  if (anArray is of size 1) {
    Determine if anArray's item is equal to value
  }
  else {
    Find the midpoint of anArray
    Determine which half of anArray contains value
    if (value is in the first half of anArray) {
      binarySearch(first half of anArray, value)
    }
    else {
      binarySearch(second half of anArray, value)
    }  // end if
  }  // end if

binarySearch(anArray, first, last, value)

mid = (first + last)/2

binarySearch(anArray, first, mid-1, value)

binarySearch(anArray, mid+1, last, value)

if (value is in the first half of anArray)

if (value < anArray[mid])

public static int binarySearch(int anArray[], int first,
                               int last, int value) {
// Searches the array items anArray[first] through
// anArray[last] for value by using a binary search.
// Precondition: 0 <= first, last <= SIZE-1, where
// SIZE is the maximum size of the array, and
// anArray[first] <= anArray[first+1] <= ... <=
// anArray[last].
// Postcondition: If value is in the array, the method
// returns the index of the array item that equals value;
// otherwise the method returns -1.
  int index;
  if (first > last) {
    index = -1;      // value not in original array
  }
  else {
    // Invariant: If value is in anArray,
    //            anArray[first] <= value <= anArray[last]
    int mid = (first + last)/2;
    if (value == anArray[mid]) {
      index = mid;  // value found at anArray[mid]
    }
    else if (value < anArray[mid]) {
     // point X
      index = binarySearch(anArray, first, mid-1, value);
    }
    else {
     // point Y
      index = binarySearch(anArray, mid+1, last, value);
    }  // end if
  }  // end if

  return index;
}  // end binarySearch

kSmall(k, anArray, first, last) =
                    kth smallest item in anArray[first..last]

kSmall(k, anArray, first, last)
     kSmall(k, anArray, first, pivotIndex-1)
                                 if k < pivotIndex - first + 1
=    p                           if k = pivotIndex - first + 1
     kSmall(k-(pivotIndex-first+1), anArray,
            pivotIndex+1, last) if k > pivotIndex - first + 1

kSmall(in k:integer, in anArray:ArrayType, in first:integer,
       in last:integer)
// Returns the kth smallest value in anArray[first..last].

   Choose a pivot item p from anArray[first..last]
   Partition the items of anArray[first..last] about p
  if (k < pivotIndex - first + 1) {
     return kSmall(k, anArray, first, pivotIndex-1)
  }
  else if (k == pivotIndex - first + 1) {
     return p
  }
  else {
     return kSmall(k-(pivotIndex-first+1), anArray,
                    pivotIndex+1, last)
  }  // end if
