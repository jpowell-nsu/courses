public static void writeBackward(String s, int size) {
  if (size > 0) {
    // write the last character
    System.out.println(s.charAt(size-1));
    // write the rest of the string backward
    writeBackward(s, size-1);
  } // end if
  // size == 0 is the base case - do nothing
} // end writeBackward

public static int iterativeRabbit(int n) {
// Iterative solution to the rabbit problem.
  // initialize base cases:
  int previous = 1;  // initially rabbit(1)
  int current = 1;   // initially rabbit(2)
  int next = 1;      // result when n is 1 or 2

  // compute next rabbit values when n >= 3
  for (int i = 3; i <= n; i++) {
    // current is rabbit(i-1), previous is rabbit(i-2)
    next = current + previous;  // rabbit(i)

    previous = current;         // get ready for
    current = next;             // next iteration
  }  // end for

  return next;
}  // end iterativeRabbit

public static void writeBackward(String s, int size) {
  if (size > 0) {
    // write the last character
    System.out.println(s.substring(size-1, size));
    writeBackward(s, size - 1);      // write rest
  }  // end if
}  // end writeBackward

public static void writeBackward(String s, int size) {
// Iterative version.
   while (size > 0) {
      System.out.println(s.substring(size-1, size));
      --size;
   }  // end while
}  // end writeBackward
