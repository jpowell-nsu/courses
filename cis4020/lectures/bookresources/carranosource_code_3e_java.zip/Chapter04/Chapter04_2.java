aList.createList()
aList.add(0, milk)
aList.add(1, eggs)
aList.add(2, butter)
aList.add(3, apple)
aList.add(4, bread)
aList.add(5, chicken)

aList.add(3, nuts)

+createList()
// Creates an empty list.

+isEmpty():boolean {query}
// Determines whether a list is empty.

+size():integer {query}
// Returns the number of items that are in a list.

+add(in index:integer, in item:ListItemType)
// Inserts item at position index of a list, if
// 0 <= index <= size().
// If index < size(), items are renumbered as
// follows: The item at index becomes the item at
// index+1, the item at index+1 becomes the
// item at index+2, and so on.
// Throws an exception when index is out of range or if
// the item cannot be placed on the list (list full).

+remove(in index:integer)
// Removes the item at position index of a list, if
// 0 <= index < size(). If index < size()-1, items are
// renumbered as follows: The item at index+1 becomes
// the item at index, the item at index+2 becomes the
// item at index+1, and so on.
// Throws an exception when index is out of range or if
// the list is empty.

+removeAll()
// Removes all the items in the list.

+get(index):ListItemType {query}
// Returns the item at position index of a list
// if 0 <= index < size(). The list is
// left unchanged by this operation.
// Throws an exception if index is out of range.

aList.remove(4)

displayList(in aList:List)
// Displays the items on the list aList.

   for (index = 0 through aList.size()-1) {
      dataItem = aList.get(index)
      Display dataItem
   }  // end for

replace(in aList:List, in i:integer,
        in newItem:ListItemType
// Replaces the ith item on the list aList with
// newItem.

   if (i >=0 and i < aList.size()) {
      aList.remove(i)
      aList.add(i, newItem)
   }  // end if

+createSortedList()
// Creates an empty sorted list.

+sortedIsEmpty():boolean {query}
// Determines whether a sorted list is empty.

+sortedSize():integer {query}
// Returns the number of items that are in a sorted list.

+sortedAdd(in item:ListItemType)
// Inserts item into its proper sorted position in a
// sorted list. Throws an exception if the item
// cannot be placed on the list (list full).

+sortedRemove(in item:ListItemType)
// Deletes item from a sorted list.
// Throws an exception if the item is not found.

+sortedGet(in index:integer)
// Returns the item at position index of a
// sorted list, if 0 <= index < sortedSize().
// The list is left unchanged by this operation.
// Throws an exception if the index is out of range.

+locateIndex(in item:ListItemType):integer {query}
// Returns the position where item belongs or
// exists in a sorted list; item and the list are
// unchanged.

listHolidays(in year:integer)
// Displays the dates of all holidays in a given year.

   date = date of first day of year
   while (date is before the first day of year+1) {
      if (date is a holiday) {
         write (date + " is a holiday")
      }  // end if
      date = date of next day
   }  // end while

+firstDay(in year:integer):Date {query}
// Returns the date of the first day of a given year.

+isBefore(in date1:Date,
          in date2:Date) : boolean {query}
// Returns true if date1 is before date2,
// otherwise returns false.

+isHoliday(in aDate:Date) : boolean {query}
// Returns true if date is a holiday,
// otherwise returns false.
+nextDay(in aDate:Date) : Date
// Returns the date of the day after a given date.

listHolidays(in year:integer)
// Displays the dates of all holidays in a given year.

   date = firstDay(year)
   while (isBefore(date, firstDay(year+1))) {
      if (isHoliday(date)) {
         write (date + " is a holiday ")
      }  // end if
      date = nextDay(date)
   }  // end while

+createAppointmentBook()
// Creates an empty appointment book.

+isAppointment(in apptDate:Date,
               in apptTime:Time):boolean {query}
// Returns true if an appointment exists for the date
// and time specified; otherwise returns false.

+makeAppointment(in apptDate:Date, in apptTime:Time,
                 in purpose:string):boolean
// Inserts the appointment for the date, time, and purpose
// specified as long as it does not conflict with an
// existing appointment.
// Returns true if successful, false otherwise.

+cancelAppointment(in apptDate:Date,
                   in apptTime:Time):boolean
// Deletes the appointment for the date and time specified.
// Returns true if successful, false otherwise.

+checkAppointment(in apptDate:Date,
                 in apptTime:Time):string {query}
// Returns the purpose of the appointment at
// the given date/time, if one exists. Otherwise, returns
// null.

// change the date or time of an appointment

read (oldDate, oldTime, newDate, newTime)
// get purpose of appointment
purpose = apptBook.checkAppointment(oldDate, oldTime)
if (purpose exists) {
  // see if new date/time is available
  if (apptBook.isAppointment(newDate, newTime)) {
    // new date/time is booked
    write ("You already have an appointment at " + newTime +
           " on " + newDate)
  }
  else  { // new date/time is available
    apptBook.cancelAppointment(oldDate, oldTime))
    if (apptBook.makeAppointment(newDate, newTime,
        purpose)){
      write ("Your appointment has been rescheduled to" +
              newTime + " on " + newDate)
    }  //end if
  }  // end if
}
else {
  write ("You do not have an appointment at " + oldTime +
         " on " + oldDate)
}  // end if

+insertRecipe(in aRecipe:Recipe)
// Inserts recipe into the database.

+deleteRecipe(in aRecipe:Recipe)
// Deletes recipe from the database.

+retrieveRecipe(in name:string):Recipe {query}
// Retrieves the named recipe from the database.

+getMeasure():Measurement {query}
// Returns the measure.

+setMeasure(in m:Measurement)
// Sets the measure.
+scaleMeasure(in scaleFactor: float):Measurement
// Multiplies measure by a fractional scaleFactor, which
// has no units, and returns the result.

+convertMeasure(in oldUnits:MeasureUnit,
               in newUnits:MeasureUnit):Measurement {query}
// Converts measure from its old units to a measure in
// new units, and returns the result.

addFractions(in first:Fraction, in second:Fraction):Fraction
// Adds two fractions and returns the sum reduced to lowest
// terms.

(aList.createList()).isEmpty() is true

(aList.add(i, x)).get(i) = x

(aList.createList()).size() = 0
(aList.add(i, x)).size() = aList.size() + 1
(aList.remove(i)).size() = aList.size() - 1
(aList.createList()).isEmpty() = true
(aList.add(i, item)).isEmpty() = false
(aList.createList()).remove(i) = error
(aList.add(i, x)).remove(i) = aList
(aList.createList()).get(i) = error
(aList.add(i, x)).get(i) = x
(aList.get(i) = (aList.add(i, x)).get(i+1)
(aList.get(i+1) = (aList.remove(i)).get(i)

0 <= index <= size()

aList.add(0, b)
aList.add(0, a)

(aList.add(0, b)).add(0, a)

tempList.add(0, a)

(tempList.add(0, a)).get(0) = a   by axiom 9

(tempList.add(0, a)).get(1)
   = tempList.get(0)              by axiom 10
   = (aList.add(0, b)).get(0)     by de?nition of tempList
   = b                            by axiom 9
