firstItem = items[0];

public boolean add(Object o);
public boolean contains(Object o);

public class CardCollection
                      implements java.util.Collection {
  ...
  public boolean add(Object o) {
    // implementation of add method
  } // end add

  public boolean contains(Object o) {
    // implementation of contains method
  }  // end contains

  // and so on...
}  // end CardCollection

public interface MyInterface {
  public final int f1 = 0;
  public void method1();
  public int method2(int a, int b);
}  // end MyInterface

class SimpleSphere implements java.lang.Comparable<Object> {

  // same methods as before

  public int compareTo(Object rhs){
  // Compares rhs object with this object
  // Precondition: The object rhs should be a Sphere object
  // Postcondition: If this sphere has the same radius as the
  // rhs sphere, returns zero. If this sphere has a larger
  // radius than the rhs sphere, a positive integer is
  // returned. If this sphere has a smaller radius than the
  // rhs sphere, a negative integer is returned.
  // Throws: ClassCastException if the rhs object is not a
  // Sphere object.

    // Throws ClassCastException if rhs cannot be cast to
    // Sphere
    Sphere other = (Sphere)rhs;

    if (radius == other.radius) {
       return 0;  //Equal
    } else if (radius < other.radius) {
       return -1;
    } else {  // radius > other.radius
        return 1;
    }
  } // end compareTo
} // end SimpleSphere class

public class FullName implements java.lang.Comparable<Object> {
  private String firstName;
  private String lastName;
  public FullName(String first, String last) {
    firstName = first;
    lastName = last;
  } // end constructor

  public int compareTo(Object rhs) {
  // Precondition: The object rhs should be a Fullname object
  // Postcondition: Returns 0 if all fields match
  //    if lastName equals rhs.lastName and
  //    firstName is greater than rhs.firstName.
  // Returns -1 if lastName is less than rhs.lastName or
  //    if lastName equals rhs.lastName and
  //    firstName is less than rhs.firstName
  // Throws: ClassCastException if the rhs object is not a Fullname
  // object.

    // Throws ClassCastException if rhs cannot be cast to Fullname
    FullName other = (FullName)rhs;

    if (lastName.compareTo(((FullName)other).lastName)==0){
      return firstName.compareTo(((FullName)other).firstName);
    }
    else {
      return lastName.compareTo(((FullName)other).lastName);
    } // end if
  } // end compareTo
} // end class FullName

package drawingPackage;

package drawingPackage;
public class Palette {
...

package drawingPackage.shapePackage;

import java.io.*;

import java.io.DataStream;

+createList()
+isEmpty():boolean
+size():integer
+add(in index:integer, in newItem:ListItemType)
+remove(in index:integer)
+removeAll()
+get(in index:integer):ListItemType

private final int MAX_LIST = 100; // max length of list
private int items[MAX_LIST];      // array of list items
private int numItems;             // length of list

public class ListIndexOutOfBoundsException
            extends IndexOutOfBoundsException {
  public ListIndexOutOfBoundsException(String s) {
    super(s);
  }  // end constructor
}  // end ListIndexOutOfBoundsException

public class ListException extends RuntimeException {
  public ListException(String s) {
    super(s);
  }  // end constructor
}  // end ListException

// ********************************************************
// Interface IntegerListInterface for the ADT list.
// *********************************************************
public interface IntegerListInterface {
   public boolean isEmpty();
   // Determines whether a list is empty.
   // Precondition: None.
   // Postcondition: Returns true if the list is empty,
   // otherwise returns false.
   // Throws: None.

   public int size();
   // Determines the length of a list.
   // Precondition: None.
   // Postcondition: Returns the number of items that are
   // currently in the list.
   // Throws: None.

   public void removeAll();
   // Deletes all the items from the list.
   // Precondition: None.
   // Postcondition: The list is empty.
   // Throws: None.

   public void add(int index, int item)
            throws ListIndexOutOfBoundsException,
                   ListException;
   // Adds an item to the list at position index.
   // Precondition: index indicates the position at which
   // the item should be inserted in the list.
   // Postcondition: If insertion is successful, item is
   // at position index in the list, and other items are
   // renumbered accordingly.
   // Throws: ListIndexOutOfBoundsException if index < 0 or
   // index > size().
   // Throws: ListException if item cannot be placed on
   // the list.

   public int get(int index) throws
         ListIndexOutOfBoundsException;
   // Retrieves a list item by position.
   // Precondition: index is the number of the item to be
   // retrieved.
   // Postcondition: If 0 <= index < size(), the item at
   // position index in the list is returned.
   // Throws: ListIndexOutOfBoundsException if index < 0 or
   // index > size()-1.

   public void remove(int index)
               throws ListIndexOutOfBoundsException;
   // Deletes an item from the list at a given position.
   // Precondition: index indicates where the deletion
   // should occur.
   // Postcondition: If 0 <= index < size(), the item at
   // position index in the list is deleted, and other items
   // are renumbered accordingly.
   // Throws: ListIndexOutOfBoundsException if index < 0 or
   // index > size()-1.

} // end IntegerListInterface

// ********************************************************
// Interface ListInterface for the ADT list.
// *********************************************************
public interface ListInterface {
  public boolean isEmpty();
  public int size();
  public void add(int index, Object item)
                  throws ListIndexOutOfBoundsException,
                         ListException;
  public Object get(int index)
                    throws ListIndexOutOfBoundsException;
  public void remove(int index)
                     throws ListIndexOutOfBoundsException;
  public void removeAll();
}  // end ListInterface

// ********************************************************
// Array-based implementation of the ADT list.
// *********************************************************
public class ListArrayBased implements ListInterface {
  private static final int MAX_LIST = 50;
  private Object items[];  // an array of list items
  private int numItems;  // number of items in list

  public ListArrayBased() {
    items = new Object[MAX_LIST];
    numItems = 0;
  }  // end default constructor

  public boolean isEmpty() {
    return (numItems == 0);
  } // end isEmpty

  public int size() {
    return numItems;
  }  // end size

  public void removeAll() {
    // Creates a new array; marks old array for
    // garbage collection.
    items = new Object[MAX_LIST];
    numItems = 0;
  } // end removeAll

  public void add(int index, Object item)
                  throws  ListIndexOutOfBoundsException {
    if (numItems > MAX_LIST) {
      throw new ListException("ListException on add");
    }  // end if
    if (index >= 0 && index <= numItems) {
      // make room for new element by shifting all items at
      // positions >= index toward the end of the
      // list (no shift if index == numItems+1)
      for (int pos = numItems; pos >= index; pos--) {
          items[pos+1] = items[pos];
      } // end for
      // insert new item
      items[index] = item;
      numItems++;
    }
    else {  // index out of range
      throw new ListIndexOutOfBoundsException(
       "ListIndexOutOfBoundsException on add");
    }  // end if
  } //end add

  public Object get(int index)
                    throws ListIndexOutOfBoundsException {
    if (index >= 0 && index < numItems) {
      return items[index];
    }
    else  {  // index out of range
      throw new ListIndexOutOfBoundsException(
        "ListIndexOutOfBoundsException on get");
    }  // end if
  } // end get

  public void remove(int index)
                     throws ListIndexOutOfBoundsException {
    if (index >= 0 && index < numItems) {
      // delete item by shifting all items at
      // positions > index toward the beginning of the list
      // (no shift if index == size)
      for (int pos = index+1; pos <= size(); pos++) {
        items[pos-1] = items[pos];
      }  // end for
      numItems--;
    }
    else {  // index out of range
        throw new ListIndexOutOfBoundsException(
        "ListIndexOutOfBoundsException on remove");
    }  // end if
  } // end remove

}  // end ListArrayBased

static public void main(String args[]) {
   � � �
   ListArrayBased aList = new ListArrayBased();
   String dataItem;

   aList.add(0, "Cathryn");
   � � �
   dataItem = (String)aList.get(0);
   � � �
