Integer intRef;
intRef = new Integer(5);

Integer p, q;
p = new Integer(6);
q = p;

Integer[] scores = new Integer[30];

scores[0] = new Integer(7);
scores[1] = new Integer(9); // and so on ...

public class MyNumber {
  private int num;

  public MyNumber(int n) {
    num = n;
  } // end constructor

  public String toString() {
    return "My number is " + num;
  } // end toString
} // end class MyNumber

MyNumber x = new MyNumber(9);
MyNumber y = new MyNumber(9);
MyNumber z = x;

public void changeNumber(MyNumber n) {
  n = new MyNumber(5);
} // end changeNumber

MyNumber x = new MyNumber(9);
changeNumber(x); // attempts to assign 5 to x
System.out.println(x);

Integer intRef;
intRef = new Integer(5);
intRef = new Integer(5);

final int MAX_SIZE = 50;
double[] myArray = new double[MAX_SIZE];

if (capacityIncrement == 0) {
  capacity *= 2;
}
else {
  capacity += capacityIncrement;
}
// now create a new array using the updated
// capacity value
double [] newArray = new double[capacity];
// copy the contents of the original array
// to the new array
for (int i = 0; i < myArray.length; i++) {
  newArray[i] = myArray[i];
} // end for
// now change the reference to the original array
// to the new array
myArray = newArray;

public class IntegerNode {
  public int item;
  public IntegerNode next;
} // end class IntegerNode

package IntegerList;
class IntegerNode {
  int item;
  IntegerNode next;
} // end class IntegerNode

IntegerNode n1 = new IntegerNode();
IntegerNode n2 = new IntegerNode();
n1.item = 5; // set item in first node
n2.item = 9; // set item in second node
n1.next = n2; // link the nodes

package IntegerList;
class IntegerNode {
  int item;
  IntegerNode next;

  IntegerNode(int newItem) {
    item = newItem;
    next = null;
  } // end constructor
  IntegerNode(int newItem, IntegerNode nextNode) {
    item = newItem;
    next = nextNode;
  } // end constructor
}  // end class IntegerNode

package List;

class Node {
  Object item;
  Node next;

  Node(Object newItem) {
    item = newItem;
    next = null;
  } // end constructor

  Node(Object newItem, Node nextNode) {
    item = newItem;
    next = nextNode;
  } // end constructor
} // end class Node

Node n = new Node(new Integer(6));
Node first = new Node(new Integer(9), n);

Node head = null;

head = new Node(); // Don't really need to use new here
head = null;  // since we lose the new Node object here
