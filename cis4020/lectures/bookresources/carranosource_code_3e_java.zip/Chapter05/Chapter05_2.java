Let a variable curr reference the first node in
  the linked list
while (the curr reference is not null) {
  Display the data portion of the current node
  Set the curr reference to the next field of the
      current node
}  // end while

Node curr = head;

System.out.println(curr.item);

curr = curr.next;

temp = curr.next;
curr = temp;

// Display the data in a linked list that head
// references.
// Loop invariant: curr references the next node to be
// displayed
for (Node curr = head; curr != null; curr = curr.next) {
  System.out.println(curr.item);
} // end for

prev.next = curr.next;

head = head.next;

curr.next = null;
curr = null;

newNode.next = curr;
prev.next = newNode;

newNode = new Node(item);

newNode.next = head;
head = newNode;

newNode.next = curr;
prev.next = newNode;

// determine the point of insertion into a sorted
// linked list
// initialize prev and curr to start the traversal
// from the beginning of the list
prev = null
curr = head

// advance prev and curr as long as
// newValue > the current data item
// Loop invariant: newValue > data items in all
// nodes at and before the node that prev references
while (newValue > curr.item) { // causes a problem!
  prev = curr
  curr = curr.next
}  // end while

while (curr != null && newValue > curr.item)

// determine the point of insertion into a sorted
// linked list
// initialize prev and curr to start the traversal
// from the beginning of the list
prev = null
curr = head

// advance prev and curr as long as newValue > the
// current data item; do not go beyond end of list
// Loop invariant: newValue > data items in all
// nodes at and before the node that prev references
while (curr != null && newValue > curr.item) {
  prev = curr
  curr = curr.next
}  // end while

newNode.next = curr;
prev.next = newNode;

// determine the point of insertion or deletion
// for a sorted linked list
// Loop invariant: newValue > data items in all
// nodes at and before the node that prev references
for ( prev = null, curr = head;
      (curr != null) && (newValue > curr.item);
      prev = curr, curr = curr.next ) {
  // no statements in loop body
} // end for

// determine the point of insertion or deletion
// for a sorted linked list of objects
// Loop invariant: newValue > data items (using
// compareTo method) in all nodes at and before
// the node that prev references
for ( prev = null, curr = head;
      (curr != null ) &&
      (newValue.compareTo(curr.item) > 0);
      prev = curr, curr = curr.next ) {
} // end for

package List;
// ****************************************************
// Interface for the ADT list
// ****************************************************
public interface ListInterface {
  // list operations:
  public boolean isEmpty();
  public int size();
  public void add(int index, Object item)
                         throws ListIndexOutOfBoundsException;
  public void remove(int index)
                         throws ListIndexOutOfBoundsException;
  public Object get(int index)
                         throws ListIndexOutOfBoundsException;
  public void removeAll();
} // end ListInterface

package List;
// ****************************************************
// Reference-based implementation of ADT list.
// ****************************************************
public class ListReferenceBased implements ListInterface {
  // reference to linked list of items
  private Node head;
  private int numItems; // number of items in list

  // definitions of constructors and methods
    . . .

public ListReferenceBased() {
  numItems = 0;
  head = null;
}  // end default constructor

public boolean isEmpty() {
  return numItems == 0;
}  // end isEmpty

public int size() {
  return numItems;
}  // end size

private Node find(int index) {
// --------------------------------------------------
// Locates a specified node in a linked list.
// Precondition: index is the number of the desired
// node. Assumes that 1 <= index <= numItems+1
// Postcondition: Returns a reference to the desired
// node.
// --------------------------------------------------
  Node curr = head;
  for (int skip = 0; skip < index; skip++) {
    curr = curr.next;
  } // end for
  return curr;
} // end find

public Object get(int index)
              throws ListIndexOutOfBoundsException {
  if (index >= 0 && index < numItems) {
    // get reference to node, then data in node
    Node curr = find(index);
    Object dataItem = curr.item;
    return dataItem;
  }
  else {
    throw new ListIndexOutOfBoundsException(
                           "List index out of bounds on get");
  } // end if
} // end get

public void add(int index, Object item)
                throws ListIndexOutOfBoundsException {
  if (index >= 0 && index < numItems+1) {
    if (index == 0) {
      // insert the new node containing item at
      // beginning of list
      Node newNode = new Node(item, head);
      head = newNode;
    }
    else {
      Node prev = find(index-1);

      // insert the new node containing item after
      // the node that prev references
      Node newNode = new Node(item, prev.next);
      prev.next = newNode;
    } // end if
    numItems++;
  }
  else {
    throw new ListIndexOutOfBoundsException(
                           "List index out of bounds on add");
  } // end if
}  // end add

public void remove(int index)
                 throws ListIndexOutOfBoundsException {
  if (index >= 0 && index < numItems) {
    if (index == 0) {
      // delete the first node from the list
      head = head.next;
    }
    else {
      Node prev = find(index-1);
      // delete the node after the node that prev
      // references, save reference to node
      Node curr = prev.next;
      prev.next = curr.next;
    } // end if
    numItems--;
  } // end if
  else {
    throw new ListIndexOutOfBoundsException(
                  "List index out of bounds on remove");
  } // end if
}  // end remove

public void removeAll() {
  // setting head to null causes list to be
  // unreachable and thus marked for garbage
  // collection
  head = null;
  numItems = 0;
} // end removeAll

Write the first node of the list
Write the list minus its first node

private static void writeList(Node nextNode) {
// ---------------------------------------------------------
// Writes a list of objects.
// Precondition: The linked list is referenced by nextNode.
// Postcondition: The list is displayed. The linked list
// and nextNode are unchanged.
// ---------------------------------------------------------
  if (nextNode != null) {
    // write the first data object
    System.out.println(nextNode.item);
    // write the list minus its first node
    writeList(nextNode.next);
  }  // end if
}  // end writeList

Write the last character of string s
Write string s minus its last character backward

Write string s minus its first character backward
Write the first character of string s

Write the last node of the list
Write the list minus its last node backward

Write the list minus its first node backward
Write the first node of the list

private static void writeListBackward2(Node nextNode) {
// ----------------------------------------------------
// Writes a list of objects backwards.
// Precondition: The linked list is referenced by
// nextNode.
// Postcondition: The list is displayed backwards. The
// linked list and nextNode are unchanged.
// ----------------------------------------------------
  if (nextNode != null) {
    // write the list minus its first node backward
    writeListBackward2(nextNode.next);
    // write the data object in the first node
    System.out.println(nextNode.item);
  } // end if
}  // end writeListBackward2

private static Node insertRecursive(Node headNode,
                        java.lang.Comparable newItem) {
  if ( (headNode == null) ||
       (newItem.compareTo(headNode.item) < 0) ) {
    // base case: insert newItem at the beginning of the
    // linked list that nextNode references
    Node newNode = new Node(newItem, headNode);
    headNode = newNode;
  }
  else { //insert into rest of linked list
    Node nextNode = insertRecursive(headNode.next,newItem);
    headNode.next = nextNode;
  } // end if
  return headNode;
}  // end insertRecursive

head = insertRecursive(head, newItem);

head = insertRecursive(head, newItem);

head = insertRecursive(head, newItem);
