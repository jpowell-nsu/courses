waitingList.add(request, waitingList.size()+1);

tail.next = new Node(request, null);

// display the data in a circular linked list;
// list references its last node
if (list != null) {
  // list is not empty
  Node first = list.next; // reference first node

  Node curr = first;        // start at first node
  // Loop invariant: curr references next node to display
  do {
    // write data portion
    System.out.println(curr.item);
    curr = curr.next;      // reference next node
  } while (curr != first);      // list traversed?
}  // end if

prev.next = curr.next;

prev = curr.preceding;

// delete the node that curr references
curr.preceding.next = curr.next;
curr.next.preceding = curr.preceding;

// find the insertion point
curr = listHead.next // reference first node, if any
while (curr != listHead and newName > curr.item) {
  curr = curr.next
} // end while

// insert the new node that newNode references before
// the node referenced by curr
newNode.next = curr;
newNode.preceding = curr.preceding;
curr.preceding = newNode;
newNode.preceding.next = newNode;
