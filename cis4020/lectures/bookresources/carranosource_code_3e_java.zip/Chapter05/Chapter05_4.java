public class Customer {
  private String lastName;
  private String firstName;
  private String phone;

  public Customer(String first, String last, String phone) {
    // to be implemented
    . . .
  } // end constructor

  public String toString() {
    // to be implemented
    . . .
  } // end toString
} // end class Customer

public class StockItem implements java.lang.Comparable {
  private String title;
  private int have, want;
  private ListReferenceBased waitingList;

  // various constructors for StockItem
  . . .
  public void addToWaitingList(String lastName,
                              String firstName, String phone) {
  // add a person to the waiting list
    waitingList.addSorted(
                 new Customer(lastName, firstName, phone);
  } // end addToWaitingList

  public String toString() {
    // for displaying StockItem instances
    . . .
  } // end toString

  public int compareTo(Object rhs) {
  // define how StockItems are compared, only by title
     return title.compareTo(((StockItem)rhs).title);
  } // end compareTo

// mutator and accessor methods for other data fields
  . . .

}  // end class StockItem


SortedList inventory = new SortedList();


try {
  FileOutputStream fos = new
                       FileOutputStream("inventory.dat");
  ObjectOutputStream oos = new ObjectOutputStream(fos);
  oos.writeObject(inventory);
  fos.close();
} // end try
catch (Exception e) {
  System.out.println(e);
} // end catch


ListReferenceBased restoredInventory;
try {
  FileInputStream fis = new
                      FileInputStream("inventory.dat");
  ObjectInputStream ois = new ObjectInputStream(fis);
  Object o = ois.readObject();
  restoredInventory = (ListReferencedBased) o;
  System.out.println(restoredInventory);
} // end try
catch (Exception e) {
  System.out.println(e);
} // end catch
