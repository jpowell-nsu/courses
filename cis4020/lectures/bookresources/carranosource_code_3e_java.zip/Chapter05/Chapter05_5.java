public class MyClass<E> {
  private E theData;
  private int n;

  public MyClass() {
    n = 0;
  } // end constructor

  public MyClass(E initData, int num) {
    n = num;
    theData = initData;
  } // end constructor

  public void setData(E newData) {
    theData = newData;
  } // end setData

  public E getData() {
    return theData;
  } // end get Data

  public int getNum() {
    return n;
  } // end getNum
} // end MyClass

static public void main(String[] args) {
  MyClass<String> a = new MyClass<String>();
  Double d = new Double(6.4);
  MyClass<Double> b = new MyClass<Double>(d, 51);

  a.setData("Sarah");
  System.out.println(a.getData() + ", " + b.getData());
  System.out.println(a.getNum() + ", " + b.getNum());

public interface Iterator<E> {
  boolean hasNext();
    // Returns true if the iteration has more elements.

  E next();
    // Returns the next element in the iteration.

  void remove() throws UnsupportedOperationException,
                       IllegalStateException;
    // Removes from the underlying collection the last
    // element returned by the iterator (optional
    // operation).
} // end Iterator

public interface Iterable<E> {
  Iterator<E> iterator();
  // Returns an iterator over the elements in this collection
} // end Iterable
public interface Collection<E> extends Iterable<E> {
  // Only a portion of the Collection interface is shown here.
  // See the J2SE documentation for a complete listing of
  // methods

  boolean add(E o);
    // Ensures that this collection contains the specified
    // element (optional operation).

  boolean remove(Object o);
    // Removes a single instance of the specified element from
    // this collection, if it is present (optional operation).

  void clear();
    // Removes all of the elements from this collection
    // (optional operation).

  boolean contains(Object o);
    // Returns true if this collection contains the specified
    // element.

  boolean equals(Object o);
    // Compares the specified object with this collection for
    // equality.

  boolean isEmpty()
    // Returns true if this collection contains no elements.

  int size();
    // Returns the number of elements in this collection.

  Object[] toArray();
    //Returns an array containing all of the elements in this
    // collection.
} // end Collection

import java.util.LinkedList;
import java.util.Iterator;

public class TestLinkedList {
  static public void main(String[] args) {
    LinkedList<Integer> myList = new LinkedList<Integer>();

    Iterator iter = myList.iterator();
    if (!iter.hasNext()) {
      System.out.println("The list is empty");
    } // end if

    for (int i=1; i <= 5; i++) {
      myList.add(new Integer(i));
    } // end for

      iter = myList.iterator();
     while (iter.hasNext()) {
       System.out.println(iter.next());
     } // end while
  } // end main
} // end TestLinkedList

public interface ListIterator<E> extends Iterator<E> {

  void add(E o);
    // Inserts the specified element into the list (optional
    // operation).

  boolean hasNext();
    // Returns true if this list iterator has more elements when
    // traversing the list in the forward direction.

  boolean hasPrevious();
    // Returns true if this list iterator has more elements when
    // traversing the list in the reverse direction.
  E next();
    // Returns the next element in the list.

  int nextIndex();
    // Returns the index of the element that would be returned
    // by a subsequent call to next.

  E previous();
    // Returns the previous element in the list.

  int previousIndex();
    // Returns the index of the element that would be returned
    // by a subsequent call to previous.

  void remove();
    // Removes from the list the last element that was
    // returned by next or previous (optional operation).

  void set(E o);
    // Replaces the last element returned by next or previous
    // with the specified element (optional operation).
} // end ListIterator

public interface List<E> extends Collection<E>
  // Only a portion of the List interface is shown here.
  // See the J2SE documentation for a complete listing of
  // methods

  boolean add(E o);
    // Appends the specified element to the end of this list
    // (optional operation).

  void add(int index, E element);
    // Inserts the specified element at the specified position in
    // this list (optional operation).

  void clear();
    // Removes all of the elements from this list (optional
    // operation).

  boolean contains(Object o);
    // Returns true if this list contains the specified element.

  boolean equals(Object o);
    // Compares the specified object with this list for equality.

  E get(int index);
    // Returns the element at the specified position in this
    // list.

  int indexOf(Object o);
    // Returns the index in this list of the first occurrence of
    // the specified element, or -1 if this list does not contain
    // this element.

  boolean isEmpty();
    // Returns true if this list contains no elements.

  Iterator<E> iterator();
    // Returns an iterator over the elements in this list in
    // proper sequence.

  ListIterator<E> listIterator();
    // Returns a list iterator of the elements in this list (in
    // proper sequence).
  ListIterator<E> listIterator(int index);
    // Returns a list iterator of the elements in this list (in
    // proper sequence), starting at the specified position in
    // this list.

  E remove(int index);
    // Removes the element at the specified position in this list 
    // (optional operation).

  boolean remove(Object o);
    // Removes the first occurrence in this list of the specified
    // element (optional operation).

  E set(int index, E element);
    // Replaces the element at the specified position in this
    // list with the specified element (optional operation).

  int size();
    // Returns the number of elements in this list.

  List<E> subList(int fromIndex, int toIndex);
    // Returns a view of the portion of this list between the
    // specified fromIndex, inclusive, and toIndex,
    // exclusive.

  Object[] toArray();
    // Returns an array containing all of the elements in this
    // list in proper sequence.
} // end List

import java.util.ArrayList;
import java.util.Iterator;

public class GroceryList {

  static public void main(String[] args) {
    ArrayList<String> groceryList = new ArrayList<String>();
    Iterator<String> iter;

    groceryList.add("apples");
    groceryList.add("bread");
    groceryList.add("juice");
    groceryList.add("carrots");
    groceryList.add("ice cream");

    System.out.println("Number of items on my grocery list: "
                       + groceryList.size());
    System.out.println("Items are: ");
    iter = groceryList.listIterator();
    while (iter.hasNext()) {
      String nextItem = iter.next();
      System.out.println(groceryList.indexOf(nextItem)+") "
                         + nextItem);
    } // end while

  } // end main

} // end GroceryList

Number of items on my grocery list: 5
Items are:
0) apples
1) bread
2) juice
3) carrots
4) ice cream
