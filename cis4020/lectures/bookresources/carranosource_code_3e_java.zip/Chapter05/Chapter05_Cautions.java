Integer intRef = new Integer(5);
intRef = null;

while (value > curr.item)
  curr = curr.next;

while ((curr != null) && (value > curr.item))
  curr = curr.next;
