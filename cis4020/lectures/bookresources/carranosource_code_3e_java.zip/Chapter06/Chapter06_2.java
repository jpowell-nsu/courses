isId(in w:string):boolean
// Returns true if w is a legal Java identifier;
// otherwise returns false.
  if (w is of length 1)  { // base case
    if (w is a letter) {
      return true
    }
    else {
      return false
    }  // end if
  }
  else if (the last character of w is a letter or a digit) {
    return isId(w minus its last character)  // Point X
  }
  else  {
    return false
  } // end if

isPal(in w:string):boolean
// Returns true if the string w of letters is a palindrome;
// otherwise returns false.

  if (w is the empty string or w is of length 1) {
    return true
  }
  else if (w's first and last characters are the same
           letter) {
    return isPal(w minus its first and last characters)
  }
  else {
    return false
  }  // end if

isAnBn(in w:string):boolean
// Returns true if w is of the form AnBn;
// otherwise returns false.

  if (the length of w is zero) {
    return true
  }
  else if (w begins with the character A and ends with the
           character B) {
    return isAnBn(w minus its first and last characters)
  }
  else {
    return false
  }  // end if

y = x + z * (w/k + z * (7 * 6));

endPre(in first:integer, in second:integer):integer
// Finds the end of a prefix expression, if one exists.
// Precondition: The substring of strExp from index first
// through last contains no blank characters.
// Postcondition: Returns the index of the last character
// in strExp that begins at index first, if one exists, or
// returns -1 if no such prefix expression exists.

  if (first < 0 or first > last) {
     return -1
  }  // end if
  ch = character at position first of strExp
  if (ch is an identifier) {
    // index of last character in simple prefix expression
    return first
  }
  else if (ch is an operator) {
    // find the end of the first prefix expression
    firstEnd = endPre(first + 1, last)            // Point X

    // if the end of the first expression was found
    // find the end of the second prefix expression
    if (firstEnd > -1) {
      return endPre(firstEnd + 1, last)           // Point Y
    }
    else {
      return -1
    }  // end if
  }
  else {
    return -1
  }  // end if

isPre():boolean
// Determines whether the string expression in this class
// is a prefix expression.
// Precondition: The class has a data field strExp that
// has been initialized with a string expression that
// contains no blank characters.
// Postcondition: Returns true if the expression is in
// prefix form; otherwise returns false.

  size = length of expression strExp
  lastChar = endPre(0, size - 1)

  if (lastChar >= 0 and lastChar == size-1) {
    return true
  }
  else {
    return false
  }  // end if

evaluatePrefix(in strExp:string):float
// Evaluates the prefix expression strExp.
// Precondition: strExp is a string consisting of a valid
// prefix expression containing no blanks.
// Postcondition: Returns the value of the prefix
// expression.
  ch = first character of expression strExp
  Delete first character from strExp
  if (ch is an identifier) {
    // base case - single identifier
    return value of the identifier
  }
  else if (ch is an operator named op) {
    operand1 = evaluatePrefix(strExp)
    operand2 = evaluatePrefix(strExp)
    return operand1 op operand2
  } // end if

if (exp is a single letter) {
  return exp
}
else {
  return postfix(prefix1) + postfix(prefix2) + operator

} // end if

convert(in pre:string):string
// Converts a prefix expression pre to postfix form.
// Precondition: The expression in the string pre is a
// valid prefix expression.
// Postcondition: Returns the equivalent postfix expression
// as a string.

  // check the first character of the given string
  ch = first character of pre       // get first character
  Delete first character of pre
  if (ch is a lowercase letter) {   // check character
    // base case - single identifier expression
  return ch as a string
  }
  else  { // ch is an operator
    // do the conversion recursively
    postfix1 = convert(pre)
    postfix2 = convert(pre)
    return postfix1 + postfix2 + ch  // concatenate operator
  }  // end if
