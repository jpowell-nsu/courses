fact(in n:integer):integer

  if (n is 0) {
    return 1
  }
  else {
    return n * fact(n - 1)
  }  // end if

solveTowers(in count:integer, in source:Pole,
            in destination:Pole, in spare:Pole)

  if (count is 1) {
    Move a disk directly from source to destination
  }
  else {
    solveTowers(count-1, source, spare, destination)
    solveTowers(1, source, destination, spare)
    solveTowers(count-1, spare, destination, source)
  }  // end if
