abcc?ddde???ef?fg

abcdefg

// read the line, correcting mistakes along the way
while (not end of line) {
  Read a new character ch
  if (ch is not a '?') {
    Add ch to the ADT
  }
  else {
    Remove from the ADT the item added most recently
  }  // end if
}  // end while

// read the line, correcting mistakes along the way
while (not end of line) {
  Read a new character ch
  if (ch is not a '?') {
    Add ch to the ADT
  }
  else if (the ADT is not empty) {
    Remove from the ADT the item added most recently
  }
  else {
    Ignore the '?'
  }  // end if
}  // end while

// write the line
while (the ADT is not empty) {
  Remove from the ADT the item added most recently
  Write .....Uh-oh!
}  // end while

// write the line in reversed order
while (the ADT is not empty) {
  Retrieve from the ADT the item that was
     added most recently and put it in ch
  Write ch
  Remove from the ADT the item added most recently
}  // end while

+displayBackward(in aStack:Stack)
// Displays the input line in reversed order by
// writing the contents of stack.
        aStack = readAndCorrect()

  while (!aStack.isEmpty()) {
    newChar = aStack.pop()
    Write newChar
  }  // end while

  Advance to new line


+readAndCorrect():Stack
// Reads the input line and returns the corrected
// version as a stack. For each character read,
// either enters it into the stack or, if it
// is '?', corrects the contents of stack.
  aStack.createStack()2
  Read newChar
  while (newChar is not the end-of-line symbol) {
    if (newChar is not '?') {
      aStack.push(newChar)
    }
    else if (!aStack.isEmpty()) {
      oldChar = aStack.pop()
    }  // end if
    Read newChar
  }  // end while
  return aStack

// StackItemType is the type of the items stored in the stack.

+createStack()
// Creates an empty stack.

+isEmpty():boolean {query}
// Determines whether a stack is empty.

+push(in newItem:StackItemType) throws StackException
// Adds newItem to the top of the stack. Throws
// StackException if the insertion is not successful.

+pop():StackItemType throws StackException
// Retrieves and then removes the top of the stack (the
// item that was added most recently). Throws
// StackException if the deletion is not successful.

+popAll()
// Removes all items from the stack.

+peek():StackItemType {query} throws StackException
// Retrieves the top of the stack. That is, peek
// retrieves the item that was added most recently.
// Retrieval does not change the stack. Throws
// StackException if the retrieval is not successful.

(aStack.push(newItem)).pop() = aStack
