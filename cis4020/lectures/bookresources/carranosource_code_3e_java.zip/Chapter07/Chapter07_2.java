abc{defg{ijk}{l{mn}}op}qr

abc{def}}{ghij{kl}m

while (not at the end of the string) {
  if (the next character is a '{') {
    aStack.push('{')
  }
  else if (the character is a '}') {
    openBrace = aStack.pop()
  }  // end if
}  // end while

aStack.createStack()
balancedSoFar = true
i = 0

while (balancedSoFar and i < length of aString) {
  ch = character at position i in aString
  ++i
  // push an open brace
  if (ch is '{') {
    aStack.push('{')
  }
  // close brace
  else if (ch is '}') {
    if (!aStack.isEmpty()) {
      openBrace = aStack.pop()    // pop a matching open brace
    }
    else {                       // no matching open brace
      balancedSoFar = false
    }  // end if
  }  // end if
  // ignore all characters other than braces
}  // end while


if (balancedSoFar and aStack.isEmpty()) {
  aString has balanced braces
}
else {
  aString does not have balanced braces
}  // end if

  // close brace
  else if (ch is '}') {
    if (!aStack.isEmpty()) {
      openBrace = aStack.pop()  // pop open brace
    }
    else {                     // no open brace
      balancedSoFar = false
    }  // end if
  }  // end if

  // close brace
  else if (ch is '}') {
    try {
      // try to pop open brace
      openBrace = aStack.pop()
    }  // end try
    catch (StackException e) {
      balancedSoFar = false  // no open brace
    }  // end catch
  }  // end if

aStack.createStack()

// push the characters before $, that is, the
// characters in w, onto the stack
i = 0
ch = character at position i in aString
while (ch is not '$') {
  aStack.push(ch)
  ++i
  ch = character at position i in aString
}  // end while

// skip the $
++i

// match the reverse of w
inLanguage = true  // assume string is in language
while (inLanguage and i < length of aString) {
  ch = character at position i in aString
  try {
    stackTop = aStack.pop()
    if (stackTop equals ch) {
      ++i  // characters match
    }
    else {
      //  top of stack is not ch (characters do not match)
      inLanguage = false  // reject string
    }  // end if
  }  // end try
  catch (StackException e) {
    // aStack.pop() failed, aStack is empty (first half of
    // string is shorter than second half)
    inLanguage = false
  }  // end catch
}  // end while

if (inLanguage and aStack.isEmpty()) {
   aString is in language
}
else {
   aString is not in language
}  // end if
