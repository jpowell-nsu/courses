public interface StackInterface {
  public boolean isEmpty();
  // Determines whether the stack is empty.
  // Precondition: None.
  // Postcondition: Returns true if the stack is empty;
  // otherwise returns false.

  public void popAll();
  // Removes all the items from the stack.
  // Precondition: None.
  // Postcondition: Stack is empty.

  public void push(Object newItem) throws StackException;
  // Adds an item to the top of a stack.
  // Precondition: newItem is the item to be added.
  // Postcondition: If insertion is successful, newItem
  // is on the top of the stack.
  // Exception: Some implementations may throw
  // StackException when newItem cannot be placed on
  // the stack.

  public Object pop() throws StackException;
  // Removes the top of a stack.
  // Precondition: None.
  // Postcondition: If the stack is not empty, the item
  // that was added most recently is removed from the
  // stack and returned.
  // Exception: Throws StackException if the stack is
  // empty.

  public Object peek() throws StackException;
  // Retrieves the top of a stack.
  // Precondition: None.
  // Postcondition: If the stack is not empty, the item
  // that was added most recently is returned. The
  // stack is unchanged.
  // Exception: Throws StackException if the stack is
  // empty.
}  // end StackInterface

public class StackException
             extends java.lang.RuntimeException {
  public StackException(String s) {
    super(s);
  }  // end constructor
}  // end StackException

public class StackArrayBased implements StackInterface {
  final int MAX_STACK = 50;  // maximum size of stack
  private Object items[];
  private int top;
  public StackArrayBased() {
    items = new Object[MAX_STACK];
    top = -1;
  }  // end default constructor

  public boolean isEmpty() {
    return top < 0;
  }  // end isEmpty

  public boolean isFull() {
    return top == MAX_STACK-1;
  }  // end isFull

  public void push(Object newItem) throws StackException {
    if (!isFull()) {
      items[++top] = newItem;
    }
    else {
      throw new StackException("StackException on " +
                               "push: stack full");
    }  // end if
  }  // end push

  public void popAll() {
    items = new Object[MAX_STACK];
    top = -1;
  }  // end popAll

  public Object pop() throws StackException {
    if (!isEmpty()) {
      return items[top--];
    }
    else {
      throw new StackException("StackException on " +
                               "pop: stack empty");
    }  // end if
  }  // end pop

  public Object peek() throws StackException {
    if (!isEmpty()) {
      return items[top];
    }
    else {
      throw new StackException("Stack exception on " +
                               "peek - stack empty");
    }  // end if
  }  // end peek
}  // end StackArrayBased

public class StackTest {
  public static final int MAX_ITEMS = 15;

  public static void main(String[] args) {
    StackArrayBased stack = new StackArrayBased();
    Integer items[] = new Integer[MAX_ITEMS];
    for (int i=0; i<MAX_ITEMS; i++) {
      items[i] = new Integer(i);
      if (!stack.isFull()) {
        stack.push(items[i]);
      }  // end if
    }  // end for
    while (!stack.isEmpty()) {
      // cast result of pop to Integer
      System.out.println((Integer)(stack.pop()));
    }  // end while
    ...

public class StackReferenceBased
                  implements StackInterface {
  private Node top;

  public StackReferenceBased() {
    top = null;
  }  // end default constructor

  public boolean isEmpty() {
    return top ==  null;
  }  // end isEmpty

  public void push(Object newItem) {
    top = new Node(newItem, top);
  }  // end push

  public Object pop() throws StackException {
    if (!isEmpty()) {
      Node temp = top;
      top = top.next;
      return temp.item;
    }
    else {
      throw new StackException("StackException on " +
                               "pop: stack empty");
    }  // end if
  }  // end pop

  public void popAll() {
    top = null;
  }  // end popAll

  public Object peek() throws StackException {
    if (!isEmpty()) {
      return top.item;
    }
    else {
      throw new StackException("StackException on " +
                               "peek: stack empty");
    }  // end if
  }  // end peek
}  // end StackReferenceBased

public class StackListBased implements StackInterface {
  private ListInterface list;
  public StackListBased() {
    list = new ListReferenceBased();
  }  // end default constructor

  public boolean isEmpty() {
    return list.isEmpty();
  }  // end isEmpty

  public void push(Object newItem) {
    list.add(0, newItem);
  }  // end push

  public Object pop() throws StackException {
    if (!list.isEmpty()) {
      Object temp = list.get(0);
      list.remove(0);
      return temp;
    }
    else {
      throw new StackException("StackException on " +
                               "pop: stack empty");
    }  // end if
  }  // end pop

  public void popAll() {
    list.removeAll();
  }  // end popAll

  public Object peek() throws StackException {
    if (!isEmpty()) {
      return list.get(0);
    }
    else {
      throw new StackException("StackException on " +
                               "peek: stack empty");
    }  // end if
  }  // end peek
}  // end StackListBased

public class Stack<E> extends Vector<E> {

  public Stack()
  // Creates an empty Stack

  public boolean empty()
  // Tests if this stack is empty.

  public E peek() throws EmptyStackException
  // Looks at the object at the top of this stack without
  // removing it from the stack.

  public E pop() throws EmptyStackException
  // Removes the object at the top of this stack and
  // returns that object as the value of this function.

  public E push(E item)
  // Pushes an item onto the top of this stack.

  public int search(Object o)
  // Returns the 1-based position where an object is on this
  // stack. The topmost item on the stack is considered to be
  // at distance 1.

} // end Stack

import java.util.Stack;

public class TestStack {

  static public void main(String[] args) {
    Stack<Integer> aStack = new Stack<Integer>();
    if (aStack.empty()) {
      System.out.println("The stack is empty");
    } // end if
    for (int i = 0; i < 5; i++) {
      aStack.push(i); // With autoboxing, this is the same
                      // as aStack.push(new Integer(i))
    } // end for

    while (!aStack.empty()) {
      System.out.print(aStack.pop()+ " ");
    } // end while
    System.out.println();

  } // end main

} // end TestStack

  The stack is empty
  4 3 2 1 0
