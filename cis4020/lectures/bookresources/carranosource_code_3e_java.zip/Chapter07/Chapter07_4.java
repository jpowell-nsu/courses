for (each character ch in the string) {
  if (ch is an operand) {
    Push value that operand ch represents onto stack
  }
  else {  // ch is an operator named op
    // evaluate and push the result
    operand2 = Pop the top of the stack
    operand1 = Pop the top of the stack
    result = operand1 op operand2
    Push result onto stack
  }  // end if
}  // end for

Initialize postfixExp to the null string
for (each character ch in the infix expression) {
  switch (ch) {
  case ch is an operand:
    Append ch to the end of postfixExp
    break
  case ch is an operator:
    Store ch until you know where to place it
    break
  case ch is '(' or ')':
    Discard ch
    break
  }  // end switch
}  //  end for

for (each character ch in the infix expression) {
  switch (ch) {
    case operand:  // append operand to end of postfixExp
      postfixExp = postfixExp + ch
      break
    case '(':      // save '(' on stack
      aStack.push(ch)
      break
    case ')':      // pop stack until matching '('
      while (top of stack is not '(') {
        postfixExp = postfixExp + aStack.pop()
      }  // end while
      openParen = aStack.pop() // remove the open parenthesis
      break
    case operator:            // process stack operators of
                              // greater precedence
      while ( !aStack.isEmpty() and
              top of stack is not '(' and
              precedence(ch) <= precedence(top of stack) ) {
        postfixExp = postfixExp + aStack.pop()
      }  // end while

      aStack.push(ch)  // save new operator
      break
  }  // end switch
}  // end for
// append to postfixExp the operators remaining in the stack
while (!aStack.isEmpty()) {
   postfixExp = postfixExp + aStack.pop()
}  // end while
