Request is to fly from Providence to San Francisco.
HPAir flies from Providence to San Francisco.

Request is to fly from Philadelphia to Albuquerque.
Sorry. HPAir does not fly from Philadelphia to Albuquerque.

Request is to fly from Salt Lake City to Paris.
Sorry. HPAir does not serve Paris.

aStack.createStack()

aStack.push(originCity)  // push origin city onto stack

while (a sequence of flights from the origin to the
                          destination has not been found){
  if (you need to backtrack from the city on the
         top of the stack) {
      temp = aStack.pop()
  }
  else {
    Select a destination city C for a flight from
    the city on the top of the stack
    aStack.push(C)
  }  // end if
}  // end while

Backtrack from the city on the top of the stack.

aStack.createStack()
Clear marks on all cities
aStack.push(originCity)  // push origin city onto stack
Mark the origin as visited
while (a sequence of flights from the origin to the
                          destination has not been found) {
   // loop invariant: The stack contains a directed path
   // from the origin city at the bottom of the stack to
   // the city at the top of the stack
   if (no flights exist from the city on the
         top of the stack to unvisited cities) {
     temp = aStack.pop()  // backtrack
   }
   else {
      Select an unvisited destination city C for a
        flight from the city on the top of the stack
      aStack.push(C)
      Mark C as visited
   }  // end if
}  // end while

+searchS(in originCity:City, in destinationCity:City)
// Searches for a sequence of flights from
// originCity to destinationCity

  aStack.createStack()
  Clear marks on all cities

  aStack.push(originCity)  // push origin onto stack
  Mark the origin as visited

  while (!aStack.isEmpty() and
          destinationCity is not at the top of the stack) {
    // Loop invariant: The stack contains a directed path
    // from the origin city at the bottom of the stack to
    // the city at the top of the stack
    if (no flights exist from the city on the
            top of the stack to unvisited cities) {
      temp = aStack.pop()  // backtrack
    }
    else {
      Select an unvisited destination city C for a
          flight from the city on the top of the stack
      aStack.push(C)
      Mark C as visited
    }  // end if
  }  // end while

  if (aStack.isEmpty()) {
    return false  // no path exists
  }
  else {
    return true  // path exists
  }  // end if

+createFlightMap()
// Creates an empty flight map.

+readFlightMap(in cityFileName:string,
               in flightFileName:string)
// Reads flight information into the flight map.

+displayFlightMap() {query}
// Displays flight information.

+displayAllCities() {query}
// Displays the names of all cities that HPAir serves.

+displayAdjacentCities(in aCity:City) {query}
// Displays all cities that are adjacent to a given city.

+markVisited(in aCity:City)
// Marks a city as visited.

+unvisitAll()
// Clears marks on all cities.

+isVisited(in aCity:City):boolean {query}
// Determines whether a city was visited.

+insertAdjacent(in aCity:City, in adjCity:City)
// Inserts a city adjacent to another city in a
// flight map.
+getNextCity(in fromCity:City)
// Returns the next unvisited city, if any, that
// is adjacent to a given city.  Returns null if no
// unvisited adjacent city was found.

+isPath(in originCity:City, in destinationCity:City)
// Determines whether a sequence of flights between
// two cities exists.

public boolean isPath(City originCity,
               City destinationCity) {
// ---------------------------------------------------
// Determines whether a sequence of flights between two cities
// exists. Nonrecursive stack version.
// Precondition: originCity and destinationCity are the origin
// and destination cities, respectively.
// Postcondition: Returns true if a sequence of flights exists
// from originCity to destinationCity, otherwise returns
// false. Cities visited during the search are marked as
// visited in the flight map.
// Implementation notes: Uses a stack for the cities of a
// potential path. Calls unvisitAll, markVisited, and
// getNextCity.
// ---------------------------------------------------
  StackReferenceBased stack = new StackReferenceBased();

  City topCity, nextCity;
  unvisitAll();  // clear marks on all cities

  // push origin city onto stack, mark it visited
  stack.push(originCity);
  markVisited(originCity);

  topCity = (City)(stack.peek());
  while (!stack.isEmpty() &&
         (topCity.compareTo(destinationCity) != 0)) {
    // loop invariant: stack contains a directed path
    // from the origin city at the bottom of the stack
    // to the city at the top of the stack

    // find an unvisited city adjacent to the city on
    // the top of the stack
    nextCity = getNextCity(topCity);

    if (nextCity == null) {
      stack.pop();  // no city found; backtrack
    }
    else {                  // visit city
      stack.push(nextCity);
      markVisited(nextCity);
    }  // end if
    topCity = (City)stack.peek();
  }  // end while
  if (stack.isEmpty()) {
    return false;  // no path exists
  }
  else {
    return true;   // path exists
  }  // end if
}  // end isPath

To fly from the origin to the destination:
  Select a city C adjacent to the origin
  Fly from the origin to city C
  if (C is the destination city) {
    Terminate -- the destination is reached
  }
  else {
    Fly from city C to the destination
  }  // end if

+searchR(in originCity:City, in destinationCity:City):boolean
// Searches for a sequence of flights from
// originCity to destinationCity.

  Mark originCity as visited

  if (originCity is destinationCity) {
    Terminate -- the destination is reached
  }
  else {
    for (each unvisited city C adjacent to originCity) {
      searchR(C, destinationCity)
    }  // end for
  }  // end if

public boolean isPath(City originCity,
                      City destinationCity) {
  City  nextCity;
  boolean done;

  // mark the current city as visited
  markVisited(originCity);

  // base case: the destination is reached
  if (originCity.compareTo(destinationCity) == 0) {
    return true;
  }
  else { // try a flight to each unvisited city
    done = false;
    nextCity = getNextCity(originCity);

    while (nextCity != null && !done) {
      done = isPath(nextCity, destinationCity);
      if (!done) {
        nextCity = getNextCity(originCity);
      }  // end if
    }  // end while

    return done;
  }  // end if
}  // end isPath
