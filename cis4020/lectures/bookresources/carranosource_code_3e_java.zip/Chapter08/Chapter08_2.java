// read a string of characters from a
// single line of input into a queue
aQueue.createQueue()
while (not end of line) {
   Read a new character ch
   aQueue.enqueue(ch)
}  // end while

// convert digits in queue aQueue into a decimal integer n

// get first digit, ignoring any leading blanks
do  {
  ch = aQueue.dequeue()
}  while (ch is blank)
// Assertion: ch contains first digit
// compute n from digits in queue
n = 0
done = false
do  {
  n = 10 * n + integer that ch represents
  if (!aQueue.isEmpty()) {
    ch = aQueue.dequeue()
  }
  else {
    done = true
  }  // end if
}  while (!done and ch is a digit)
// Assertion: n is result

+isPal(in str:String):boolean
// Determines whether str is a palindrome.

   // create an empty queue and an empty stack
   aQueue.createQueue()
   aStack.createStack()

   // insert each character of the string into both
   // the queue and the stack
   length = the length of str
   for (i = 1 through length) {
      nextChar = ith character of str
      aQueue.enqueue(nextChar)
      aStack.push(nextChar)
   }  // end for

   // compare the queue characters with the stack
   // characters
   charactersAreEqual = true
   while (aQueue is not empty and charactersAreEqual is true) {
      queueFront = aQueue.dequeue()
      stackTop = aStack.pop()
      if (queueFront not equal to stackTop) {
         charactersAreEqual = false
      }  // end if
   }  // end while
   return charactersAreEqual
