public interface QueueInterface {

  public boolean isEmpty();
  // Determines whether a queue is empty.
  // Precondition: None.
  // Postcondition: Returns true if the queue is empty;
  // otherwise returns false.

  public void enqueue(Object newItem) throws QueueException;
  // Adds an item at the back of a queue.
  // Precondition: newItem is the item to be inserted.
  // Postcondition: If the operation was successful, newItem
  // is at the back of the queue. Some implementations may
  // throw QueueException if newItem cannot be added to the
  // queue.

  public Object dequeue() throws QueueException;
  // Retrieves and removes the front of a queue.
  // Precondition: None.
  // Postcondition: If the queue is not empty, the item
  // that was added to the queue earliest is returned and
  // the item is removed. If the queue is empty, the
  // operation is impossible and QueueException is thrown.

  public void dequeueAll();
  // Removes all items of a queue.
  // Precondition: None.
  // Postcondition: The queue is empty.

  public Object peek() throws QueueException;
  // Retrieves the item at the front of a queue.
  // Precondition: None.
  // Postcondition: If the queue is not empty, the item
  // that was added to the queue earliest is returned.
  // If the queue is empty, the operation is impossible
  // and QueueException is thrown.
}  // end QueueInterface

public class QueueException extends RuntimeException {

  public QueueException(String s) {
    super(s);
  }  // end constructor
}  // end QueueException

public class QueueReferenceBased implements QueueInterface {
  private Node lastNode;

  public QueueReferenceBased() {
    lastNode = null;
  }  // end default constructor

  // queue operations:
  public boolean isEmpty() {
    return lastNode == null;
  }  // end isEmpty

  public void dequeueAll() {
    lastNode = null;
  }  // end dequeueAll

  public void enqueue(Object newItem) {
    Node newNode = new Node(newItem);

    // insert the new node
    if (isEmpty()) {
      // insertion into empty queue
      newNode.next = newNode;
    }
    else {
      // insertion into nonempty queue
      newNode.next = lastNode.next;
      lastNode.next = newNode;
    }  // end if

    lastNode = newNode;  // new node is at back
  }  // end enqueue

  public Object dequeue() throws QueueException {
    if (!isEmpty()) {
      // queue is not empty; remove front
      Node firstNode = lastNode.next;
      if (firstNode == lastNode) { // special case?
        lastNode = null;           // yes, one node in queue
      }
      else {
        lastNode.next = firstNode.next;
      }  // end if
      return firstNode.item;
    }
    else {
      throw new QueueException("QueueException on dequeue:"
                             + "queue empty");
    }  // end if
  }  // end dequeue

  public Object peek() throws QueueException {
    if (!isEmpty()) {
      // queue is not empty; retrieve front
      Node firstNode = lastNode.next;
      return firstNode.item;
    }
    else {
      throw new QueueException("QueueException on peek:"
                             + "queue empty");
    }  // end if
  }  // end peek

} // end QueueReferenceBased

  public class QueueTest {
    public static void main(String[] args) {
      QueueReferenceBased aQueue =
                                new QueueReferenceBased();
      for (int i = 0; i < 9; i++) {
        aQueue.enqueue(new Integer(i));
      }  // end for
      . . .
    }  // end main
  }  // end QueueTest

final int MAX_QUEUE = maximum-size-of-queue;

Object[] items;
int      front;
int      back;

back = (back+1) % MAX_QUEUE;
items[back] = newItem;
++count;

front = (front+1) % MAX_QUEUE;
--count;

public class QueueArrayBased implements QueueInterface {
  private final int MAX_QUEUE = 50; // maximum size of queue
  private Object[] items;
  private int front, back, count;

  public QueueArrayBased() {
    items = new Object[MAX_QUEUE];
    front = 0;
    back = MAX_QUEUE-1;
    count = 0;
  }  // end default constructor

  // queue operations:
  public boolean isEmpty() {
    return count == 0;
  }  // end isEmpty

  public boolean isFull() {
    return count == MAX_QUEUE;
  }  // end isFull

  public void enqueue(Object newItem) throws QueueException {
    if (!isFull()) {
      back = (back+1) % (MAX_QUEUE);
      items[back] = newItem;
      ++count;
    }
    else {
      throw new QueueException("QueueException on enqueue: "
                             + "Queue full");
    }  // end if
  }  // end enqueue
  public Object dequeue() throws QueueException {
    if (!isEmpty()) {
      // queue is not empty; remove front
      Object queueFront = items[front];
      front = (front+1) % (MAX_QUEUE);
      --count;
      return queueFront;
    }
    else {
      throw new QueueException("QueueException on dequeue: "
                             + "Queue empty");
    }  // end if
  }  // end dequeue
  public void dequeueAll() {
    items = new Object[MAX_QUEUE];
    front = 0;
    back = MAX_QUEUE-1;
    count = 0;
  }  // end dequeueAll

  public Object peek() throws QueueException {
    if (!isEmpty()) {
      // queue is not empty; retrieve front
      return items[front];
    }
    else {
      throw new QueueException("Queue exception on peek: " +
                             + "Queue empty");
    }  // end if
  }  // end peek

} // end QueueArrayBased

public class QueueListBased implements QueueInterface {
  private ListInterface aList;

  public QueueListBased() {
    aList = new ListReferenceBased();
  }  // end default constructor

  // queue operations:
  public boolean isEmpty() {
    return aList.isEmpty();
  }  // end isEmpty

  public void enqueue(Object newItem) {
    aList.add(aList.size(), newItem);
  }  // end enqueue

  public Object dequeue() throws QueueException {
    if (!isEmpty()) {
      // queue is not empty; remove front
      Object queueFront = aList.get(0);
      aList.remove(0);
      return queueFront;
    }
    else {
      throw new QueueException("Queue exception on dequeue: "
                             + " queue empty");
    }  // end if
  }  // end dequeue

  public void dequeueAll() {
    aList.removeAll();
  }  // end dequeueAll

  public Object peek() throws QueueException {
    if (!isEmpty()) {
      // queue is not empty; retrieve front
      return aList.get(0);
    }
    else {
      throw new QueueException("Queue exception on peek "
                             + "queue empty");
    }  // end if
  }  // end peek

}  // end QueueListBased

public interface Queue<E> extends Collection<E> {

  E element() throws NoSuchElementException;
    // Retrieves, but does not remove, the head of this queue.
    // If this queue is empty, throws NoSuchElementException.

  boolean offer(E o);
    // Inserts the specified element into this queue, if
    // possible.
  E peek();
    // Retrieves, but does not remove, the head of this queue,
    // returning null if this queue is empty.

  E poll();
    // Retrieves and removes the head of this queue, or null
    // if this queue is empty.

  E remove() throws NoSuchElementException;
    // Retrieves and removes the head of this queue,
    // or throws NoSuchElementException if this queue
    // is empty.
} // end Queue

public interface Deque<E> extends Queue<E>

  // Three methods for adding an element, if no space is
  // available, they throw IllegalStateException.

  boolean add(E e) throws IllegalStateException;
    // Inserts the specified element into the queue
    // represented by this deque (in other words, at the
    // tail of this deque).

  void addFirst(E e) throws IllegalStateException;
    // Inserts the specified element at the front of this
    // deque.

  void addLast(E e) throws IllegalStateException;
    // Inserts the specified element at the end of this deque.

  // These three methods also add an element, but rather than
  // throw an exception, they return true upon success and
  // false if no space is currently available.

  boolean offer(E e)
    // Inserts the specified element into the queue
    // represented by this deque (in other words, at the
    // tail of this deque), returning true upon success and
    // false if no space is currently available.

  boolean offerFirst(E e)
    // Inserts the specified element at the front of this
    // deque, returning true upon success and false if no
    // space is currently available.

  boolean offerLast(E e)
    // Inserts the specified element at the end of this deque,
    // returning true upon success and false if no space is
    // currently available.

  // Three methods for retrieving but not removing an element,
  // if the deque is empty, they throw NoSuchElementException.

  E element() throws NoSuchElementException;
    // Retrieves, but does not remove, the head of the queue
    // represented by this deque (in other words, the first
    // element of this deque).
  E getFirst() throws NoSuchElementException;
    // Retrieves, but does not remove, the first element of
    // this deque.

  E getLast() throws NoSuchElementException;
    // Retrieves, but does not remove, the last element of
    // this deque.

  // These three methods also retrieve but do not removing an
  // element, but if the deque is empty, they return null.

  E peek()
    // Retrieves, but does not remove, the head of the queue
    // represented by this deque (in other words, the first
    // element of this deque).

  E peekFirst()
    // Retrieves, but does not remove, the first element of
    // this deque.

  E peekLast()
    // Retrieves, but does not remove, the last element of
    // this deque.

  // Three methods for retrieving and removing an element,
  // if the deque is empty, they throw NoSuchElementException.

  E remove() throws NoSuchElementException;
    // Retrieves and removes the head of the queue represented
    // by this deque (in other words, the first element of
    // this deque).

  E removeFirst()throws NoSuchElementException;
    // Retrieves and removes the first element of this deque.

  E removeLast()throws NoSuchElementException;
    // Retrieves and removes the last element of this deque.

    // These three methods also retrieve and remove an
    // element, but if the deque is empty, they return null.

  E poll()
    // Retrieves and removes the head of the queue represented
    // by this deque (in other words, the first element of
    // this deque).
  E pollFirst()
    // Retrieves and removes the first element of this deque.

  E pollLast()
    // Retrieves and removes the last element of this deque.

    // Miscellaneous methods

  boolean contains(Object o)
    // Returns true if this deque contains the specified
    // element.

  int size()
    // Returns the number of elements in this deque.
} // end Deque

import java.util.LinkedList;
public class TestQueue {

  static public void main(String[] args) {
    LinkedList<Integer> aQueue = new LinkedList<Integer>();
    boolean ok = true;
    Integer item;
    if (aQueue.isEmpty()) {
      System.out.println("The queue is empty");
    } // end if

    for (int i = 0; i < 5; i++) {
      aQueue.add(i); // With autoboxing, this is the same as
                     // aQueue.add(new Integer(i))
    } // end for

    while (!aQueue.isEmpty()) {
      System.out.print(aQueue.peek()+ " ");
      item = aQueue.remove();
    } // end while
    System.out.println();

  } // end main

} // end TestQueue

The queue is empty
0 1 2 3 4
