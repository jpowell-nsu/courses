// initialize
currentTime = 0
Initialize the line to "no customers"

while (currentTime � time of the final event) {

  if (an arrival event occurs at time currentTime) {
    Process the arrival event
  }  // end if
  if (a departure event occurs at time currentTime) {
    Process the departure event
  }  // end if
  // when an arrival event and departure event
  // occur at the same time, arbitrarily process
  // the arrival event first
  ++currentTime
}  // end while

// initialize the line to "no customers"

while (events remain to be processed) {
  currentTime = time of next event
  if (event is an arrival event) {
    Process the arrival event
  }
  else {
    Process the departure event
  }  // end if
  // when an arrival event and departure event
  // occur at the same time, arbitrarily process
  // the arrival event first
}  // end while

currentTime = time of next event

TO PROCESS AN ARRIVAL EVENT

  // Update the event list
  Delete the arrival event for customer C from
      the event list

  if (new customer C begins transaction immediately) {
    Insert a departure event for customer C into the
        event list (time of event = current time +
        transaction length)
  }  // end if
  if (not at the end of the input file) {
    Read a new arrival event and add it to the event list
        (time of event = time specified in file)
  }  // end if

TO PROCESS A DEPARTURE EVENT

  // Update the line
  Delete the customer at the front of the queue
  if (the queue is not empty) {
     The current front customer begins transaction
  }  // end if

  // Update the event list
  Delete the departure event from the event list
  if (the queue is not empty) {
     Insert into the event list the departure event for
       the customer now at the front of the queue
       (time of event = current time + transaction length)
  }  // end if

+simulate()
// Performs the simulation.

  Create an empty queue bankQueue to represent the bank line
  Create an empty event list eventList

  Get the first arrival event from the input file
  Place the arrival event in the event list

  while (the event list is not empty) {
    newEvent = the first event in the event list

    if (newEvent is an arrival event) {
      processArrival(newEvent, arrivalFile,
                     eventList, bankQueue)
    }
    else {
      processDeparture(newEvent, eventList, bankQueue)
    }  // end if
  }  // end while

+processArrival(in arrivalEvent:Event,
                in arrivalFile:File,
                inout anEventList:EventList,
                inout bankQueue:Queue)
// Processes an arrival event.

  atFront = bankQueue.isEmpty()  // present queue status

  // update the bankQueue by inserting the customer, as
  // described in arrivalEvent, into the queue
  bankQueue.enqueue(arrivalEvent)

  // update the event list
  Delete arrivalEvent from anEventList

  if (atFront) {
    // the line was empty, so new customer is at front
    // of line and begins transaction immediately
    Insert into the anEventList a departure event that
        corresponds to the new customer and has
    currentTime = currentTime + transaction length
  }  // end if

  if (not at end of input file) {
    Get the next arrival event from arrivalFile
    Add the event -- with time as specified in the input
        file -- to anEventList
  }  // end if

+processDeparture(in departureEvent:Event,
                  in anEventList:EventList,
                  inout bankQueue:Queue)
// Processes a departure event.

  // update the line by deleting the front customer
  bankQueue.dequeue()

  // update the event list
  Delete departureEvent from anEventList
  if (!bankQueue.isEmpty())
    // customer at front of line begins transaction
    Insert into anEventList a departure event that
        corresponds to the customer now at the front of the
        line and has currentTime = currentTime
        + transaction length
  }  // end if

+createEventList()
// Creates an empty event list.

+isEmpty():boolean {query}
// Determines whether an event list is empty.

+insert(in anEvent:Event)
// Inserts anEvent into an event list so that events
// are ordered by time. If an arrival event and a
// departure event have the same time, the arrival
// event precedes the departure event.

+delete()
// Deletes the first event from an event list.

+retrieve():Event
// Retrieves the first event in an event list.
