Set the time
Advance the time
Display the time

Set the alarm
Enable the alarm
Sound the alarm
Silence the alarm

public class Sphere {
  private double radius;
  public static final double DEFAULT_RADIUS = 1.0;

  public Sphere() {
    setRadius(DEFAULT_RADIUS);
  } // end default constructor

  public Sphere(double initialRadius) {
    setRadius(initialRadius);
  } // end constructor

  public boolean equals(Object rhs) {
    return ((rhs instanceof Sphere) &&
            (radius == ((Sphere)rhs).radius));
  }  // end equals

  public void setRadius(double newRadius) {
    if (newRadius >= 0.0) {
      radius = newRadius;
    }  // end if
  } // end setRadius

  public double getRadius() {
    return radius;
  } // end getRadius

  public double diameter() {
    return 2.0 * radius;
  } // end diameter

  public double circumference() {
    return Math.PI * diameter();
  } // end circumference

  public double area() {
    return 4.0 * Math.PI * radius * radius;
  } // end area

  public double volume() {
    return (4.0*Math.PI * Math.pow(radius, 3.0)) / 3.0;
  } // end volume

  public void displayStatistics() {
    System.out.println("\nRadius = " + getRadius() +
                  "\nDiameter = " + diameter() +
                 "\nCircumference = " + circumference() +
                 "\nArea = " + area() +
                 "\nVolume = " + volume());
  }  // end displayStatistics
} // end Sphere

public class Ball extends Sphere {
  private String name;  // the ball's name

  // constructors:
  public Ball() {
  // Creates a ball with radius 1.0 and name "unknown."
    setName("unknown");
  }  // end default constructor

  public Ball(double initialRadius, String initialName) {
  // Creates a ball with radius initialRadius and
  // name initialName.
    super(initialRadius);
    setName(initialName);
  }  // end constructor

  // additional or revised operations:
  public boolean equals(Object rhs) {
    return ((rhs instanceof Ball) &&
            (getRadius() == ((Ball)rhs).getRadius()) &&
            (name.compareTo(((Ball)rhs).name)==0) );
  }  // end equals

  public String getName() {
  // Determines the name of a ball.
    return name;
  }  // end getName

  public void setName(String newName) {
  // Sets (alters) the name of an existing ball.
    name = newName;
  }  // end setName

  public void resetBall(double newRadius, String newName) {
  // Sets (alters) the radius and name of an existing
  // ball to newRadius and newName, respectively.
    setRadius(newRadius);
    setName(newName);
  }  // end resetBall

  public void displayStatistics() {
  // Displays the statistics of a ball.
    System.out.print("\nStatistics for a "+ name());
    super.displayStatistics();
  }  // end displayStatistics

}  // end Ball

@Override
public void myMethod() {  }

@Override
public void displayStatistics() {
// Displays the statistics of a ball.
  System.out.print("\nStatistics for a "+ name());
  super.displayStatistics();
} // end displayStatistics

Ball myBall = new Ball(5.0, "Volleyball");

Ball myBall = new Ball();

public static void displayDiameter(Sphere aSphere) {
   System.out.println("The diameter is "
                     + aSphere.diameter() + ".");
}  // end displayDiameter

Sphere mySphere = new Sphere(2.0);
Ball myBall = new Ball(5.0, "Volleyball");

displayDiameter(mySphere);  // mySphere's diameter
displayDiameter(myBall);    // myBall's diameter

public class Pen {
   private Ball point;
   ...
}  // end Pen
