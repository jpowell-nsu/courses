Ball myBall = new Ball(1.25, "golfball");
Sphere mySphere = myBall;
mySphere.displayStatistics();

@Override
public double area() {  // cross-sectional area
   double r = getRadius()
   return Math.PI * r * r;  // Math.PI is a constant
}  // end area

public class Sphere {
   � � �  // everything as before
  public double area() {  // surface area
    return 4.0 * Math.PI * radius * radius;
  }  // end area

  public void displayStatistics() {
    System.out.println("\nRadius = " + getRadius()
               + "\nDiameter = " + diameter()
               + "\nCircumference = " + circumference()
               + "\nArea = " + area()
               + "\nVolume = " + volume());
  }  // end displayStatistics

   � � �
}  // end Sphere

public class Ball extends Sphere {
   � � �  // everything as before, except
          // displayStatistics is omitted 
          // and area is revised:
  @Override
  public double area() {
    double r = getRadius();
    return Math.PI * r * r;
  }  // end area
   � � �
}  // end Ball

public void resetBall(double newRadius, String newName) {
// Sets (alters) the radius and name of an existing
// ball to newRadius and newName, respectively.
  setRadius(newRadius);
  setName(newName);
}  // end resetBall

public void resetBall(double newRadius) {
// Sets (alters) the radius of an existing
// ball to newRadius.
  setRadius(newRadius);
}  // end resetBall

public void resetBall(String newName) {
// Sets (alters) the name of an existing
// ball to newName.
  setName(newName);
}  // end resetBall

+insert()
// Inserts a disc into the player.

+remove()
// Removes a disc from the player.

+play()
// Plays the disc.

+record()
// Record the disc.

+stop()
// Stops playing the disc.

+skipForward()
// Skip ahead to another section of the disc.

+skipBackward()
// Skip back to an earlier section of the disc.

public abstract void record();

public abstract class EquidistantShape {
  private double radius;
  public static final double DEFAULT_RADIUS = 1.0;

  public void setRadius(double newRadius) {
    if (newRadius >= 0.0) {
      radius = newRadius;
    }  // end if
  }  // end setRadius

  public double getRadius() {
    return radius;
  }  // end getRadius

  public abstract double area();
  public abstract void displayStatistics();
}  // end EquidistantShape

public class Sphere extends EquidistantShape {
  public Sphere() {
    setRadius(1.0);
  } // end default constructor

  public Sphere(double initialRadius) {
    setRadius(initialRadius);
  } // end constructor

  // Implementation of abstract methods

  @Override
  public double area() {
    double r = getRadius();
    return 4.0 * Math.PI * r * r;
  } // end area

  @Override 
  public void displayStatistics...
  public void displayStatistics() {
    System.out.println("\nRadius = " + getRadius()
               + "\nDiameter = " + diameter()
               + "\nCircumference = " + circumference()
               + "\nArea = " + area()
               + "\nVolume = " + volume());
  }  // end displayStatistics

  // Remaining methods for class appear here
  � � �

} // end Sphere

StackInterface stack = new StackArrayBased();

StackInterface stack = new StackReferenceBased();

public interface AnimateInterface {
  public void move(int x, int y);
  public void paint();
}  // end AnimateInterface
