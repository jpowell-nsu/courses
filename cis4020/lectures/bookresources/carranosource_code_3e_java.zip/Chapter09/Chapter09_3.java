public class NewClass <T> {

  private int year;
  private T data = null;

  public NewClass() {
    year = 1970;
  }  // end constructor

  public NewClass(T initialData) {
    year = 1970;
    data = initialData;
  }  // end constructor

  public NewClass(T initialData, int year) {
    this.year = year;
    data = initialData;
  }  // end constructor

  public void setData(T newData) {
    data = newData;
  }  // end setData

  public T getData() {
    return data;
  }  // end getData

  public String toString() {
    if (data != null) {
      return data.toString() + ", " + year;
    }
    else {
      return null + ", " + year;
    }  // end if
  }  // end toString
}  // end NewClass

static public void main(String[] args) {
  NewClass<Integer> second = new NewClass<Integer>(15);
  NewClass<String> first = new NewClass<String>("Wally", 2010);

  System.out.println("Contents of first => " + first);
  first.setData("Wood");
  System.out.println("After modifying first => " + first);
  System.out.println("Result of getData on second=> " +
                                            second.getData());

  ...
} // end main

Error: generic array creation
  T[] test = new T[10];

  Vector<T> test = new Vector<T>();
  ArrayList<T> test2 = new ArrayList<T>();

  Error: incompatible types
       found   : NewClass<java.lang.Integer>
       required: NewClass<java.lang.String>
         first = second;

  public void process(NewClass<?> temp) {
    System.out.println("getData() => " + temp.getData());
  }  // end process

public class Book<T, S, R>

// Uses same generic parameters
public class RuleBook<T, S, R> extends Book<T, S, R>

// Specifies actual types for all of the type parameters
public class MyBook extends Book<Integer, String, String>

// Specifies the types for some of the type parameters and adds an
// additional one Q
public class TextBook<T, Q> extends Book<T, String, String>

public interface Registration <T extends Student> {

  public void register(T student, CourseID cid);
  public void drop(T student, CourseID cid);
  ...
}  // end Registration

Registration<Student> students = new Registration<Student>();
Registration<UpgradStudent> ugrads = new Registration<UgradStudent>();
Registration<GradStudent> grads = new Registration<GradStudent>();

Registration<Person> people = new Registration<Person>();

Error: type parameter Person is not within its bound

public void process(ArrayList<?> list)

public void process(ArrayList<? extends Student> stuList)

ArrayList<UgradStudent> ugList =
                                new ArrayList<UgradStudent>();
test1.process(ugList);

ArrayList<Person>pList = new ArrayList<Person>();
test1.process(pList);

Error: process(java.util.ArrayList<? extends Student>) in Test
cannot be applied to (java.util.ArrayList<Person>)

class Student extends Person implements Comparable<Student> {
  protected String id;
  ...

  public int compareTo(Student s) {
    return id.compareTo(s.id);
  } // end compareTo
  ...
} // end Student

import java.util.ArrayList;
class MyList <T extends Comparable<T>> {

  ArrayList<T> list = new ArrayList<T>();

  public void add(T x) {
    ...
    if ((list.get(i)).compareTo(list.get(j)) < 0) {
      ...
    }  // end if
  }  // end add
  ...
}  // end MyList

MyList<Student> it320 = new MyList<Student>();

MyList<UgradStudent> it321 = new MyList<UgradStudent>();

Error: type parameter UgradStudent is not within its bound

  class MyList <T extends Comparable<? super T>>

// ****************************************************
// Interface for the ADT list
// ****************************************************
public interface ListInterface<T> {

    public int size();
    public boolean isEmpty();
    public void removeAll();
    public void add(int index, T item)
                         throws ListIndexOutOfBoundsException;
    public void remove(int index)
                         throws ListIndexOutOfBoundsException;
    public T get(int index)
                         throws ListIndexOutOfBoundsException;
} // end ListInterface

// ****************************************************
// Class Node used in the implementation of ADT list
// ****************************************************
class Node <T> {
  T item;
  Node<T> next;

  public Node(T newItem) {
    item = newItem;
    next = null;
  } // end constructor

  public Node(T newItem, Node<T> nextNode) {
    item = newItem;
    next = nextNode;
  } // end constructor

} // end class Node

// ****************************************************
// Reference-based implementation of ADT list.
// ****************************************************
public class ListReferenceBased<T> implements ListInterface<T> {
  // reference to linked list of items
  private Node<T> head;
  private int numItems; // number of items in list

  public ListReferenceBased() {
    numItems = 0;
    head = null;
  }  // end default constructor

  public boolean isEmpty() {
    return numItems == 0;
  }  // end isEmpty

  public int size() {
    return numItems;
  }  // end size

  private Node<T> find(int index) {
    Node<T> curr = head;
    for (int skip = 1; skip < index; skip++) {
      curr = curr.next;
    } // end for
    return curr;
  } // end find
  // The methods get, add, and remove are omitted here - see
  // Exercise 12.

  public void removeAll() {
    // setting head to null causes list to be
    // unreachable and thus marked for garbage
    // collection
    head = null;
    numItems = 0;
  } // end removeAll
} // end ListReferenceBased

class MyMethods {

  public static <T extends Comparable<? super T>>
         void sort(ArrayList<T> list) {
    // implementation of sort appears here
  } // end sort
} // end MyMethods

class TestMethod {
  public static void main (String[ ] args) {
    ArrayList<String> names = new ArrayList<String>();
    names.add("Janet");
    names.add("Andrew");
    names.add("Sarah");
    . . .
    MyMethods.sort(names);
  }  // end main
}  // end TestMethod
