public interface BasicADTInterface {
  public int size();
  public boolean isEmpty();
  public void removeAll();
}  // end BasicADTInterface

public interface ListInterface<T> extends BasicADTInterface {
  public void add(int index, T item)
         throws ListIndexOutOfBoundsException;
  public T get(int index)
         throws ListIndexOutOfBoundsException;
  public void remove(int index)
         throws ListIndexOutOfBoundsException;
}  // end ListInterface

+createSortedList()
+isEmpty():boolean {query}
+size():integer {query}
+sortedAdd(in newItem:ListItemType) throw ListException
+sortedRemove(in anItem:ListItemType) throw ListException
+removeAll()
+get(in index:integer) throw ListIndexOutOfBoundsException
+locateIndex(in anItem:ListItemType):integer {query}

public interface
       SortedListInterface<T extends Comparable<? super T>>
       extends BasicADTInterface {
  public void sortedAdd(T newItem) throws ListException;
  public T get (int index)
         throws ListIndexOutOfBoundsException;
  public int locateIndex(T anItem);
  public void sortedRemove(T anItem) throws ListException;
}  // end SortedListInterface

public class SortedList<T extends Comparable<? super T>>
       extends ListReferenceBased<T>
       implements SortedListInterface<T> {

  public SortedList() {
    // invokes default constructor of superclass
  }  // end default constructor

  public void sortedAdd(T newItem) {
  // Adds an item to the list.
  // Precondition: None.
  // Postcondition: The item is added to the list in
  // sorted order.
    int newPosition = locateIndex(newItem);
    super.add(newPosition, newItem);
  }  // end sortedAdd

  public void sortedRemove(T anItem) throws ListException {
  // Removes an item from the list.
  // Precondition: None.
  // Postcondition: The item is removed from the list
  // and the sorted order maintained.
    int position = locateIndex(anItem);
    if ((anItem.compareTo(get(position))==0)) {
      super.remove(position);
    }
    else {
      throw new ListException("Sorted remove failed");
    }  // end if
  }  // end sortedRemove

  public int locateIndex(T anItem) {
  // Finds an item in the list.
  // Precondition: None.
  // Postcondition: If the item is in the list, its
  // index position in the list is returned.  If the
  // item is not in the list, the index of where it
  // belongs in the list is returned.
    int index = 0;
    // Loop invariant: anItem belongs after all the
    // elements up to the element referenced by index
    while ( (index < size()) &&
            (anItem.compareTo(get(index)) > 0 ) ) {
      ++index;
    }  // end while
    return index;
  }  // end locateIndex
}  // end SortedList

public void add(int index, T item)
       throws UnsupportedOperationException {
   throw new UnsupportedOperationException();
}

public class SortedList<T extends Comparable<? super T>>
       implements SortedListInterface<T> {
  private ListInterface<T> aList;

// constructors:
  public sortedList() {
    aList = new ListReferenceBased<T>();
  }  // end default constructor

// sorted list operations:
  public boolean isEmpty() {
    // To be implemented in Programming Problem 1
  }  // end isEmpty

  public int size() {
    // To be implemented in Programming Problem 1
  }  // end size

  public void sortedAdd(T newItem) {
    int newPosition = locateIndex(newItem);
    aList.add(newPosition, newItem);
  }  // end sortedAdd

  public void sortedRemove(T anItem) {
    // To be implemented in Programming Problem 1
  }  // end sortedRemove

  public T get(int position) {
    // To be implemented in Programming Problem 1
  }  // end get

  public int locateIndex(T anItem) {
    // To be implemented in Programming Problem 1
  }  // end locateIndex

  public void removeAll() {
    // to be implemented in Programming Problem 1
  } // end removeAll
}  // end SortedList
