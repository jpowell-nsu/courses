public interface ListIterator<E> extends Iterator<E> {

  void add(E o);
  // Inserts the specified element into the list (optional
  // operation). The element is inserted immediately before
  // the next element that would be returned by next, if any,
  // and after the next element that would be returned by
  // previous, if any. (If the list contains no elements, the
  // new element becomes the sole element on the list.) The
  // new element is inserted before the implicit cursor: a
  // subsequent call to next would be unaffected, and a
  // subsequent call to previous would return the new element.

  boolean hasNext();
  // Returns true if this list iterator has more elements when
  // traversing the list in the forward direction.

  boolean hasPrevious();
  // Returns true if this list iterator has more elements when
  // traversing the list in the reverse direction.
 
  E next() throws NoSuchElementException;
  // Returns the next element in the list. Throws
  // NoSuchElementException if the iteration has no next
  // element.

  int nextIndex();
  // Returns the index of the element that would be returned
  // by a subsequent call to next. (Returns list size if the
  // list iterator is at the end of the list.)

  E previous()throws NoSuchElementException;
  // Returns the previous element in the list. This method may
  // be called repeatedly to iterate through the list
  // backwards, or intermixed with calls to next to go back
  // and forth. (Note that alternating calls to next and
  // previous will return the same element repeatedly.) Throws
  // NoSuchElementException if the iteration has no previous
  // element.

  int previousIndex()
  // Returns the index of the element that would be returned
  // by a subsequent call to previous. (Returns -1 if the list
  // iterator is at the beginning of the list.)

  void remove() throws UnsupportedOperationException,
                       IllegalStateException;
  // Removes from the list the last element that was
  // returned by next or previous (optional
  // operation).

  void set(E o) throws UnsupportedOperationException,
                       IllegalStateException;
  // Replaces the last element returned by next or
  // previous with the specified element (optional
  // operation).
} // end ListIterator

public class MyListIterator<T>
       implements java.util.ListIterator<T> {

  private ListInterface<T> list;
  private int cursor;        // location of the cursor in list
  private int lastItemIndex; // index of last item returned
                             // by previous or next

  public MyListIterator(ListInterface<T> list) {
    this.list = list;
    cursor = 0;
    lastItemIndex = -1;
  } // end constructor

  public void add(T item) {
    list.add(cursor+1, item);
    cursor++;
    lastItemIndex = -1;
  } // end add

  public boolean hasNext() {
    return (cursor < list.size());
  } // end hasNext

  public boolean hasPrevious() {
    return (cursor >= 0);
  } // end hasPrevious

  public T next() throws java.util.NoSuchElementException {
    try {
      T item = list.get(cursor + 1);
      lastItemIndex = cursor;
      cursor++;
      return item;
    } // end try
    catch (IndexOutOfBoundsException e){
      throw new java.util.NoSuchElementException();
    } // end catch
  } // end next

  public int nextIndex() {
    return cursor;
  } // end nextIndex

  public T previous()
         throws java.util.NoSuchElementException {
    try {
      T item = list.get(cursor);
      lastItemIndex = cursor;;
      cursor--;
      return item;
    } // end try
    catch(IndexOutOfBoundsException e) {
      throw new java.util.NoSuchElementException();
    } // catch
  } // end previous

  public int previousIndex() {
    return cursor - 1;
  } // end previousIndex

  public void remove() throws  UnsupportedOperationException,
                               IllegalStateException {
    // See Programming Problem 10.
    throw new UnsupportedOperationException();
  } // end remove

  public void set(T item)
        throws UnsupportedOperationException {
    // See Programming Problem 10.
    throw new UnsupportedOperationException();
  } // end set

} // end MyListIterator
