Node curr = head;                        ? 1 assignment
while (curr != null) {                   ? n+1 comparisons
  System.out.println(curr.item);         ? n writes
  curr = curr.next;                      ? n assignments
}  // end while

for (i = 1 through n) {
  for (j = 1 through i) {
    for (k = 1 through 5) {
      Task T
    }  // end for
  }  // end for
}  // end for
