public static <T extends Comparable<? super T>>
       void selectionSort(T[] theArray, int n) {
// ---------------------------------------------------
// Sorts the items in an array into ascending order.
// Precondition: theArray is an array of n items.
// Postcondition: theArray is sorted into
// ascending order.
// Calls: indexOfLargest.
// ---------------------------------------------------
  // last = index of the last item in the subarray of
  //        items yet to be sorted
  // largest = index of the largest item found

  for (int last = n-1; last >= 1; last--) {
    // Invariant: theArray[last+1..n-1] is sorted
    // and > theArray[0..last]

    // select largest item in theArray[0..last]
    int largest = indexOfLargest(theArray, last+1);

    // swap largest item theArray[largest] with
    // theArray[last]
    T temp = theArray[largest];
    theArray[largest] = theArray[last];
    theArray[last] = temp;
  }  // end for
}  // end selectionSort

private static <T extends Comparable<? super T>>
        int indexOfLargest(T[] theArray, int size) {
// ---------------------------------------------------
// Finds the largest item in an array.
// Precondition: theArray is an array of size items;
// size >= 1.
// Postcondition: Returns the index of the largest
// item in the array.
// ---------------------------------------------------
  int indexSoFar = 0; // index of largest item found so far

  // Invariant: theArray[indexSoFar]>=theArray[0..currIndex-1]
  for (int currIndex = 1; currIndex < size; ++currIndex) {
    if (theArray[currIndex].compareTo(theArray[indexSoFar])>0) {
      indexSoFar = currIndex;
    }  // end if
  } // end for

  return indexSoFar;  // index of largest item
}  // end indexOfLargest

public static <T extends Comparable<? super T>>
       void bubbleSort(T[] theArray, int n) {
// ---------------------------------------------------
// Sorts the items in an array into ascending order.
// Precondition: theArray is an array of n items.
// Postcondition: theArray is sorted into ascending
// order.
// ---------------------------------------------------
  boolean sorted = false;  // false when swaps occur

  for (int pass = 1; (pass < n) && !sorted; ++pass) {
    // Invariant: theArray[n+1-pass..n-1] is sorted
    //            and > theArray[0..n-pass]
    sorted = true;  // assume sorted
    for (int index = 0; index < n-pass; ++index) {
      // Invariant: theArray[0..index-1] <= theArray[index]
      int nextIndex = index + 1;
      if (theArray[index].compareTo(theArray[nextIndex]) > 0) {
        // exchange items
        T temp = theArray[index];
        theArray[index] = theArray[nextIndex];
        theArray[nextIndex] = temp;
        sorted = false;  // signal exchange
      }  // end if
    }  // end for

    // Assertion: theArray[0..n-pass-1] < theArray[n-pass]
  }  // end for
}  // end bubbleSort

public static <T extends Comparable<? super T>>
       void insertionSort(T[] theArray, int n) {
// ---------------------------------------------------
// Sorts the items in an array into ascending order.
// Precondition: theArray is an array of n items.
// Postcondition: theArray is sorted into ascending
// order.
// ---------------------------------------------------
  // unsorted = first index of the unsorted region,
  // loc = index of insertion in the sorted region,
  // nextItem = next item in the unsorted region

  // initially, sorted region is theArray[0],
  //          unsorted region is theArray[1..n-1];
  // in general, sorted region is theArray[0..unsorted-1],
  //          unsorted region is theArray[unsorted..n-1]

  for (int unsorted = 1; unsorted < n; ++unsorted) {
    // Invariant: theArray[0..unsorted-1] is sorted

    // find the right position (loc) in
    // theArray[0..unsorted] for theArray[unsorted],
    // which is the first item in the unsorted
    // region; shift, if necessary, to make room
    T nextItem = theArray[unsorted];
    int loc = unsorted;

    while ((loc > 0) &&
           (theArray[loc-1].compareTo(nextItem) > 0)) {
      // shift theArray[loc-1] to the right
      theArray[loc] = theArray[loc-1];
      loc--;
    }  // end while
    // Assertion: theArray[loc] is where nextItem belongs
    // insert nextItem into sorted region
    theArray[loc] = nextItem;
  }  // end for
}  // end insertionSort

+mergesort(inout theArray:ItemArray,
           in first:integer, in last:integer)
// Sorts theArray[first..last] by
//   1. sorting the first half of the array
//   2. sorting the second half of the array
//   3. merging the two sorted halves

  if (first < last) {
    mid = (first + last)/2  // get midpoint
    // sort theArray[first..mid]
    mergesort(theArray, first, mid)
    // sort theArray[mid+1..last]
    mergesort(theArray, mid + 1, last)
    // merge sorted halves theArray[first..mid]
    // and theArray[mid+1..last]
    merge(theArray, first, mid, last)
  }  // end if
  // if first >= last, there is nothing to do

public static<T extends Comparable<? super T>>
       void mergesort(T[ ] theArray) {
// Declare temporary array used for merge, must do
// unchecked cast from Comparable<?>[] to T[]

  T[] tempArray = (T[])new Comparable<?>[theArray.length];
  mergesort(theArray, tempArray, 0, theArray.length - 1 );
} // end mergesort

private static<T extends Comparable<? super T>>
        void merge(T[] theArray, T[] tempArray,
                   int first, int mid, int last) {

// ---------------------------------------------------------
// Merges two sorted array segments theArray[first..mid] and
// theArray[mid+1..last] into one sorted array.
// Precondition: first <= mid <= last. The subarrays
// theArray[first..mid] and theArray[mid+1..last] are
// each sorted in increasing order.
// Postcondition: theArray[first..last] is sorted.
// Implementation note: This method merges the two
// subarrays into a temporary array and copies the result
// into the original array theArray.
// ---------------------------------------------------------

  // initialize the local indexes to indicate the subarrays
  int first1 = first;    // beginning of first subarray
  int last1  = mid;      // end of first subarray
  int first2 = mid + 1;  // beginning of second subarray
  int last2  = last;     // end of second subarray
  // while both subarrays are not empty, copy the
  // smaller item into the temporary array
  int index = first1;    // next available location in
                         // tempArray

  while ((first1 <= last1) && (first2 <= last2)) {
    // Invariant: tempArray[first1..index-1] is in order
    if (theArray[first1].compareTo(theArray[first2])<0) {
      tempArray[index] = theArray[first1];
      first1++;
    }
    else {
      tempArray[index] = theArray[first2];
      first2++;
    }  // end if
    index++;
  }  // end while

  // finish off the nonempty subarray

  // finish off the first subarray, if necessary
  while (first1 <= last1) {
    // Invariant: tempArray[first1..index-1] is in order
    tempArray[index] = theArray[first1];
    first1++;
    index++;
  }  // end while
  // finish off the second subarray, if necessary
  while (first2 <= last2) {
    // Invariant: tempArray[first1..index-1] is in order
    tempArray[index] = theArray[first2];
    first2++;
    index++;
  }  // end while

  // copy the result back into the original array
  for (index = first; index <= last; ++index) {
    theArray[index] = tempArray[index];
  }  // end for
}  // end merge

public static <T extends Comparable<? super T>>
       void mergesort(T[] theArray, T[] tempArray
                      int first, int last) {
// ---------------------------------------------------------
// Sorts the items in an array into ascending order.
// Precondition: theArray[first..last] is an array.
// Postcondition: theArray[first..last] is sorted in
// ascending order.
// Calls: merge.
// ---------------------------------------------------------
  if (first < last) {
    // sort each half
    int mid = (first + last)/2;   // index of midpoint
    // sort left half theArray[first..mid]
    mergesort(theArray, tempArray, first, mid);
    // sort right half theArray[mid+1..last]
    mergesort(theArray, tempArray, mid+1, last);

    // merge the two halves
    merge(theArray, tempArray, first, mid, last);
  }  // end if
}  // end mergesort

Merge sorted halves theArray[first..mid]
    and theArray[mid+1..last]

Choose a pivot item p from theArray[first..last]
Partition the items of theArray[first..last] about p

+quicksort(inout theArray:ItemArray,
          in first:integer, in last:integer)
// Sorts theArray[first..last].

  if (first < last) {
    Choose a pivot item p from theArray[first..last]
    Partition the items of theArray[first..last] about p
    // the partition is theArray[first..pivotIndex..last]

    // sort S1
    quicksort(theArray, first, pivotIndex-1)
    // sort S2
    quicksort(theArray, pivotIndex+1, last)
 }  // end if
 // if first >= last, there is nothing to do

+kSmall(in k:integer, in theArray:ItemArray,
        in first:integer, in last:integer):ItemType
// Returns the kth smallest value in theArray[first..last].

  Choose a pivot item p from theArray[first..last]
  Partition the items of theArray[first..last] about p
  if (k < pivotIndex - first + 1) {
    return kSmall(k, theArray, first, pivotIndex-1)
  }
  else if (k == pivotIndex - first + 1) {
    return p
  }
  else {
    return kSmall(k-(pivotIndex-first+1),
                  theArray, pivotIndex+1, last)
  }  // end if

lastS1 = first
firstUnknown = first + 1

+partition(inout theArray:ItemArray,
           in first:integer, in last:integer)
// Returns the index of the pivot element after
// partitioning theArray[first..last].

  // initialize
  Choose the pivot and swap it with theArray[first]
  p = theArray[first]       // p is the pivot
  lastS1 = first            // set S1 and S2 to empty
  firstUnknown = first + 1  // set unknown region
                            // to theArray[first+1..last]
  // determine the regions S1 and S2
  while (firstUnknown <= last) {
    // consider the placement of the "leftmost"
    // item in the unknown region
    if (theArray[firstUnknown] < p) {
      Move theArray[firstUnknown] into S1
    }
    else {
      Move theArray[firstUnknown] into S2
    }  // end if
  }  // end while
  // place pivot in proper position between
  // S1 and S2, and mark its new location
  Swap theArray[first] with theArray[lastS1]
  return lastS1 // the index of the pivot element

Swap theArray[firstUnknown] with theArray[lastS1+1]
Increment lastS1
Increment firstUnknown

private static <T extends Comparable<? super T>>
         void choosePivot(T[] theArray, int first, int last) {
// ---------------------------------------------------------
// Chooses a pivot for quicksort's partition algorithm and
// swaps it with the first item in an array.
// Precondition: theArray[first..last] where first <= last.
// Postcondition: theArray[first] is the pivot.
// ---------------------------------------------------------
// Implementation left as an exercise.
}  // end choosePivot

private static <T extends Comparable<? super T>>
        int partition(T[] theArray, int first, int last) {
// ---------------------------------------------------------
// Partitions an array for quicksort.
// Precondition: theArray[first..last] where first <= last.
// Postcondition: Returns the index of the pivot element of
// theArray[first..last]. Upon completion of the method,
// this will be the index value lastS1 such that
//    S1 = theArray[first..lastS1-1] <  pivot
//         theArray[lastS1]          == pivot
//    S2 = theArray[lastS1+1..last]  >= pivot
// Calls: choosePivot.
// ---------------------------------------------------------
  // tempItem is used to swap elements in the array
  T tempItem;
  // place pivot in theArray[first]
  choosePivot(theArray, first, last);
  T pivot = theArray[first];   // reference pivot

  // initially, everything but pivot is in unknown
  int lastS1 = first;          // index of last item in S1

  // move one item at a time until unknown region is empty
  // firstUnknown is the index of first item in unknown region

  for (int firstUnknown = first + 1; firstUnknown <= last;
                                    ++firstUnknown) {
    // Invariant: theArray[first+1..lastS1] < pivot
    //            theArray[lastS1+1..firstUnknown-1] >= pivot
    // move item from unknown to proper region
    if (theArray[firstUnknown].compareTo(pivot) < 0) {
      // item from unknown belongs in S1
      ++lastS1;
      tempItem = theArray[firstUnknown];
      theArray[firstUnknown] = theArray[lastS1];
      theArray[lastS1] = tempItem;
    }  // end if
  // else item from unknown belongs in S2
  }  // end for

  // place pivot in proper position and mark its location
  tempItem = theArray[first];
  theArray[first] = theArray[lastS1];
  theArray[lastS1] = tempItem;
  return lastS1;
}  // end partition

public static <T extends Comparable<? super T>>
       void quickSort(T[] theArray, int first, int last) {

// ---------------------------------------------------------
// Sorts the items in an array into ascending order.
// Precondition: theArray[first..last] is an array.
// Postcondition: theArray[first..last] is sorted.
// Calls: partition.
// ---------------------------------------------------------

  int pivotIndex;

  if (first < last) {
    // create the partition: S1, Pivot, S2
    pivotIndex = partition(theArray, first, last);

    // sort regions S1 and S2
    quickSort(theArray, first, pivotIndex-1);
    quickSort(theArray, pivotIndex+1, last);
  }  // end if
}  // end quickSort

+quicksort(inout theArray:ItemArray,
          in first:integer, in last:integer)

  if (first < last) {
    Prepare theArray for recursive calls
    quicksort(S1 region of theArray)
    quicksort(S2 region of theArray)
        }  // end if

mergesort has the general form

+mergesort(inout theArray:ItemArray,
           in first:integer, in last:integer)
  if (first < last) {
    mergesort(Left half of theArray)
    mergesort(Right half of theArray)
    Tidy up array after the recursive calls
  }  // end if

+radixSort(inout theArray:ItemArray,
           in n:integer, in d:integer)
// Sorts n d-digit integers in the array theArray.

  for (j = d down to 1) {
    Initialize 10 groups to empty
    Initialize a counter for each group to 0
    for (i = 0 through n-1) {
      k = jth digit of theArray[i]
      Place theArray[i] at the end of group k
      Increase kth counter by 1
    }  // end for i

    Replace the items in theArray with all the
        items in group 0, followed by all the items
        in group 1, and so on.
  }  // end for j

static <T extends Comparable<? super T>> void sort(List<T> list)
  // Sorts the specified list into ascending order, according
  // to the natural ordering of its elements.

static <T> void sort(List<T> list, Comparator<? super T> c)
  // Sorts the specified list according to the order induced
  // by the specified comparator.

public static void main(String args[]) {
  String[] names = {"Janet", "Michael", "Andrew", "Kate",
                    "Sarah", "Regina", "Rachael", "Allie"};
  List<String> l = Arrays.asList(names);
  Collections.sort(l);
  System.out.println(l);
} // end main

[Allie, Andrew, Janet, Kate, Michael, Rachael, Regina, Sarah]

public interface Comparator<T> {

  int compare(T o1, T o2);
    // Compares its two arguments for order.

  boolean equals(Object obj);
    // Indicates whether some other object is "equal to" this
    // Comparator.
} // end Comparator

class Person implements Serializable {
  private String name;
  private int age;

  public Person(String name, int age) {
    this.name = name;
    this.age = age;
  } // end constructor

  public String getName() {
    return name;
  } // end getName

  public int getAge() {
    return age;
  } // end getAge

  public String toString() {
    return name + " - " + age;
  } // end toString
} //end Person

import java.util.Comparator;
import java.io.Serializable;

class NameComparator implements Comparator<Person>, Serializable {

  public int compare(Person o1, Person o2) {
    // Compares its two arguments for order by name.
    return o1.getName().compareTo(o2.getName());
  } // end compare

  public boolean equals(Object obj) {
    // Simply checks to see if we have the same object
    return this==obj;
  } // end equals

} // end NameComparator

import java.util.Comparator;
import java.io.Serializable;

class AgeComparator implements Comparator<Person>, Serializable {
  public int compare(Person o1, Person o2) {
    // Returns the difference:
    // if positive, age of o1 person is greater than o2 person
    // if zero, the ages are equal
    // if negative, age of o1 person is less than o2 person
    return o1.getAge() - o2.getAge();
  } // end compare

  public boolean equals(Object obj) {
    // Simply checks to see if we have the same object
    return this==obj;
  } // end equals
} // end AgeComparator

public static void main(String args[]) {
  NameComparator nameComp = new NameComparator();
  AgeComparator ageComp = new AgeComparator();

  Person[] p = new Person[5];
  p[0] = new Person("Michael", 45);
  p[1] = new Person("Janet", 39);
  p[2] = new Person("Sarah", 17);
  p[3] = new Person("Kate", 20);
  p[4] = new Person("Andrew", 20);
  List<Person> list = Arrays.asList(p);

  System.out.println("Sorting by age:");
  Collections.sort(list, ageComp);
  System.out.println(list);

  System.out.println("Sorting by name:");
  Collections.sort(list, nameComp);
  System.out.println(list);

  System.out.println("Now sorting by age, after sorting by name:");
  Collections.sort(list, ageComp);
  System.out.println(list);
} // end main

Sorting by age:
[Sarah - 17, Kate - 20, Andrew - 20, Janet - 39, Michael - 45]
Sorting by name:
[Andrew - 20, Janet - 39, Kate - 20, Michael - 45, Sarah - 17]
Now sorting by age, after sorting by name:
[Sarah - 17, Andrew - 20, Kate - 20, Janet - 39, Michael - 45]
