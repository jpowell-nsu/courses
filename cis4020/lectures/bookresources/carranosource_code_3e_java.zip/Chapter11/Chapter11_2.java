+createBinaryTree()
// Creates an empty binary tree.

+createBinaryTree(in rootItem:TreeItemType)
// Creates a one-node binary tree whose root contains
// rootItem.

+makeEmpty()
// Removes all of the nodes from a binary tree, leaving an
// empty tree.

+isEmpty():boolean {query}
// Determines whether a binary tree is empty.

+getRootItem():TreeItemType throws TreeException {query}
// Retrieves the data item in the root of a nonempty
// binary tree. Throws TreeException if the tree is
// empty.

+setRootItem(in rootItem:TreeItemType)
             throws UnsupportedOperationException
// Sets the data item in the root of a binary tree. Throws
// UnsupportedOperationException if the method is not
// implemented.

+createBinaryTree(in rootItem:TreeItemType,
                  in leftTree:BinaryTree,
                  in rightTree:BinaryTree)
// Creates a binary tree whose root contains rootItem and
// has leftTree and rightTree, respectively, as its left
// and right subtrees.

+setRootItem(in newItem:TreeItemType)
// Replaces the data item in the root of a binary tree
// with newItem, if the tree is not empty. If the
// tree is empty, creates a root node whose data item
// is newItem and inserts the new node into the tree.

+attachLeft(in newItem:TreeItemType) throws TreeException
// Attaches a left child containing newItem to the root of
// a binary tree. Throws TreeException if the binary
// tree is empty (no root node to attach to) or a left
// subtree already exists (should explicitly detach it
// first).

+attachRight(in newItem:TreeItemType) throws TreeException
// Attaches a right child containing newItem to the root of
// a binary tree. Throws TreeException if the binary
// tree is empty (no root node to attach to) or a left
// subtree already exists (should explicitly detach it
// first).

+attachLeftSubtree(in leftTree:BinaryTree) throws TreeException
// Attaches leftTree as the left subtree of the
// root of a binary tree and makes leftTree empty
// so that it cannot be used as a reference into this tree.
// Throws TreeException if the binary tree is empty
// (no root node to attach to) or a left subtree already
// exists (should explicitly detach it first).

+attachRightSubtree(in rightTree:BinaryTree) throws TreeException
// Attaches rightTree as the right subtree of the
// root of a binary tree and makes rightTree empty
// so that it cannot be used as a reference into this tree.
// Throws TreeException if the binary tree is empty
// (no root node to attach to) or a right subtree already
// exists (should explicitly detach it first).

+detachLeftSubtree():BinaryTree throws TreeException
// Detaches and returns the left subtree of a binary tree's
// root. Throws TreeException if the binary tree is empty
// (no root node to detach from).

+detachRightSubtree():BinaryTree throws TreeException
// Detaches and returns the right subtree of a binary tree's
// root. Throws TreeException if the binary tree is empty
// (no root node to detach from).

tree1.setRootItem("F")
tree1.attachLeft("G")

tree2.setRootItem("D")
tree2.attachLeftSubtree(tree1)

tree3.setRootItem("B")
tree3.attachLeftSubtree(tree2)
tree3.attachRight("E")

tree4.setRootItem("C")
// tree in Fig 11-6b
binTree.createBinaryTree("A", tree3, tree4)

+traverse(in binTree:BinaryTree)
// Traverses the binary tree binTree.

  if (binTree is not empty) {
    traverse(Left subtree of binTree's root)
    traverse(Right subtree of binTree's root)
  }  // end if

+preorder(in binTree:BinaryTree)
// Traverses the binary tree binTree in preorder.
// Assumes that "visit a node" means to display
// the node's data item.

  if (binTree is not empty) {
    Display the data in the root of binTree
    preorder(Left subtree of binTree's root)
    preorder(Right subtree of binTree's root)
  }  // end if

+inorder(in binTree:BinaryTree)
// Traverses the binary tree binTree in inorder.
// Assumes that "visit a node" means to display
// the node's data item.

  if (binTree is not empty) {
    inorder(Left subtree of binTree's root)
    Display the data in the root of binTree
    inorder(Right subtree of binTree's root)
  }  // end if

+postorder(in binTree:BinaryTree)
// Traverses the binary tree binTree in postorder.
// Assumes that "visit a node" means to display
// the node's data item.

  if (binTree is not empty) {
    postorder(Left subtree of binTree's root)
    postorder(Right subtree of binTree's root)
    Display the data in the root of binTree
  }  // end if

public class TreeNode<T> {
  private T item;             // data item in the tree
  private int leftChild;      // index to left child
  private int rightChild;     // index to right child
  ...
  // constructors and methods appear here
}  // end TreeNode

public class BinaryTreeArrayBased<T> {
  protected final int MAX_NODES = 100;
  protected ArrayList<TreeNode<T>> tree;
  protected int root; // index of tree's root
  protected int free; // index of next unused array
                      // location
  ...
  // constructors and methods
}  // end BinaryTreeArrayBased

class TreeNode<T> {
  T item;
  TreeNode<T> leftChild;
  TreeNode<T> rightChild;
  ...
  // constructors
}  // end TreeNode

public abstract class BinaryTreeBasis<T> {
  protected TreeNode root;
  ...
  // constructors and methods appear here
}  // end BinaryTreeBasis

class TreeNode<T> {
  T item;
  TreeNode<T> leftChild;
  TreeNode<T> rightChild;

  public TreeNode(T newItem) {
  // Initializes tree node with item and no children.
    item = newItem;
    leftChild  = null;
    rightChild = null;
  }  // end constructor

  public TreeNode(T newItem,
                  TreeNode<T> left, TreeNode<T> right) {
  // Initializes tree node with item and
  // the left and right children references.
    item = newItem;
    leftChild  = left;
    rightChild = right;
  }  // end constructor

}  // end TreeNode

public class TreeException extends RuntimeException {
  public TreeException(String s) {
    super(s);
  }  // end constructor
} // end TreeException

public abstract class BinaryTreeBasis<T> {
  protected TreeNode<T> root;

  public BinaryTreeBasis() {
    root = null;
  }  // end default constructor

  public BinaryTreeBasis(T rootItem) {
    root = new TreeNode<T>(rootItem, null, null);
  }  // end constructor

  public boolean isEmpty() {
  // Returns true if the tree is empty, else returns false.
    return root == null;
  }  // end isEmpty

  public void makeEmpty() {
  // Removes all nodes from the tree.
    root = null;
  }  // end makeEmpty

  public T getRootItem() throws TreeException {
  // Returns the item in the tree's root.
    if (root == null) {
      throw new TreeException("TreeException: Empty tree");
    }
    else {
      return root.item;
    }  // end if
  }  // end getRootItem

  public abstract void setRootItem(T newItem);
    // Throws UnsupportedOperationException if operation
    // is not supported.

}  // end BinaryTreeBasis

public class BinaryTree<T> extends BinaryTreeBasis<T> {

  public BinaryTree() {
  }  // end default constructor

  public BinaryTree(T rootItem) {
    super(rootItem);
  }  // end constructor

  public BinaryTree(T rootItem,
                    BinaryTree<T> leftTree,
                    BinaryTree<T> rightTree) {
    root = new TreeNode<T>(rootItem, null, null);
    attachLeftSubtree(leftTree);
    attachRightSubtree(rightTree);
  }  // end constructor

  public void setRootItem(T newItem) {
    if (root != null) {
      root.item = newItem;
    }
    else {
      root = new TreeNode<T>(newItem, null, null);
    }  // end if
  }  // end setRootItem

  public void attachLeft(T newItem) {
    if (!isEmpty() && root.leftChild == null) {
      // assertion: nonempty tree; no left child
      root.leftChild = new TreeNode<T>(newItem, null, null);
    }  // end if
  }  // end attachLeft

  public void attachRight(T newItem) {
    if (!isEmpty() && root.rightChild == null) {
      // assertion: nonempty tree; no right child
      root.rightChild = new TreeNode<T>(newItem, null, null);
    }  // end if
  }  // end attachRight

  public void attachLeftSubtree(BinaryTree<T> leftTree)
                                throws TreeException {
    if (isEmpty()) {
      throw new TreeException("TreeException:  Empty tree");
    }
    else if (root.leftChild != null) {
      // a left subtree already exists; it should have been
      // deleted first
      throw new TreeException("TreeException: " +
                           "Cannot overwrite left subtree");
    }
    else {
      // assertion: nonempty tree; no left child
      root.leftChild = leftTree.root;
      // don't want to leave multiple entry points into
      // our tree
      leftTree.makeEmpty();
    }  // end if
  }  // end attachLeftSubtree

  public void attachRightSubtree(BinaryTree<T> rightTree)
                                 throws TreeException {
    if (isEmpty()) {
      throw new TreeException("TreeException:  Empty tree");
    }
    else if (root.rightChild != null) {
      // a right subtree already exists; it should have been
      // deleted first
      throw new TreeException("TreeException: " +
                          "Cannot overwrite right subtree");
    }
    else {
      // assertion: nonempty tree; no right child
      root.rightChild = rightTree.root;
      // don't want to leave multiple entry points into
      // our tree
      rightTree.makeEmpty();
    }  // end if
  }  // end attachRightSubtree

  protected BinaryTree(TreeNode<T> rootNode) {
    root = rootNode;
  }  // end protected constructor

  public BinaryTree<T> detachLeftSubtree()
                         throws TreeException {
    if (isEmpty()) {
      throw new TreeException("TreeException:  Empty tree");
    }
    else {
      // create a new binary tree that has root's left
      // node as its root
      BinaryTree<T> leftTree;
      leftTree = new BinaryTree<T>(root.leftChild);
      root.leftChild = null;
      return leftTree;
    }  // end if
  }  // end detachLeftSubtree

  public BinaryTree<T> detachRightSubtree()
                         throws TreeException {
    if (isEmpty()) {
      throw new TreeException("TreeException:  Empty tree");
    }
    else {
      BinaryTree <T> rightTree;
      rightTree = new BinaryTree<T>(root.rightChild);
      root.rightChild = null;
      return rightTree;
    }  // end if
  }  // end detachRightSubtree
} // end BinaryTree

BinaryTree<Integer> tree1 = new BinaryTree<Integer>();
BinaryTree<Integer> tree2 = new BinaryTree<Integer>(root2);
BinaryTree<Integer> tree3 = new BinaryTree<Integer>(root3);
BinaryTree<Integer> tree4 = new BinaryTree<Integer>(root4,
                                                tree2, tree3);

leftTree = new BinaryTree<T>(root.leftChild)

void inorder(TreeNode treeNode);

import java.util.LinkedList;
public class TreeIterator<T> implements java.util.Iterator<T> {
  private BinaryTreeBasis<T> binTree;
  private TreeNode<T> currentNode;
  private LinkedList <TreeNode<T>> queue; // from JCF

  public TreeIterator(BinaryTreeBasis<T> bTree) {
    binTree = bTree;
    currentNode = null;
    // empty queue indicates no traversal type currently
    // selected or end of current traversal has been reached
    queue = new LinkedList <TreeNode<T>>();
  }  // end constructor

  public boolean hasNext() {
    return !queue.isEmpty();
  }  // end hasNext

  public T next()
           throws java.util.NoSuchElementException {
      currentNode = queue.remove();
      return currentNode.item;
  }  // end next

  public void remove()
              throws UnsupportedOperationException {
    throw new UnsupportedOperationException();
  }  // end remove

  public void setPreorder() {
    queue.clear();
    preorder(binTree.root);
  }  // setPreOrder

  public void setInorder() {
    queue.clear();
    inorder(binTree.root);
  }  // end setInorder

  public void setPostorder() {
    queue.clear();
    postorder(binTree.root);
  }  // end setPostorder

  private void preorder(TreeNode<T> treeNode) {
    if (treeNode != null) {
      queue.add(treeNode);
      preorder(treeNode.leftChild);
      preorder(treeNode.rightChild);
    } // end if
  }  // end preorder

  private void inorder(TreeNode<T> treeNode) {
    if (treeNode != null) {
      inorder(treeNode.leftChild);
      queue.add(treeNode);
      inorder(treeNode.rightChild);
    } // end if
  }  // end inorder

  private void postorder(TreeNode<T> treeNode) {
    if (treeNode != null) {
      postorder(treeNode.leftChild);
      postorder(treeNode.rightChild);
      queue.add(treeNode);
    } // end if
  }  // end postorder
}  // end TreeIterator

TreeIterator<T> treeIterator = new TreeIterator<T>(tree4);
treeIterator.setPreorder();

System.out.println("Preorder traversal:");
while (treeIterator.hasNext()) {
  System.out.println(treeIterator.next());
}  // end while

public static void main(String[] args) {
  BinaryTree<Integer> tree3 = new BinaryTree<Integer>(70);

  // build the tree in Figure 11-10
  BinaryTree<Integer> tree1 = new BinaryTree<Integer>();
  tree1.setRootItem(40);
  tree1.attachLeft(30);
  tree1.attachRight(50);

  BinaryTree<Integer> tree2 = new BinaryTree<Integer>();
  tree2.setRootItem(20);
  tree2.attachLeft(10);
  tree2.attachRightSubtree(tree1);

  BinaryTree<Integer> binTree =  // tree in Figure 11-10
         new BinaryTree<Integer>(60, tree2, tree3);

  TreeIterator<Integer> btIterator =
         new TreeIterator<Integer>(binTree);
  btIterator.setInorder();

  while (btIterator.hasNext()) {
    System.out.println(btIterator.next());
  }  // end while

  BinaryTree<Integer> leftTree = binTree.detachLeftSubtree();
  TreeIterator<Integer> leftIterator =
                          new TreeIterator<Integer>(leftTree);

  // iterate through the left subtree
  leftIterator.setInorder();
  while (leftIterator.hasNext()) {
    System.out.println(leftIterator.next());
  }  // end while

  // iterate through binTree minus left subtree
  btIterator.setInorder();
  while (btIterator.hasNext()) {
    System.out.println(btIterator.next());
  }  // end while
} // end main

+inorder(in treeNode:TreeNode)
// Recursively traverses a binary tree in inorder.

  if (treeNode != null) {
    inorder(treeNode.leftChild)  // point 1
    queue.enqueue(treeNode)
    inorder(treeNode.rightChild) // point 2
   } // end if

+inorderTraverse(in treeNode:TreeNode)
// Nonrecursively traverses a binary tree in inorder.

  // initialize
  Create an empty stack visitStack
  curr = treeNode          // start at root treeNode
  done = false
  while (!done) {
    if (curr != null) {
      // place reference to node on stack before
      // traversing node's left subtree
      visitStack.push(curr)

      // traverse the left subtree
      curr = curr.leftChild
    }

    else {// backtrack from the empty subtree and visit
          // the node at the top of the stack; however,
          // if the stack is empty, you are done
      if (!visitStack.isEmpty()) {
        curr = visitStack.pop()
        queue.enqueue(curr)

          // traverse the right subtree
          // of the node just visited
          curr = curr.rightChild
      }

      else {
        done = true
      }  // end if
    }  // end if
  }  // end while
