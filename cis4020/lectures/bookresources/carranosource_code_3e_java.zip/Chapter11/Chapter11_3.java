Find the record for the person whose ID number is 123456789

public abstract class KeyedItem<KT extends
                                     Comparable<? super KT>> {
  private KT searchKey;

  public KeyedItem(KT key) {
     searchKey = key;
  }  // end constructor

  public KT getKey() {
    return searchKey;
  } // end getKey
} // end KeyedItem

public class Person extends KeyedItem<String> {
  // inherits method getKey that returns the search key
  private FullName name;
  private String phoneNumber;
  private Address address;

  public Person(String id, FullName name, String phone,
                Address addr) {
    super(id);   // sets the key value to String id
    this.name = name;
    phoneNumber = phone;
    address = addr;
  }  // end constructor

  public String toString() {
    return getKey() + " # " + name;
  } // end toString

  // other methods would appear here
}  // end Person

public class Person extends KeyedItem <Fullname> {
  private String idNumber;
  private String phoneNumber;
  private Address address;

  public Person(String id, Fullname name,
                String phone, Address addr) {
    super(name);
    idNumber = id;
    phoneNumber = phone;
    address = addr;
  } // end constructor
  ...
  // other methods appear here

+insert(in newItem:TreeItemType)
// Inserts newItem into a binary search tree whose items
// have distinct search keys that differ from newItem's
// search key.

+delete(in searchKey:KeyType) throws TreeException
// Deletes from a binary search tree the item whose search
// key equals searchKey. If no such item exists, the
// operation fails and throws TreeException.

+retrieve(in searchKey:KeyType):TreeItemType
// Returns the item in a binary search
// tree whose search key equals searchKey. Returns
// null if no such item exists.

firstRecord = nameTree.retrieve("Karen")

nameTree.insert(secondRecord)

nameTree.delete("Janet")

TreeIterator<Person> nameIterator =
                           new TreeIterator<Person>(nameTree);
nameIterator.setInorder();
System.out.println("Inorder traversal:");
while (nameIterator.hasNext()) {
  System.out.println(nameIterator.next());
}  // end while

+search(in bst:BinarySearchTree, in searchKey:KeyType)
// Searches the binary search tree bst for the item
// whose search key is searchKey.

  if (bst is empty) {
    The desired record is not found
  }
  else if (searchKey == search key of root's item) {
      The desired record is found
  }
  else if (searchKey < search key of root's item) {
      search(Left subtree of bst, searchKey)
  }
  else {
    search(Right subtree of bst, searchKey)
  }  // end if

insertItem(in treeNode:TreeNode, in newItem:TreeItemType)
// Inserts newItem into the binary search tree of
// which treeNode is the root.
  Let parentNode be the parent of the empty subtree
      at which search terminates when it seeks
      newItem's search key

  if (Search terminated at parentNode's left subtree) {
    Set leftChild of parentNode to reference newItem
  }
  else {
    Set rightChild of parentNode to reference newItem
  }  // end if

+insertItem(in treeNode:TreeNode, in newItem:TreeItemType)
// Inserts newItem into the binary search tree of
// which treeNode is the root.
  if (treeNode is null) {
    Create a new node and let treeNode reference it
    Create a new node with newItem as the data portion
    Set the references in the new node to null
  }

  else if (newItem.getKey() < treeNode.item.getKey()) {
    treeNode.leftChild = insertItem(treeNode.leftChild, newItem)
  }
  else {
    treeNode.rightChild = insertItem(treeNode.rightChild, newItem)
  }  // end if

  return treeNode

insertItem(treeNode.leftChild, newItem)

insertItem(treeNode.rightChild, newItem)

+deleteItem(in rootNode:TreeNode, in searchKey:KeyType)
// Deletes from the binary search tree (with root
// rootNode) the item whose search key equals
// searchKey. If no such item exists, the operation
// fails and throws TreeException.
  Locate (by using the search algorithm) the item i
      whose search key equals searchKey

  if (item i is found) {
    Remove item i from the tree
  }
  else {
    throw a tree exception
  }  // end if

Remove item i from the tree

nameTree.delete(searchKey)

+deleteItem(in rootNode:TreeNode, in searchKey:KeyType)
// Deletes from the binary search tree (with root rootNode)
// the item whose search key equals searchKey. If no such
// item exists, the operation fails and throws TreeException.

  Locate (by using the search algorithm) the
     item whose search key equals searchKey; it
     occurs in node i
  if (item is found in node i) {
    deleteNode(i)  // defined next
  }
  else {
    throw a tree exception
  }  // end if

+deleteNode(in treeNode:TreeNode):TreeNode
// Deletes the item in treeNode. Returns
// the root node of the resulting tree.

  if (treeNode is a leaf) {
    Remove treeNode from the tree
  }
  else if (treeNode has only one child c) {
    if (c was a left child of its parent p){
      Make c the left child of p
    }
    else {
      Make c the right child of p
    }  // end if
  }
  else { // treeNode has two children
    Find the item contained in treeNode's
        inorder successor
    Copy the item into treeNode
    Remove treeNode's inorder successor by using the
        previous technique for a leaf or a node
        with one child
  }  // end if
  return reference to root node of resulting tree

+deleteItem(in rootNode:TreeNode, in searchKey:KeyType):TreeNode
// Deletes from the binary search tree (with root
// rootNode) the item whose search key equals searchKey.
// Returns the root node of the resulting tree.
// If no such item exists, the operation
// fails and throws TreeException.

  if (rootNode is null) {
    throw TreeException // item not found
  }
  else if (searchKey equals the key in rootNode item) {
    // delete the rootNode; a new root of the tree is
    // returned
     newRoot = deleteNode(rootNode, searchKey)
     return newRoot
  }
  else if (searchKey is less than the key in rootNode item) {
    newLeft = deleteItem(rootNode.leftChild, searchKey)
    rootNode.leftChild = newLeft
    return rootNode // returns rootNode with new left
                    // subtree
  }
  else { // search the right subtree
    newRight = deleteItem(rootNode.rightChild, searchKey)
    rootNode.rightChild = newRight
    return rootNode // returns rootNode with new right
                    // subtree
} // end if

+deleteNode(in treeNode:TreeNode):TreeNode
// Deletes the item in the node referenced by treeNode.
// Returns the root node of the resulting tree.

  if (treeNode is a leaf) {
    // remove leaf from the tree
   return null
  }
  else if (treeNode has only one child c) {
    // c replaces treeNode as the child of
    // treeNode's parent
    if (c is the left child of treeNode) {
      return treeNode.leftChild
    }
    else {
      return treeNode.rightChild
    }  // end if
  }
  else { // treeNode has two children
    // find the inorder successor of the search key in
    // treeNode: it is in the leftmost node of the
    // subtree rooted at treeNode's right child
    replacementItem = findLeftMost(treeNode.rightChild)
    replacementRChild = deleteLeftmost(treeNode.rightChild)
    Set treeNode's item to replacementItem
    Set treeNode's right child to replacementRChild
    return treeNode
  }  // end if

+findLeftmost(in treeNode:TreeNode):TreeNode
// Returns the item that is the leftmost
// descendant of the tree rooted at treeNode.
  if (treeNode.leftChild == null) {
    // this is the node you want, so return its item
    return treeNode.item
  }
  else {
    return findLeftmost(treeNode.leftChild)
  }  // end if

+deleteLeftmost(in treeNode:TreeNode):TreeNode
// Deletes the node that is the leftmost
// descendant of the tree rooted at treeNode.
// Returns subtree of deleted node.

  if (treeNode.leftChild == null) {
    // this is the node you want; it has no left
    // child, but it might have a right subtree

    // the return value of this method is a
    // child reference of treeNode's parent; thus, the
    // following "moves up" treeNode's right subtree
    return treeNode.rightChild
  }
  else {
    replacementLChild = deleteLeftmost(treeNode.leftChild)
    treeNode.leftChild = replacementLChild
    return treeNode
  }  // end if

+search(in bst:BinarySearchTree, in searchKey:KeyType)
// Searches the binary search tree bst for the item
// whose search key is searchKey.

  if (bst is empty) {
    The desired record is not found
  }
  else if (searchKey == search key of bst's root item) {
    The desired record is found
  }
  else if (searchKey < search key of bst's root item) {
    search(Left subtree of bst, searchKey)
  }
  else {
    search(Right subtree of bst, searchKey)
  }  // end if

+retrieveItem(in treeNode:TreeNode,
              in searchKey:KeyType):TreeItemType
// Returns the item (treeItem) whose search
// key equals searchKey from the binary search tree
// that has treeNode as its root. The operation
// returns a null reference if no such item
// exists.

  if (treeNode == null) {
    treeItem = null  // tree is empty
  }
  else if (searchKey == treeNode.item.getKey()) {
    // item is in the root of some subtree
    treeItem = treeNode.item
  }
  else if (searchKey < treeNode.item.getKey()) {
    // search the left subtree
    treeItem =
    retrieveItem(treeNode.leftChild, searchKey)
  }
  else { // search the right subtree
    treeItem =
    retrieveItem(treeNode.rightChild, searchKey)
  }  // end if

  return treeItem

+inorder(in bst:BinarySearchTree)
// Traverses the binary tree bst in inorder.

  if (bst is not empty) {
    inorder(Left subtree of bst's root)
    Process the root of bst
    inorder(Right subtree of bst's root)
  } // end if

import SearchKeys.KeyedItem;

// ADT binary search tree.
//  Assumption: A tree contains at most one item with a
//              given search key at any time.

public class BinarySearchTree<T extends KeyedItem<KT>,
                            KT extends Comparable<? super KT>>
       extends BinaryTreeBasis<T> {
  // inherits isEmpty(), makeEmpty(), getRootItem(), and
  // the use of the constructors from BinaryTreeBasis

  public BinarySearchTree() {
  }  // end default constructor

  public BinarySearchTree(T rootItem) {
    super(rootItem);
  }  // end constructor

  public void setRootItem(T newItem)
              throws UnsupportedOperationException {
    throw new UnsupportedOperationException();
  }  // end setRootItem

  public void insert(T newItem) {
    root = insertItem(root, newItem);
  }  // end insert

  public T retrieve(KT searchKey) {
    return retrieveItem(root, searchKey);
  }  // end retrieve

  public void delete(KT searchKey) throws TreeException {
    root = deleteItem(root, searchKey);
  }  // end delete

  public void delete(T item) throws TreeException {
    root = deleteItem(root, item.getKey());
  }  // end delete

  protected TreeNode<T> insertItem(TreeNode<T> tNode,
                                   T newItem) {
    TreeNode<T> newSubtree;
    if (tNode == null) {
      // position of insertion found; insert after leaf
      // create a new node
      tNode = new TreeNode<T>(newItem, null, null);
      return tNode;
    }  // end if
    T nodeItem = tNode.item;

    // search for the insertion position

    if (newItem.getKey().compareTo(nodeItem.getKey()) < 0) {
      // search the left subtree
      newSubtree = insertItem(tNode.leftChild, newItem);
      tNode.leftChild = newSubtree;
      return tNode;
    }
    else { // search the right subtree
      newSubtree = insertItem(tNode.rightChild, newItem);
      tNode.rightChild = newSubtree;
      return tNode;
    }  // end if
  }  // end insertItem

  protected T retrieveItem(TreeNode<T> tNode,
                           KT searchKey) {
    T treeItem;
    if (tNode == null) {
      treeItem = null;
    }
    else {
      T nodeItem = tNode.item;
      if (searchKey.compareTo(nodeItem.getKey()) == 0) {
        // item is in the root of some subtree
        treeItem = tNode.item;
      }
      else if (searchKey.compareTo(nodeItem.getKey()) < 0) {
        // search the left subtree
        treeItem = retrieveItem(tNode.leftChild, searchKey);
      }
      else { // search the right subtree
        treeItem = retrieveItem(tNode.rightChild, searchKey);
      }  // end if
    }  // end if
    return treeItem;
  }  // end retrieveItem

  protected TreeNode<T> deleteItem(TreeNode<T> tNode,
                                   KT searchKey) {
    // Calls: deleteNode.
    TreeNode<T> newSubtree;
    if (tNode == null) {
      throw new TreeException("TreeException: Item not found");
    }
    else {
      T nodeItem = tNode.item;
      if (searchKey.compareTo(nodeItem.getKey()) == 0) {
        // item is in the root of some subtree
        tNode = deleteNode(tNode);  // delete the item
      }
      // else search for the item
      else if (searchKey.compareTo(nodeItem.getKey()) < 0) {
        // search the left subtree
        newSubtree = deleteItem(tNode.leftChild, searchKey);
        tNode.leftChild = newSubtree;
      }
      else { // search the right subtree
        newSubtree = deleteItem(tNode.rightChild, searchKey);
        tNode.rightChild = newSubtree;
      }  // end if
    }  // end if
    return tNode;
  }  // end deleteItem

  protected TreeNode<T> deleteNode(TreeNode<T> tNode) {
    // Algorithm note: There are four cases to consider:
    //   1. The tNode is a leaf.
    //   2. The tNode has no left child.
    //   3. The tNode has no right child.
    //   4. The tNode has two children.
    // Calls: findLeftmost and deleteLeftmost
    T replacementItem;

    // test for a leaf
    if ( (tNode.leftChild == null) &&
         (tNode.rightChild == null) ) {
      return null;
    }  // end if leaf

    // test for no left child
    else if (tNode.leftChild == null) {
      return tNode.rightChild;
    }  // end if no left child

    // test for no right child
    else if (tNode.rightChild == null) {
      return tNode.leftChild;
    }  // end if no right child

    // there are two children:
    // retrieve and delete the inorder successor
    else {
      replacementItem = findLeftmost(tNode.rightChild);
      tNode.item = replacementItem;
      tNode.rightChild = deleteLeftmost(tNode.rightChild);
      return tNode;
    }  // end if
  }  // end deleteNode

  protected T findLeftmost(TreeNode<T> tNode)  {
    if (tNode.leftChild == null) {
      return tNode.item;
    }
    else {
      return findLeftmost(tNode.leftChild);
    }  // end if
  }  // end findLeftmost

  protected TreeNode<T> deleteLeftmost(TreeNode<T> tNode) {
    if (tNode.leftChild == null) {
      return tNode.rightChild;
    }
    else {
      tNode.leftChild = deleteLeftmost(tNode.leftChild);
      return tNode;
    }  // end if
  }  // end deleteLeftmost

}  // end BinarySearchTree

+treesort(inout anArray:ArrayType, in n:integer)
// Sorts the n integers in array anArray into
// ascending order.

   Insert anArray's elements into a binary search tree
     bTree

   Traverse bTree inorder. As you visit bTree's nodes, copy
     their data items into successive locations of anArray

+readFull(in inputFile:FileType, in n:integer):TreeNode
// Builds a full binary search tree from n sorted values
// in a file and returns the tree's root.

  if (n > 0) {
    treeNode = a new node with null child references
    // construct the left subtree
    Set treeNode's left child to readFull(inputFile, n/2)

    // get the root
    Read item from file into treeNode's item

    // construct the right subtree
    Set treeNode's right child to readFull(inputFile, n/2)
  }  // end if

  return treeNode

+readTree(in inputFile:FileType, in n:integer):TreeNode
// Builds a minimum-height binary search tree from n sorted
// values in a file. Will return the tree's root.

  if (n > 0) {
    treeNode = reference to new node with null
               child references
    // construct the left subtree
    Set treeNode's left child to readTree(inputFile, n/2)

    // get the root
    Read item from file into treeNode's item

    // construct the right subtree
    Set treeNode's right child to
        readTree(inputFile, (n-1)/2)
  }  // end if

  return treeNode

static <T> int
  binarySearch(List<? extends Comparable<? super T>> list, T key)

static <T> int
  binarySearch(List<? extends T> list, T key,
               Comparator<? super T> c)

import java.util.List;
import java.util.LinkedList;
import java.util.Collections;
import java.util.Arrays;

public class JCFSearchEx {
  public static void main(String args[]) {
    String[] names = {"Janet", "Michael", "Pat", "Craig",
                      "Andrew", "Sarah", "Evan", "Anita"};

    LinkedList<String> namelist = new LinkedList<String>();
    namelist.addAll(Arrays.asList(names));
    Collections.sort(namelist);
    String name = "Maite";

    int loc = Collections.binarySearch(namelist, name);
    if (loc < 0) {
      System.out.println(name + " should be inserted to position "
                                  + (-(loc+1)) + "\n");
      namelist.add(-(loc+1), name);
      System.out.println(namelist);
    } else {
      System.out.println(name + " was found in location "
                              + loc + "\n");
    }  // end if
  }  // end main
}  // end JCFSearchEx
