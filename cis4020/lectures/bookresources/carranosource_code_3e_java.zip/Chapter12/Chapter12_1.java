// TableItem type is the type of the items stored in the
// table, KeyType is the type of the search-key value.

+createTable()
// Creates an empty table.

+tableIsEmpty():boolean {query}
// Determines whether a table is empty.

+tableLength():integer {query}
// Determines the number of items in a table.

+tableInsert(in newItem:TableItemType) throws
                                             TableException
// Inserts newItem into a table whose items have distinct
// search keys that differ from newItem's search key.
// Throws TableException if the insertion is not
// successful.

+tableDelete(in searchKey:KeyType)
// Deletes from a table the item whose search key equals
// searchKey. Returns false if no such item exists.
// Returns true if the deletion was successful.

+tableRetrieve(in searchKey:KeyType):TableItemType
// Returns the item in a table whose search
// key equals searchKey. Returns null
// if no such item exists.

+tableTraverse():TableItemType
// Traverses a table in sorted search-key order.

Display all the table items

package SearchKeys;

public abstract class KeyedItem<KT extends
                                    Comparable <? super KT>> {
  private KT searchKey;

  public KeyedItem(KT key) {
    searchKey = key;
  }  // end constructor

  public KT getKey() {
    return searchKey;
  }  // end getKey
}  // end KeyedItem

import SearchKeys.KeyedItem;

public class City extends KeyedItem<String> {
  private String city;      // city's name
  private String country;   // city's country
  private int  pop;         // city's population
  . . .
  // implementation of methods for accessing private
  // data fields
}  // end City

import SearchKeys.KeyedItem;

public class City extends KeyedItem<String> {
  // city's name will be designated as search key
  private String country;  // city's country
  private int  pop;        // city's population

  public City(String theCity, String theCountry,
              int newPop) {
    super(theCity); // makes city name the search key
    country = theCountry;
    pop = newPop;
  }  // end constructor

  public String toString() {
    return getKey() + ", " + country + "  " + pop;
  }  // end toString

  // The methods getCountry, setCountry, getPopulation,
  // and setPopulation appear here.

  ...

}  // end City

+displayItem(in anItem:TableItemType)

  Display anItem.getCity()
  Display anItem.getPopulation()

+updatePopulation(in anItem:TableItemType)

  anItem.setPopulation(1.1 * anItem.getPopulation())

+deleteSmall(inout table:Table, in anItem:TableItemType)

  if (anItem.getPopulation() < 1,000,000)
    table.tableDelete(anItem)

package Tables;
import SearchKeys.KeyedItem;

public interface
       TableInterface<T extends KeyedItem<KT>,
                      KT extends Comparable <? super KT>> {

// Table operations:
// Precondition for all operations:
// No two items of the table have the same search key.
// The table's items are sorted by search key.

  public boolean tableIsEmpty();
  // Determines whether a table is empty.
  // Postcondition: Returns true if the table is
  // empty; otherwise returns false.

  public int tableLength();
  // Determines the length of a table.
  // Postcondition: Returns the number of items in the
  // table.

  public void tableInsert(T newItem) throws TableException;
  // Inserts an item into a table in its proper sorted
  // order according to the item's search key.
  // Precondition: The item to be inserted into the
  // table is newItem, whose search key differs from
  // all search keys presently in the table.
  // Postcondition: If the insertion was successful,
  // newItem is in its proper order in the table.
  // Otherwise, the table is unchanged, and
  // TableException is thrown.

  public boolean tableDelete(KT searchKey);
  // Deletes an item with a given search key from a
  // table.
  // Precondition: searchKey is the search key of the
  // item to be deleted.
  // Postcondition: If the item whose search key equals
  // searchKey existed in the table, the item was
  // deleted and method returns true. Otherwise, the
  // table is unchanged and the method returns false.

  public T tableRetrieve(KT searchKey);
  // Retrieves an item with a given search key from a
  // table.
  // Precondition: searchKey is the search key of the
  // item to be retrieved.
  // Postcondition: If the retrieval was successful,
  // the table item with the matching search key is
  // returned. If no such item exists, the method
  // returns a null reference.

}  // end TableInterface

Look at the "middle" item in the table

package Tables;
import SearchKeys.KeyedItem;
import java.util.ArrayList;

// *********************************************************
// ADT table.
// Sorted array-based implementation.
// Assumption: A table contains at most one item with a
//             given search key at any time.
// *********************************************************

public class
       TableArrayBased<T extends KeyedItem<KT>,
                       KT extends Comparable<? super KT>>
       implements TableInterface<T, KT> {
  final int MAX_TABLE = 100;        // maximum size of table
  protected ArrayList<T> items;     // table items

  public TableArrayBased() {
    items = new ArrayList<T>(MAX_TABLE);
  }  // default constructor

  public boolean tableIsEmpty() {
    return tableLength()==0;
  } // end tableIsEmpty

  public int tableLength() {
    return items.size();
  }  // end tableLength

  public void tableInsert(T newItem) throws TableException {
  // Calls: position.
    if (tableLength() < MAX_TABLE) {
      // there is room to insert;
      // locate the position where newItem belongs
      int spot = position(newItem.getKey());
      if ((spot < tableLength()) &&
          (items.get(spot).getKey()).compareTo(
                                       newItem.getKey())==0) {
        // we have found a duplicate key
        throw new TableException("Table Exception: " +
                    "Insertion failed, duplicate key item");
      }
      else {
        // ArrayList automatically shifts items to make room
        // for the new item
        items.add(spot, newItem);
      }  // end if
    }
    else {
      throw new TableException("TableException: Table full");
    } // end if
  }  // end tableInsert

  public boolean tableDelete(KT searchKey) {
  // Calls: position.
    // locate the position where searchKey exists/belongs
    int spot = position(searchKey);
    // is searchKey present in the table?
    boolean success = (spot <= tableLength()) &&
           (items.get(spot).getKey().compareTo(searchKey)==0);
    if (success) {
      // searchKey in table
      // ArrayList automatically shifts items
      items.remove(spot);
    }  // end if

    return success;
  }  // end tableDelete

  public T tableRetrieve(KT searchKey) {
  // Calls: position.

    // locate the position where searchKey exists/belongs
    int spot = position(searchKey);
    // is searchKey present in table?
    boolean success = (spot < tableLength()) &&
           (items.get(spot).getKey().compareTo(searchKey)==0);
    if (success) {
      return items.get(spot);  // item present; retrieve it
    }
    else {
      return null;
    }  // end if
  }  // end tableRetrieve

  protected int position(KT searchKey) {
  // Finds the position of a table item or its insertion
  // point.
  // Precondition: searchKey is the value of the search key
  // sought in the table.
  // Postcondition: Returns the index (between 0 and size - 1)
  // of the item in the table whose search key equals
  // searchKey. If no such item exists, returns the position
  // (between 0 and size) that the item would occupy if
  // inserted into the table. The table is unchanged.
    int pos = 0;
    while ((pos < tableLength()) &&
         (searchKey.compareTo(items.get(pos).getKey()) > 0)) {
      pos++;
    }  // end while
    return pos;
  }  // end position

}  // end TableArrayBased

package Tables;
import BinaryTrees.BinarySearchTree;
import BinaryTrees.TreeException;
import SearchKeys.KeyedItem;

// Assumes that the binary search tree created in Chapter 11
// is contained in a package called BinaryTrees.

// ********************************************************
// Implementation of a table using a binary search tree.
// Assumption: A table contains at most one item with a
//             given search key at any time.
// ********************************************************

public class
       TableBSTBased<T extends KeyedItem<KT>,
                     KT extends Comparable<? super KT>>
       implements TableInterface<T, KT> {
// binary search tree that contains the table's items
  protected BinarySearchTree<T,KT> bst;
  protected int size;       // number of items in the table

  public TableBSTBased() {
    bst = new BinarySearchTree<T,KT>();
    size = 0;
  }  // end default constructor

// table operations:
  public boolean tableIsEmpty() {
    return size == 0;
  }  // end tableIsEmpty

  public int tableLength() {
    return size;
  }  // end tableLength

  public void tableInsert(T newItem) throws TableException {
    if (bst.retrieve(newItem.getKey()) == null) {
      bst.insert(newItem);
      ++size;
    }
    else {
      throw new TableException("Table Exception: Insertion"
                             + " failed, duplicate key item");
    } // end if
  }  // end tableInsert

  public T tableRetrieve(KT searchKey) {
    return bst.retrieve(searchKey);
  }  // end tableRetrieve

  public boolean tableDelete(KT searchKey) {
    try {
      bst.delete(searchKey);
    }  // end try
    catch (TreeException e) {
      return false;
    }  //end catch
    --size;
    return true;
  }  // end tableDelete
  protected void setSize(int newSize) {
    size = newSize;
  }  // end setSize

}  // end TableBSTBased

import Tables.*;

class TestTable {
  public static void displayCity(City c) {
    System.out.println(c.getCity());
  }  // end displayCity

  // Main entry point
  public static void main(String[] args) {
    TableInterface<City, String> chart =
                        new TableBSTBased<City, String>();
  City c;

  c = new City("Narragansett, RI", "USA", 16361);
  chart.tableInsert(c);
  c = new City("Ocracoke, NC", "USA", 769);
  chart.tableInsert(c);

  System.out.println(chart.tableRetrieve("Narragansett, RI"));
  System.out.println(chart.tableLength());

  // If a table iterator class called TableIteratorBST
  // is available for the class TableBSTBased (as created
  // in Programming Problem 2, you can also do the
  // following:
  TreeIteratorBST<City> iter = new TableIteratorBST<City>(chart);
  while (iter.hasNext()) {
    displayCity(iter.next());
  } // end while

  } // end main
} // end TestTable
