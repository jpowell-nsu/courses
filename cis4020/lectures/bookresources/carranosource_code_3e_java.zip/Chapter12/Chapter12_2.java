// PQItemType is the type of the items
// stored in the priority queue.

+createPQueue()
// Creates an empty priority queue.

+pqIsEmpty():boolean {query}
// Determines whether a priority queue is empty.

+pqInsert(in newItem:PQItemType) throws PQueueException
// Inserts newItem into a priority queue. Throws
// PQueueException if priority queue is full.

+pqDelete():PQItemType
// Retrieves and then deletes the item in a priority queue
// with the highest priority value.

// HeapItemType is the type of the items stored
// in the heap

+createHeap()
// Creates an empty heap.

+heapIsEmpty():boolean {query}
// Determines whether a heap is empty.

+heapInsert(in newItem:HeapItemType) throws HeapException
// Inserts newItem into a heap. Throws HeapException
// if heap is full.

+heapDelete():HeapItemType
// Retrieves and then deletes a heap's root item.
// This item has the largest search key.

// return the item in the root
rootItem = items[0]

// copy the item from the last node into the root
items[0] = items[size-1]

// remove the last node
--size

+heapRebuild(inout items:ArrayType, in root:integer,
            in size:integer)
// Converts a semiheap rooted at index root into a heap.

  // Recursively trickle the item at index root down to
  // its proper position by swapping it with its larger
  // child, if the child is larger than the item.
  // If the item is at a leaf, nothing needs to be done.

  if (the root is not a leaf) {
    // root must have a left child
    child = 2 * root + 1             // left child index

    if (the root has a right child) {
      rightChild = child + 1        // right child index
      if (items[rightChild].getKey() > items[child].getKey()) {
        child = rightChild          // larger child index
      }  // end if
    }  // end if

    // if the item in the root has a smaller search key
    // than the search key of the item in the larger
    // child, swap items
    if (items[root].getKey() < items[child].getKey()) {
      Swap items[root] and items[child]

      // transform semiheap rooted at child into a heap
      heapRebuild(items, child, size)
    }  // end if
  }  // end if

  // else root is a leaf, so you are done

// return the item in the root
rootItem = items[0]

// copy the item from the last node into the root
items[0] = items[size-1]

// remove the last node
--size

// transform the semiheap back into a heap
heapRebuild(items, 0, size)
return rootItem

// insert newItem into the bottom of the tree
items[size] = newItem

// trickle new item up to appropriate spot in the tree
place = size
parent = (place-1)/2
while ( (parent >= 0) and
        (items[place] > items[parent]) ) {
  Swap items[place] and items[parent]
  place = parent
  parent = (place-1)/2
}  // end while

Increment size

package Heaps;
import java.util.ArrayList;
import java.util.Comparator;

public class Heap<T> {
  private ArrayList<T> items;    // array of heap items
  private Comparator<? super T> comparator;

  public Heap() {
    items = new ArrayList<T>();
  }  // end default constructor

  public Heap(Comparator<? super T> comparator) {
    items = new ArrayList<T>();
    this.comparator = comparator;
  }  // end default constructor

// heap operations:
  public boolean heapIsEmpty() {
  // Determines whether a heap is empty.
  // Precondition: None.
  // Postcondition: Returns true if the heap is empty;
  // otherwise returns false.
    return items.size()==0;
  } // end heapIsEmpty

  public void heapInsert(T newItem)
         throws HeapException, ClassCastException {
  // Inserts an item into a heap.
  // Precondition: newItem is the item to be inserted.
  // Postcondition: If the heap was not full, newItem is
  // in its proper position; otherwise HeapException is
  // thrown.
    if (!items.add(newItem)) {
      // problem adding element to ArrayList item for heap
      throw new HeapException("HeapException: heapInsert failed");
    } else {
      // trickle new item up to its proper position
      int place = items.size()-1;
      int parent = (place - 1)/2;
      while ((parent >= 0) &&
             (compareItems(items.get(place), items.get(parent))) < 0) {
        // swap items[place] and items[parent]
        T temp = items.get(parent);
        items.set(parent, items.get(place));
        items.set(place, temp);

        place = parent;
        parent = (place - 1)/2;
      }  // end while
    } // end else
  } // end heapInsert

  public T heapDelete() {
  // Retrieves and deletes the item in the root of a heap.
  // This item has the largest search key in the heap.
  // Precondition: None.
  // Postcondition: If the heap is not empty, returns the
  // item in the root of the heap and then deletes it. However,
  // if we remove the item first, it may make the ArrayList items
  // method returns null.
    T rootItem = null;
    int loc;
    if (!heapIsEmpty()) {
      rootItem = items.get(0);
      loc = items.size()-1;
      // if the heap is empty, removal is impossible and the
      // empty, then set() won't work
      items.set(0, items.get(loc));
      items.remove(loc);
      heapRebuild(0);
    }  // end if
    return rootItem;
  } // end heapDelete

  protected void heapRebuild(int root) {
  // if the root is not a leaf and the root's search key
  // is less than the larger of the search keys in the
  // root's children
    int child = 2 * root + 1;  // index of root's left
                               // child, if any
    if ( child < items.size() ) {
      // root is not a leaf, so it has a left child at child
      int rightChild = child + 1;  // index of right child,
                                   // if any

      // if root has a right child, find larger child
      if ((rightChild < items.size()) &&
          (compareItems(items.get(rightChild),items.get(child)))
                                                        < 0) {
        child = rightChild;  // index of larger child
      } // end if

      // if the root's value is smaller than the
      // value in the larger child, swap values
      if (compareItems(items.get(root), items.get(child)) > 0) {
        T temp = items.get(root);
        items.set(root, items.get(child));
        items.set(child, temp);
        // transform the new subtree into a heap
        heapRebuild(child);
      }  // end if
    }  // end if
    // if root is a leaf, do nothing
  } // end heapRebuild

  private int compareItems(T item1, T item2) {
    if (comparator == null) {
    return ((Comparable <T>)item1).compareTo(item2);
    } else {
      return comparator.compare(item1, item2);
    } // end if
  } // end compare
} // end Heap

package PriorityQueues;
import Heaps.Heap;
import Heaps.HeapException;
import java.util.Comparator;

// *********************************************************
// Assumes that Heap implementation is in package Heaps.
// PriorityQueue class implementation.
// *********************************************************

public class PriorityQueue<T>{
  private Heap<T> h;

  public PriorityQueue() {
    h = new Heap<T>();
  }  // end default constructor

  public PriorityQueue(Comparator<? super T> comparator) {
    h = new Heap<T>(comparator);
  }  // end default constructor

  // priority-queue operations:
  public boolean pqIsEmpty() {
    return h.heapIsEmpty();
  }  // end pqIsEmpty

  public void pqInsert(T newItem) throws PriorityQueueException {
    try {
      h.heapInsert(newItem);
    }  // end try
    catch (HeapException e) {
      throw new PriorityQueueException(
            "PQueueException: Problem inserting to Priority Queue");
    }  // end catch
  }  // end pqInsert

  public T pqDelete() {
    return h.heapDelete();
  }  // end pqDelete

}  // end PriorityQueue

for (index = n - 1 down to 0)
  // Assertion: the tree rooted at index is a semiheap
  heapRebuild(anArray, index, n)
  // Assertion: the tree rooted at index is a heap

+heapSort(in anArray:ArrayType, in n:integer)
// Sorts anArray[0..n-1].

  // build initial heap
  for (index = n - 1 down to 0) {
    // Invariant: the tree rooted at index is a semiheap
    heapRebuild(anArray, index, n)
    // Assertion: the tree rooted at index is a heap
  }  // end for
  // Assertion: anArray[0] is the largest item in heap
  // anArray[0..n-1]

  // initialize the regions
  last = n - 1

  // Invariant: anArray[0..last] is a heap,
  // anArray[last+1..n-1] is
  // sorted and contains the largest items of A
  for (step = 1 through n) {
    // move the largest item in the heap region -- that
    // is, the root anArray[0] -- to the beginning of the
    // Sorted region by swapping items
    Swap anArray[0] and anArray[last]

    // expand the Sorted region, shrink the Heap region
    Decrement last

    // make the Heap region a heap again
    heapRebuild(anArray, 0, last)
  }  // end for
