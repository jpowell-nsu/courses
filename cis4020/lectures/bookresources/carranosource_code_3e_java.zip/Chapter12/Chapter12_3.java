public interface Map<K,V> {
  void clear();
    // Removes all mappings from this map (optional operation).

  boolean containsKey(Object key);
    // Returns true if this map contains a mapping for the specified
    // key.

  boolean containsValue(Object value);
    // Returns true if this map maps one or more keys to the
    // specified value.

  Set<Map.Entry<K,V>> entrySet();
    // Returns a set view of the mappings contained in this map.

  V get(Object key);
    // Returns the value to which this map maps the specified key.

  boolean isEmpty();
    // Returns true if this map contains no key-value mappings.

  Set<K> keySet();
    // Returns a set view of the keys contained in this map.

  V put(K key, V value);
    // Associates the specified value with the specified key in this
    // map (optional operation).

  V remove(Object key);
    // Removes the mapping for this key from this map if it is
    // present (optional operation).

  int size();
    // Returns the number of key-value mappings in this map.

  Collection<V> values();
    // Returns a collection view of the values contained in this
    // map.
}  // end Map

public static interface Map.Entry<K,V> {

  boolean equals(Object o);
    // Compares the specified object with this entry for equality.

  K getKey();
    // Returns the key corresponding to this entry.

  V getValue();
    // Returns the value corresponding to this entry.

  int hashCode();
    // Returns the hash code value for this map entry.

  V setValue(V value);
    // Replaces the value corresponding to this entry with the
    // specified value (optional operation).
}  // end Map.Entry

interface Set<T> extends Collection<T> {

  boolean add(T o);
    // Adds the specified element to this set if it is not already
    // present (optional operation).

  boolean addAll(Collection<? extends T> c);
    // Adds all of the elements in the specified collection to this set
    // if they're not already present (optional operation).

  void clear();
    // Removes all of the elements from this set (optional operation).

  boolean contains(Object o);
    // Returns true if this set contains the specified element.

  boolean isEmpty();
    // Returns true if this set contains no elements.

  Iterator<T> iterator();
    // Returns an iterator over the elements in this set.

  boolean remove(Object o);
    // Removes the specified element from this set if it is
    // present (optional operation).

  boolean removeAll(Collection<?> c);
    // Removes from this set all of its elements that are contained
    // in the specified collection (optional operation).

  boolean retainAll(Collection<?> c);
    // Retains only the elements in this set that are contained in the
    // specified collection (optional operation).

  int size();
    // Returns the number of elements in this set (its cardinality).
} // end Set

  HashSet<Integer> setA = new HashSet<Integer>();

  setA.add(2);
  setA.add(3);
  setA.add(5);
  setA.add(8);
  System.out.println("setA => " + setA);

  HashSet<Integer> setB = new HashSet<Integer>();

  setB.add(1);
  setB.add(3);
  setB.add(7);
  setB.add(9);
  System.out.println("setB => " + setB);

  // Set union
  HashSet<Integer> unionSet = new HashSet<Integer>(setA);
  unionSet.addAll(setB);
  System.out.println("setA union setB => " + unionSet);

  // Set intersection
  HashSet<Integer> intSet = new HashSet<Integer>(setA);
  intSet.retainAll(setB);
  System.out.println("setA intersect setB => " + intSet);

  // Set difference (setA - setB)
  HashSet<Integer> diffSet = new HashSet<Integer>(setA);
  diffSet.removeAll(setB);
  System.out.println("setA - setB => " + diffSet);

setA => [2, 8, 3, 5]
setB => [9, 1, 3, 7]
setA union setB => [2, 9, 8, 1, 3, 7, 5]
setA intersect setB => [3]
setA - setB => [2, 8, 5]

import java.util.*;

public class MapSetExample {

  static public void main(String[] args) {
    // create some data for the keys, use names
    String[] name = {"Smith, Jackson",
                     "Prichard, Marlene",
                     "Hayden, Sarah",
                     "Records, Hal",
                     "Prichard, Marlene"};

    // create corresponding values for the keys
    String[] phone = {"212-555-4444",
                      "806-555-6565",
                      "401-555-5220",
                      "445-555-3241",
                      "715-555-9087"};

    // Declare a map to contain the names and phone numbers
    HashMap<String, String> phoneBook = new HashMap<String, String>();

    // Insert the names and phone number pairs into the map.
    // When the duplicate key "Prichard, Marlene" is inserted, should
    // replace original entry.
    for (int i=0; i<name.length; i++) {
      phoneBook.put(name[i], phone[i]);
    } // end phone

    // print the contents of the map
    Set<Map.Entry<String,String>> resultSet = phoneBook.entrySet();
    Iterator<Map.Entry<String,String>> iter = resultSet.iterator();
    Map.Entry<String, String> entry;

    System.out.println("Contents of phone book, using HashMap");
    while (iter.hasNext()) {
      entry = iter.next();
      System.out.println(entry.getKey() + "\t\t" + entry.getValue());
    } // end while
    System.out.println("\n");

    // Retrieve a map value
    System.out.println("Search for " + name[2]);
    System.out.println("  - phone number is " +
                       phoneBook.get(name[2]));

    // Declare a sorted map to contain the names and phone numbers
    TreeMap<String, String> phoneBookSorted =
       new TreeMap<String, String>();

    // insert the names and phone number pairs into the map
    // when the duplicate key "Prichard, Marlene" is inserted, should
    // replace original entry
    for (int i=0; i<name.length; i++) {
      phoneBookSorted.put(name[i], phone[i]);
    } // end phone
    System.out.println("\n");

    // print the contents of the map
    Set<Map.Entry<String,String>> sortedSet =
        phoneBookSorted.entrySet();
    iter = sortedSet.iterator();
    System.out.println("Contents of sorted phone book, using TreeMap");
    while (iter.hasNext()) {
      entry = iter.next();
      System.out.println(entry.getKey() + "\t\t" + entry.getValue());
    } // end while
  } // end main
} // // end MapSetExample

Contents of phone book, using HashMap
Records, Hal          445-555-3241
Smith, Jackson        212-555-4444
Hayden, Sarah         401-555-5220
Prichard, Marlene     715-555-9087

Search for Hayden, Sarah
  - phone number is 401-555-5220

Contents of sorted phone book, using TreeMap
Hayden, Sarah         401-555-5220
Prichard, Marlene     715-555-9087
Records, Hal          445-555-3241
Smith, Jackson        212-555-4444

public class PriorityQueue<T> extends AbstractQueue<T>
                              implements Serializable

  PriorityQueue(int initialCapacity)
    // Creates a PriorityQueue with the specified initial
    // capacity that orders its elements according to their
    // natural ordering (using Comparable).

  PriorityQueue(int initialCapacity, Comparator<? super T> comparator)
    // Creates a PriorityQueue with the specified initial capacity that
    // orders its elements according to the specified comparator.

  // Other constructors available...

  boolean add(T o)
    // Adds the specified element to this queue.

  void clear()
    // Removes all elements from the priority queue.

  boolean contains(Object o)
    // Returns true if this priority queue contains the specified
    // element.

  Comparator<? super T> comparator()
    // Returns the comparator used to order this collection, or null
    // if this collection is sorted according to its elements natural
    // ordering (using Comparable).

  T element()
    // Retrieves, but does not remove, the head of this priority queue.

  Iterator<T> iterator()
    // Returns an iterator over the elements in this queue.

  boolean offer(T o)
    // Inserts the specified element into this priority queue.

  T peek()
    // Retrieves, but does not remove, the head of this queue,
    // returning null if this queue is empty.

  T poll()
    // Retrieves and removes the head of this queue, or null if this
    // queue is empty.

  boolean remove(Object o)
    // Removes a single instance of the specified element from this
    // queue, if it is present.

  int size()
    // Returns the number of elements in this collection.
} // end PriorityQueue

static public void main(String[] args) {

  PriorityQueue<Integer> pq = new PriorityQueue<Integer>(10);
  pq.offer(87);
  pq.offer(2);
  pq.offer(10);
  pq.offer(5);

  System.out.println("The elements will be processed in this order:");
  System.out.print(pq.remove());
  while (!pq.isEmpty()) {
    System.out.print(", " + pq.remove());
  }
  System.out.println();
} // end main

The elements will be processed in this order:

  2, 5, 10, 87
