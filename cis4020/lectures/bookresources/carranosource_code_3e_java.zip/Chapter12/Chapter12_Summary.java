Retrieve all the information about John Smith
