import SearchKeys.KeyedItem;

class TreeNode<T> {
  T smallItem;
  T largeItem;
  TreeNode<T> leftChild;
  TreeNode<T> midChild;
  TreeNode<T> rightChild;

// constructors appear here
  .  .  .
}  // end TreeNode

+inorder(in ttTree:TwoThreeTree)
// Traverses the nonempty 2-3 tree, ttTree, in sorted
// search-key order.

  if (ttTree's root node r is a leaf) {
    Visit the data item(s)
  }
  else if (r has two data items) {
    inorder(left subtree of ttTree's root)
    Visit the first data item
    inorder(middle subtree of ttTree's root)
    Visit the second data item
    inorder(right subtree of ttTree's root)
  }
  else  { // r has one data item
    inorder(left subtree of ttTree's root)
    Visit the data item
    inorder(right subtree of ttTree's root)
  }  // end if

+retrieveItem(in ttTree:TwoThreeTree,
              in searchKey:KeyType):TreeItemType
// Returns from the nonempty 2-3 tree ttTree the
// item whose search key equals searchKey. The operation
// fails and returns null if no such item exists,

  if (searchKey is in ttTree's root node r) {
    // the item has been found
    treeItem = the data portion of r
  }
  else if (r is a leaf) {
    treeItem = null  // failure
  }

  // else search the appropriate subtree
  else if (r has two data items) {
    if (searchKey < smaller search key of r) {
      treeItem = retrieveItem(r's left subtree, searchKey)
    }
    else if (searchKey < larger search key of r) {
     treeItem = retrieveItem(r's middle subtree, searchKey)
    }
    else  {
     treeItem = retrieveItem(r's right subtree, searchKey)
    }  // end if
  }

  else  { // r has one data item
    if (searchKey < r's search key) {
      treeItem = retrieveItem(r's left subtree, searchKey)
    }
    else {
      treeItem = retrieveItem(r's right subtree, searchKey)
    }  // end if
  }  // end if

+insertItem(in ttTree:TwoThreeTree, in newItem:TreeItemType)
// Inserts newItem into a 2-3 tree ttTree whose items have
// distinct search keys that differ from newItem's search
// key.

  Let sKey be the search key of newItem
  Locate the leaf leafNode in which sKey belongs
  Add newItem to leafNode

  if (leafNode now has three items) {
    split(leafNode)
  }  // end if

split(inout n:TreeNode)
// Splits node n, which contains 3 items. Note: if n is
// not a leaf, it has 4 children.

  if (n is the root) {
    Create a new node p
  }
  else {
    Let p be the parent of n
  }  // end if

  Replace node n with two nodes, n1 and n2, so that p is
      their parent

  Give n1 the item in n with the smallest search-key value
  Give n2 the item in n with the largest search-key value

  if (n is not a leaf) {
    n1 becomes the parent of n's two leftmost children
    n2 becomes the parent of n's two rightmost children
  }  // end if

  Move the item in n that has the middle
      search-key value up to p

  if (p now has three items) {
    split(p)
  }  // end if

+deleteItem(in ttTree:TwoThreeTree, in searchKey:KeyType)
// Deletes from the 2-3 tree the item whose
// search key equals searchKey. If the deletion is
// successful, the method returns true.
// If no such item exists, the operation fails and
// returns false.

  Attempt to locate item theItem whose search key
      equals searchKey

  if (theItem is present) {
    if (theItem is not in a leaf) {
      Swap item theItem with its inorder successor, which
          will be in a leaf theLeaf
    }  // end if

    // the deletion always begins at a leaf
    Delete item theItem from leaf theLeaf

    if (theLeaf now has no items) {
      fix(theLeaf)
    }  // end if
    return true
  }

  else {
    return false
  }  // end if

+fix(in n:TreeNode)
// Completes the deletion when node n is empty by either
// removing the root, redistributing values, or merging
// nodes. Note: if n is internal, it has one child.

  if (n is the root) {
    Remove the root
  }

    else {
      Let p be the parent of n

    if (some sibling of n has two items) {
      Distribute items appropriately among n, the
          sibling, and p
      if (n is internal) {
        Move the appropriate child from sibling to n
      }  // end if
    }

    else  { // merge the node
      Choose an adjacent sibling s of n
      Bring the appropriate item down from p into s

      if (n is internal) {
        Move n's child to s
      }  // end if

      Remove node n

      if (p is now empty) {
        fix(p)
      }  // end if
    }  // end if

  }  // end if

class TreeNode<T> {
  T smallItem;
  T middleItem;
  T largeItem;
  TreeNode<T> leftChild;
  TreeNode<T> lMidChild;
  TreeNode<T> rMidChild;
  TreeNode<T> rightChild;

// constructors appear here
  .  .  .
}  // end TreeNode

public enum Color {RED, BLACK}

class TreeNode<T> {
  T item;
  TreeNode<T> leftChild;
  TreeNode<T> rightChild;
  Color leftColor;
  Color rightColor;

// constructors appear here
  .  .  .
}  // end TreeNode
