+tableInsert (in newItem:TableItemType)

  i = the array index that the address calculator
          gives you for newItem's search key
  table[i] = newItem

+tableRetrieve(in searchKey:KeyType):TableItemType
// Returns table item that has a matching searchKey.
// If not found, returns null.

  i = the array index that the address calculator
          gives you for an item whose search key
          equals searchKey

  if (table[i].getKey() equals searchKey) {
    return table[i]
  }
  else {
    return null
  }  // end if

+tableDelete(in searchKey:KeyType)
// Deletes item that has a matching searchKey. If
// successful, returns true; otherwise, returns false.
  i = the array index that the address calculator
          gives you for an item whose search key
          equals searchKey

  success = (table[i].getKey() equals searchKey)
  if (success) {
    Delete the item from table[i]
  }  // end if
  return success

i = the array index that the address calculator
      gives you for an item whose search key
      equals searchKey

i = h(searchKey)

class ChainNode<K, V> {
  private K key;
  private V value;
  ChainNode<K, V> next;

  public ChainNode(K newKey, V newValue,
                   ChainNode<K, V> nextNode) {
    key = newKey;
    value = newValue;
    next = nextNode;
  }  // end constructor

  public V getValue() {
    return value;
  }  // end getValue

  public K getKey() {
    return key;
  }  // end getKey

} // end ChainNode

// ********************************************************
// Hash table implementation.
// Assumption: A table contains at most one item with a
//             given search key at any time.
// Note: This code will compile with a warning about the use
// of unchecked or unsafe operations. This is due to the
// cast in method tableRetrieve.  Exercise X asks you to
// rewrite this implementation using ArrayList to avoid this
// warning.
// *********************************************************

public class HashTable<K, V> {
  public final int HASH_TABLE_SIZE = 101;
  private ChainNode[] table;     // hash table
  private int size = 0;          // size of ADT table

  public HashTable() {
    table = new ChainNode[HASH_TABLE_SIZE];
  }  // end default constructor

// table operations
  public boolean tableIsEmpty() {
    return size==0;
  }  // end tableIsEmpty

  public int tableLength() {
    return size;
  }  // end tableLength

// Programming Problem 4 asks you to implement the following
// methods.

  public void tableInsert(K key, V value)
                          throws HashException {
    // ...
  }  // end tableInsert

  public boolean tableDelete(K searchKey) {

    // ...
    return true;  // added for compilation
  }  // end tableDelete

  public V tableRetrieve(K searchKey) {
    // ...
    return null;  // added for compilation
  } // end tableRetrieve

  public int hashIndex(K key) {
    // ...
  }  // end hashIndex

}  // end HashTable

+tableInsert(in searchKey:KeyType, in value:ValueType)

  if (table not full) {
    searchKey = the search key of newItem
    i = hashIndex(searchKey)
    node = reference to a new node containing searchKey and value
    node.next = table[i]
    table[i] = node
  }
  else { // table full
    throw new HashException()
  }  // end if

+tableRetrieve(in searchKey:KeyType):ValueType

  i = hashIndex(searchKey)
  node = table[i]

  while ((node ? null) && (node.getKey() ? searchKey)){
    node = node.next
  }  // end while

  if (node != null) {
    return node.getValue()
  }

  else {
    return null
  }  // end if

public class Hashtable<K,V>
  extends Dictionary<K,V>
  implements Map<K,V>, Cloneable, Serializable {

  Hashtable()
    // Constructs a new, empty hashtable with a default
    // capacity (11) and load factor, which is 0.75.

  Hashtable(int initialCapacity)
    // Constructs a new, empty hashtable with the specified
    // capacity and load factor, which is 0.75.

  Hashtable(int initialCapacity, float loadFactor)
    // Constructs a new, empty hashtable with the specified
    // initial capacity and the specified load factor.

  void clear()
    // Clears this hashtable so that it contains no keys.

  boolean contains(Object value)
    // Tests if some key maps into the specified value in this
    // hashtable.

  boolean containsKey(Object key)
    // Tests if the specified object is a key in this
    //  hashtable.

  boolean containsValue(Object value)
    // Returns true if this Hashtable maps one or more keys to
    // this value.

  Set<Map.Entry<K,V>> entrySet()
    // Returns a Set view of the entries contained in this
    // Hashtable.

  V get(Object key)
    // Returns the value to which the specified key is mapped
    // in this Hashtable.

  boolean isEmpty()
    // Tests if this hashtable maps no keys to values.

  Set<K> keySet()
    // Returns a Set view of the keys contained in this
    // Hashtable.

  V put(K key, V value)
    // Maps the specified key to the specified value in this
    // Hashtable.

  void putAll(Map<? extends K,? extends V> t)
    // Copies all of the mappings from the specified Map to
    // this Hashtable. These mappings will replace any
    // mappings that this Hashtable had for any of the keys
    // currently in the specified Map.

  protected void rehash()
    // Increases the capacity of and internally reorganizes
    // this Hashtable, in order to accommodate and access its
    // entries more efficiently.

  V remove(Object key)
    // Removes the key (and its corresponding value) from this
    // Hashtable.

  int size()
    // Returns the number of keys in this Hashtable.

  String toString()
    // Returns a string representation of this Hashtable
    // object in the form of a set of entries, enclosed in
    // braces and separated by the ASCII characters ", "
    // (comma and space).

  Collection<V> values()
    // Returns a collection view of the values contained in
    // this map.

} // end HashTable

  Hashtable<String, Integer> ht = new Hashtable<String, Integer>();

  // Placing items into the hash table
  ht.put("Sarah", 17);
  ht.put("Mike", 57);
  ht.put("Janet", 51);
  ht.put("Andrew", 20);

  // Retrieving items from the hash table
  System.out.println("Janet  => " + ht.get("Janet"));
  System.out.println("Mike  => " + ht.get("Mike"));
  System.out.println("Nobody => " + ht.get("Nobody"));

Janet  => 51
Mike  => 57
Nobody => null

public class TreeMap<K,V>
  extends AbstractMap<K,V>
  implements SortedMap<K,V>, Cloneable, Serializable {

  TreeMap()
    // Constructs a new, empty map, sorted according to the
    // keys' natural order.

  TreeMap(Comparator<? super K> c)
    // Constructs a new, empty map, sorted according to the
    // given comparator.

  void clear()
    // Removes all mappings from this TreeMap.

  Comparator<? super K> comparator()
    // Returns the comparator used to order this map, or null
    // if this map uses its keys' natural order.

  boolean containsKey(Object key)
    // Returns true if this map contains a mapping for the
    // specified key.

  boolean containsValue(Object value)
    // Returns true if this map maps one or more keys to the
    // specified value.

  Set<Map.Entry<K,V>> entrySet()
    // Returns a set view of the mappings contained in this
    // map.

  K firstKey()
    // Returns the first (lowest) key currently in this sorted
    // map.

  V get(Object key)
    // Returns the value to which this map maps the specified
    // key.

  SortedMap<K,V> headMap(K toKey)
    // Returns a view of the portion of this map whose keys
    // are strictly less than toKey.

  K lastKey()
    // Returns the last (highest) key currently in this sorted
    // map.

  V put(K key, V value)
    // Associates the specified value with the specified key
    // in this map.

  void putAll(Map<? extends K,? extends V> map)
    // Copies all of the mappings from the specified map to
    // this map.

  V remove(Object key)
    // Removes the mapping for this key from this TreeMap if
    // present.

  int size()
    // Returns the number of key-value mappings in this
    // map.

  SortedMap<K,V> subMap(K fromKey, K toKey)
    // Returns a view of the portion of this map whose
    // keys range from fromKey, inclusive, to toKey,
    // exclusive.

  SortedMap<K,V> tailMap(K fromKey)
    // Returns a view of the portion of this map whose keys
    // are greater than or equal to fromKey.

  Collection<V> values()
    // Returns a collection view of the values contained in
    // this map.
}  // end TreeMap

  TreeMap<String, String> phoneBook =
                                new TreeMap<String, String>();
  phoneBook.put("Smith, Jackson", "212-555-4444");
  phoneBook.put("Prichard, Marlene F.", "806-555-6565");
  phoneBook.put("Hayden, Sarah", "401-555-5220");
  phoneBook.put("Records, H.", "445-555-3241");
  phoneBook.put("Harrington, J. R.", "617-555-1962");
  phoneBook.put("Sousa, Keith", "252-555-0607");

  // Return all of the entries such that "H" <= key value <
  // "I", in other words, all of the names that start with H
  SortedMap results = phoneBook.subMap("H","I");

  if (results.isEmpty()) {
    System.out.println("Sorry, no names beginning with H found.");

  } else {
    // Set up an iterator so we can print the entries in
    // result
    Iterator<Map.Entry<String, String>> iter =
                                        results.entrySet().iterator();
    Map.Entry<String, String> entry;
    while (iter.hasNext()) {
      entry = iter.next();
      System.out.println(entry.getKey() + "\t: " + entry.getValue());
    }  // end while
  }  // end if

Harrington, J. R.  : 617-555-1962
Hayden, Sarah  :     401-555-5220
