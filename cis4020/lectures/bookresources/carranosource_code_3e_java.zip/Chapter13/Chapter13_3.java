+peek():ItemType

  Let nodeRef be the reference stored at the front of
      the queue (nodeRef references the node, which is
      in the sorted linked list, that contains the
      record for the customer at the front of the
      queue)

  return item in the node that nodeRef references

+enqueue(in newItem:ItemType)

    Find the proper position for newItem in the sorted
        linked list
    Insert a node that contains newItem into this
        position
    Insert a reference to the new node at the back of
        the queue

+dequeue()

  Delete the item at the front of the queue and
      retain its reference nodeRef (nodeRef
      references the node that contains the customer
      record to be deleted)

  Delete from the sorted linked list the node
      that nodeRef references
