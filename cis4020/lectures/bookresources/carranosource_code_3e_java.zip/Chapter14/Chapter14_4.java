+topSort1(in theGraph:Graph)
// Arranges the vertices in graph theGraph into a
// topological order and places them in list aList
// Returns aList.

   n = number of vertices in theGraph
   for (step = 1 through n) {
      Select a vertex v that has no successors
      aList.add(1, v)
      Delete from theGraph vertex v and its edges
   }  // end for
   return aList

+topSort2(in theGraph:Graph):List
// Arranges the vertices in graph theGraph into a
// topological order and places them in list aList.
// Returns aList.

   s.createStack()
   for (all vertices v in the graph theGraph) {
      if (v has no predecessors) {
         s.push(v)
         Mark v as visited
      }  // end if
   }  // end for

  while (!s.isEmpty()) {
     if (all vertices adjacent to the vertex on
           the top of the stack have been visited) {
        v = s.pop()
        aList.add(1, v)
     }
     else {
        Select an unvisited vertex u adjacent to
          the vertex on the top of the stack
        s.push(u)
        Mark u as visited
     }  // end if
  }  // end while
  return aList

+dfsTree(in v:Vertex)
// Forms a spanning tree for a connected undirected graph
// beginning at vertex v by using depth-first search:
// Recursive version.

   Mark v as visited

   for (each unvisited vertex u adjacent to v) {
      Mark the edge from u to v
      dfsTree(u)
   }  // end for

+bfsTree(in v:Vertex)
// Forms a spanning tree for a connected undirected graph
// beginning at vertex v by using breadth-first search:
// Iterative version.

   q.createQueue()

   // add v to queue and mark it
   q.enqueue(v)
   Mark v as visited

   while (!q.isEmpty() {
      w = q.dequeue()

      // loop invariant: there is a path from vertex w to
      // every vertex in the queue q
      for (each unvisited vertex u adjacent to w) {
         Mark u as visited
         Mark edge between w and u
         q.enqueue(u)
      }  // end for
   }  // end while

+PrimsAlgorithm(in v:Vertex)
// Determines a minimum spanning tree for a weighted,
// connected, undirected graph whose weights are
// nonnegative, beginning with any vertex v.
   Mark vertex v as visited and include it in the minimum
     spanning tree

   while (there are unvisited vertices) {
      Find the least-cost edge (v, u) from a visited
        vertex v to some unvisited vertex u
      Mark u as visited
      Add the vertex u and the edge (v, u) to the minimum
        spanning tree
   }  // end while

+shortestPath(in theGraph:Graph, in weight:WeightArray)
// Finds the minimum-cost paths between an origin vertex
// (vertex 0) and all other vertices in a weighted directed
// graph theGraph. The array weight contains theGraph's
// weights which are nonnegative.

  // Step 1: initialization
  Create a set vertexSet that contains only vertex 0
  n = number of vertices in theGraph
  for (v = 0 through n - 1) {
    weight[v] = matrix[0][v]
    }  // end for
    // Steps 2 through n
    // Invariant: For v not in vertexSet, weight[v] is the
    // smallest weight of all paths from 0 to v that pass
    // through only vertices in vertexSet before reaching v.
    // For v in vertexSet, weight[v] is the smallest weight
    // of all paths from 0 to v (including paths outside
    // vertexSet), and the shortest path from 0 to v lies
    // entirely in vertexSet.
    for (step = 2 through n) {
      Find the smallest weight[v] such that v is not in
          vertexSet
      Add v to vertexSet

    // Check weight[u] for all u not in vertexSet
    for (all vertices u not in vertexSet) {
      if (weight[u] > weight[v] + matrix[v][u]) {
        weight[u] = weight[v] + matrix[v][u]
      }  // end if
    }  // end for
  }  // end for
