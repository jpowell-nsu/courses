buf.readBlock(dataFile, i)

buf.writeBlock(dataFile, i)

buf.writeBlock(dataFile, n + 1)

// read block i from file dataFile into buffer buf
buf.readBlock(dataFile, i)

Find the entry buf.getRecord(j) that contains the
    record whose search key is "Smith"

// increase the salary portion of Smith's record
((buf.getRecord(j)).setSalary((buf.getRecord(j)).salary()
               + 1000)

// write changed block back to file dataFile
buf.writeBlock(dataFile, i)

rec.readRecord(dataFile, i)
// Reads the ith record of file dataFile into rec.
