Read the first block of Ri into in1
Read the first block of Rj into in2
while (either in1 or in2 is not exhausted) {
  Select the smaller "leading" record of in1 and in2
      and place it into the next position of out (if
      one of the buffers is exhausted, select the
      leading record from the other)

  if (out is full) {
    Write its contents to the next block of F2
  }  // end if
  if (in1 is exhausted and blocks remain in Ri) {
    Read the next block into in1
  }  // end if
  if (in2 is exhausted and blocks remain in Rj) {
    Read the next block into in2
  }  // end if
}  // end while

+externalMergesort(in unsortedFileName:String,
                   in sortedFileName:String)
// Sorts a file by using an external mergesort.
// Precondition: unsortedFileName is the name of an external
// file to be sorted. sortedFileName is the name that the
// method will give to the resulting sorted file.
// Postcondition: The new file named sortedFileName is sorted.
// The original file is unchanged. Both files are closed.
// Calls: blockSort, mergeFile, and copyFile.
// Simplifying assumption: The number of blocks in the
// unsorted file is an exact power of 2.

  Associate unsortedFileName with the file variable inFile
      and sortedFileName with the file variable outFile

  // Phase 1: sort file block by block and count the blocks
  blockSort(inFile, tempFile1, numberOfBlocks)

  // Phase 2: merge runs of size 1, 2, 4, 8,...,
  // numberOfBlocks/2 (uses two temporary files and a toggle
  // that keeps track of the files for each merge step)
  toggle = 1

  for (size = 1 through numberOfBlocks/2 with
                                         increments of size) {
    if (toggle == 1) {
      mergeFile(tempFile1, tempFile2, size, numberOfBlocks)
    }
    else {
      mergeFile(tempFile2, tempFile1, size, numberOfBlocks)
    }  // end if
    toggle = -toggle
  }  // end for

  // copy the current temporary file to outFile
  if (toggle == 1) {
    copyFile(tempFile1, outFile)
  }
  else {
    copyFile(tempFile2, outFile)
  }  // end if

blockSort(in inFile:File, in outFile:File,
          in numberOfBlocks:integer)
// Sorts each block of records in a file.
// Precondition: The file variable inFile is associated
// with the file to be sorted.
// Postcondition: The file associated with the file variable
// outFile contains the blocks of inFile. Each block is
// sorted; numberOfBlocks is the number of blocks processed.
// Both files are closed.
// Calls: readBlock and writeBlock to perform random access
// input and output, and sortBuffer to sort a buffer.

  Prepare inFile for input
  Prepare outFile for output

  numberOfBlocks = 0
  while (more blocks in inFile remain to be read) {
    ++numberOfBlocks
    buffer.readBlock(inFile, numberOfBlocks)
    sortBuffer(buffer)  // sort with some internal sort
    buffer.writeBlock(outFile, numberOfBlocks)
  }  // end while

  Close inFile and outFile
// end blockSort

+mergeFile(in inFile:File, in outFile:File,
           in runSize:integer,
           in numberOfBlocks:integer)
// Merges blocks from one file to another.
// Precondition: inFile is an external file that contains
// numberOfBlocks sorted blocks organized into runs of
// runSize blocks each.
// Postcondition: outFile contains the merged runs of
// inFile. Both files are closed.
// Calls: mergeRuns.

  Prepare inFile for input
  Prepare outFile for output

  for (next = 1 through numberOfBlocks with increments
                                             of 2 * runSize) {
    // Invariant: runs in outFile are ordered
    mergeRuns(inFile, outFile, next, runSize)
  }  // end for
  Close inFile and outFile
// end mergeFile

+mergeRuns(in fromFile:File, in toFile:File,
           in start:integer, in size:integer)
// Merges two consecutive sorted runs in a file.
// Precondition: fromFile is an external file of sorted runs
// open for input. toFile is an external file of sorted runs
// open for output. start is the block number of the first
// run on fromFile to be merged; this run contains size
// blocks.
//    Run 1: block start to block start + size - 1
//    Run 2: block start + size to start + (2 * size) - 1
// Postcondition: The merged runs from fromFile are appended
// to toFile. The files remain open.

  // initialize the input buffers for runs 1 and 2
  in1.readBlock(fromFile, first block of Run 1)
  in2.readBlock(fromFile, first block of Run 2)

  // Merge until one of the runs is finished. Whenever an
  // input buffer is exhausted, the next block is read.
  // Whenever the output buffer is full, it is written.
  while (neither run is finished) {
    // Invariant: out and each block in toFile are ordered
    Select the smaller "leading edge" of in1 and in2, and
        place it in the next position of out

    if (out is full) {
      out.writeBlock(toFile, next block of toFile)
    }  // end if

    if (in1 is exhausted and blocks remain in Run 1) {
      in1.readBlock(fromFile, next block of Run 1)
    }  // end if

    if (in2 is exhausted and blocks remain in Run 2) {
      in2.readBlock(fromFile, next block of Run 2)
    }  // end if
  }  // end while

  // Assertion: exactly one of the runs is complete

  // append the remainder of the unfinished input
  // buffer to the output buffer and write it

  while (in1 is not exhausted) {
    // Invariant: out is ordered
    Place next item of in1 into the next position of out
  }  // end while

  while (in2 is not exhausted) {
    // Invariant: out is ordered
    Place next item of in2 into the next position of out
  }  // end while

  out.writeBlock(toFile, next block of toFile)

  // finish off the remaining complete blocks

  while (blocks remain in Run 1) {
    // Invariant: each block in toFile is ordered
    in1.readBlock(fromFile, next block of Run 1)
    in1.writeBlock(toFile, next block of toFile)
  }  // end while

  while (blocks remain in Run 2) {
    // Invariant: Each block in toFile is ordered
    in2.readBlock(fromFile, next block of Run 2)
    in2.writeBlock(toFile, next block of toFile)
  }  // end while
// end mergeRuns
