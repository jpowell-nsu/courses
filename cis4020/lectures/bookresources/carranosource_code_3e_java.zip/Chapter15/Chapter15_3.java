+traverseTable(in dataFile:File, in numberOfBlocks:integer,
               in recordsPerBlock:integer)
// Traverses the sorted file dataFile in sorted order,
// visiting each node.

  // read each block of file dataFile into an
  // internal buffer buf
  for (blockNumber = 1 through numberOfBlocks) {
    buf.readBlock(dataFile, blockNumber)
    // visit each record in the block
    for (recordNumber = 1 through recordsPerBlock) {
      Visit record buf.getRecord(recordNumber-1)
    }  // end for
  }  // end for

+tableRetrieve(in dataFile:File, in recordsPerBlock:integer,
               in first:integer, in last:integer,
               in searchKey:KeyType):TableItemType
// Searches blocks first through last of file dataFile and
// returns the record whose search key equals
// searchKey. The operation fails and returns null
// if no such item exists.

  if (first > last or nothing is left to read from dataFile) {
    return null
  }
  else {
    // read the middle block of file dataFile into buffer buf
    mid = (first + last)/2
    buf.readBlock(dataFile, mid)
    if ( (searchKey >= (buf.getRecord(0)).getKey()) &&
         (searchKey <= (buf.getRecord(recordsPerBlock-1)).getKey()) ) {
      // desired block is found
      Search buffer buf for record buf.getRecord(j)
          whose search key equals searchKey
      if (record is found) {
        tableItem = buf.getRecord(j)
        return tableItem
      }
       else {
         return null
      }  // end if
    }
    // else search appropriate half of the file
    else if (searchKey < (buf.getRecord(0)).getKey()) {
      return tableRetrieve(dataFile, recordsPerBlock,
                          first, mid-1, searchKey)
    }
    else {
      return tableRetrieve(dataFile, recordsPerBlock,
                          mid+1, last, searchKey)
    }  // end if
  }  // end if

buf.setRecord(i+1, buf.getRecord(i))

tableRetrieve(in tIndex:File, in tData:File,
              in searchKey:KeyType):TableItemType
// Returns the record whose search key
// equals searchKey, where tIndex is the index file and
// tData is the data file. The operation fails and returns
// null if no such record exists.

  if (no blocks are left in tIndex to read) {
    return null
  }
  else {
    // read the middle block of index file into buf
    mid = number of middle block of index file tIndex
    buf.readBlock(tIndex, mid)
    num = indexRecordsPerBlock
    if ((searchKey >= (buf.getRecord(0)).getKey()) &&
        (searchKey <= buf.getRecord(indexRecPerBlock-1).getKey())) {

      // desired block of index file found
      Search buf for index file record buf.getRecord(j)
          whose key value equals searchKey

      if (index record buf.getRecord(j) is found) {
        blockNum = number of the data-file block to
                   which buf.getRecord(j) points
        data.readBlock(tData, blockNum)
        Find data record data.getRecord(k) whose search
            key equals searchKey
        tableItem = data.getRecord(k)
        return tableItem
      }
      else {
        return null
      }  // end if
    }

    else if (tIndex is one block in size) {
      return null  // no more blocks in file
    }

    // else search appropriate half of index file
    else if (searchKey < (buf.getRecord(0)).getKey()) {
      return tableRetrieve(first half of tIndex, tData,
                           searchKey)
    }
    else {
      return tableRetrieve(second half of tIndex, tData,
                          searchKey)
    }  // end if
  }  // end if

+tableRetrieve(in tIndex:File, in tData:File,
               in searchKey:KeyType):TableItemType
// Returns the item whose search key equals searchKey,
// where tIndex is the index file, which is hashed, and
// tData is the data file. The operation fails and returns
// null if no such record exists.

  // apply the hash function to the search key
  i = h(searchKey)

  // find the first block in the chain of index blocks -
  // these blocks contain index records that hash into
  // location i
  p = table[i]

  // if p == -1, no values have hashed into location i
  if (p != -1) {
    buf.readBlock(tIndex, p)
  }  // end if

  // search for the block with the desired index record
  while (p != -1 and buf does not contain an index record
                           whose key value equals searchKey) {
    p = number of next block in chain
    // if p == -1, you are at the last block in the chain
    if (p != -1) {
      buf.readBlock(tIndex, p)
    }  // end if
  }  // end while

  // retrieve the data item if present
  if (p != -1) {
    // buf.getRecord(j) is the index record whose
    // key value equals searchKey
    blockNum = number of the data-file block to
               which buf.getRecord(j) points
    data.readBlock(tData, blockNum)
    Find data record data.getRecord(k) whose search key
        equals searchKey
    tableItem = data.getRecord(k)
    return tableItem
  }
  else {
    return null
  }  // end if

i = h(searchKey)

i = h(searchKey)

+tableRetrieve(in tIndex:File, in tData:File, in rootNum:integer,
               in searchKey:KeyType):TableItemType
// Returns the record whose search key equals searchKey. tIndex
// is the index file, which is organized as a 2-3 tree. rootNum
// is the block number (of the index file) that contains the
// root of the tree. tData is the data file. The operation
// fails and returns a null reference if no such record exists.
  if (no blocks are left in tIndex to read) {
    return null
  }
  else {
    // read from index file into buf the
    // block that contains the root of the 2-3 tree
    buf.readBlock(tIndex, rootNum)

    // search for the index record whose key value
    // equals searchKey
    if (searchKey is in the root) {
      blockNum = number of the data-file block that
                 index record specifies
      data.readBlock(tData, blockNum)
      Find data record data.getRecord(k) whose search key
          equals searchKey
      tableItem = data.getRecord(k)
      return tableItem
    }
    // else search the appropriate subtree
    else if (the root is a leaf) {
      return null
    } // end else if
    else {
      child = block number of root of
                appropriate subtree
      return tableRetrieve(tIndex, tData, child,
                           searchKey)
    }  // end if
  }  // end if

+tableRetrieve(in tIndex:File, in tData:File, in rootNum:integer,
               in searchKey:KeyType):TableItemType
// Returns the record whose search key
// equals searchKey. tIndex is the index file, which is
// organized as a search tree. rootNum is the block number
// (of the index file) that contains the root of the tree.
// tData is the data file. The operation fails and returns
// null if no such record exists.

  if (no blocks are left in tIndex to read) {
   return null
  }
  else {
    // read from index file into internal buffer buf the
    // block that contains the root of the tree
    buf.readBlock(tIndex, rootNum)

    // search for the index record whose key value
    // equals searchKey
    if (searchKey is one of the Ki in the root) {
      blockNum = number of the data-file block that
                   index record specifies
      data.readBlock(tData, blockNum)
      Find data record data.getRecord(k) whose search key
          equals searchKey
      tableItem = data.getRecord(k)
      return tableItem
    }
    // else search the appropriate subtree
    else if (the root is a leaf) {
      return null
    }
    else {
      Determine which subtree Si to search
      child = block number of the root of Si
      return tableRetrieve(tIndex, tData, child, searchKey)
    }  // end if
  }  // end if

+traverseTable(in blockNum:integer, in m:integer)
// Traverses in sorted order an index file that is organized
// as a B-tree of degree m. blockNum is the block number of
// the root of the B-tree in the index file.

   if (blockNum != -1) {
      // read the root into internal buffer buf
      buf.readBlock(indexFile, blockNum)

      // traverse the children

      // traverse S0
      Let p be the block number of the 0th child of buf
      traverseTable(p, m)

      for (i = 1 through m - 1) {
         Display key Ki of buf
         // traverse Si
         Let p be the block number of the ith child of buf
         traverseTable(p, m)
      }  // end for
  }  // end if

+traverseTable(in blockNum:integer, in m:integer)
// Traverses in sorted order a data file that is indexed
// with a B-tree of degree m. blockNum is the block number
// of the root of the B-tree.

  if (blockNum != -1) {
    // read the root into internal buffer buf
    buf.readBlock(indexFile, blockNum)

    // traverse S0
    Let p be the block number of the 0th child of buf
    traverseTable(p, m)
    for (i = 1 through m - 1) {
      Let p_i be the pointer in the ith index record of buf
      data.readBlock(dataFile, p_i)
      Extract from data the record whose search key equals Ki
      Display the data record

      // traverse Si
      Let p be the block number of the ith child of buf
      traverseTable(p, m)
    }  // end for
  }  // end if

retrieveN(in aName:NameType):ItemType
// Retrieves the item whose search key contains the
// name aName.

retrieveS(in ssn:SSNType):ItemType
// Retrieves the item whose search key contains the
// Social Security number ssn.
